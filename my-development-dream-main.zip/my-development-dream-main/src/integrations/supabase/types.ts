export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      earnings_goals: {
        Row: {
          created_at: string
          id: string
          month: string
          target_amount: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          month: string
          target_amount?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          month?: string
          target_amount?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      earnings_records: {
        Row: {
          created_at: string
          deliveries_count: number
          entry_date: string
          fuel_expense: number
          gross_amount: number
          hours_worked: number
          id: string
          note: string | null
          other_expense: number
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          deliveries_count?: number
          entry_date: string
          fuel_expense?: number
          gross_amount?: number
          hours_worked?: number
          id?: string
          note?: string | null
          other_expense?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          deliveries_count?: number
          entry_date?: string
          fuel_expense?: number
          gross_amount?: number
          hours_worked?: number
          id?: string
          note?: string | null
          other_expense?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      fleets: {
        Row: {
          created_at: string
          expires_at: string | null
          id: string
          is_active: boolean
          name: string
          notes: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          name: string
          notes?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          expires_at?: string | null
          id?: string
          is_active?: boolean
          name?: string
          notes?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      founder_accounts: {
        Row: {
          created_at: string
          id: string
          password_hash: string
          updated_at: string
          username: string
        }
        Insert: {
          created_at?: string
          id?: string
          password_hash: string
          updated_at?: string
          username: string
        }
        Update: {
          created_at?: string
          id?: string
          password_hash?: string
          updated_at?: string
          username?: string
        }
        Relationships: []
      }
      founder_sessions: {
        Row: {
          created_at: string
          expires_at: string
          founder_id: string
          token: string
        }
        Insert: {
          created_at?: string
          expires_at: string
          founder_id: string
          token: string
        }
        Update: {
          created_at?: string
          expires_at?: string
          founder_id?: string
          token?: string
        }
        Relationships: [
          {
            foreignKeyName: "founder_sessions_founder_id_fkey"
            columns: ["founder_id"]
            isOneToOne: false
            referencedRelation: "founder_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      monthly_expenses: {
        Row: {
          amount: number
          created_at: string
          created_by: string | null
          id: string
          kind: string
          month: string
          note: string | null
          updated_at: string
        }
        Insert: {
          amount: number
          created_at?: string
          created_by?: string | null
          id?: string
          kind: string
          month: string
          note?: string | null
          updated_at?: string
        }
        Update: {
          amount?: number
          created_at?: string
          created_by?: string | null
          id?: string
          kind?: string
          month?: string
          note?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      motorcycles: {
        Row: {
          brand: string
          color: string | null
          created_at: string
          current_km: number
          id: string
          inspection_end: string | null
          inspection_start: string | null
          insurance_end: string | null
          insurance_start: string | null
          model: string
          notes: string | null
          photos: string[]
          plate: string
          service_interval_km: number
          status: Database["public"]["Enums"]["motorcycle_status"]
          updated_at: string
          year: number | null
        }
        Insert: {
          brand: string
          color?: string | null
          created_at?: string
          current_km?: number
          id?: string
          inspection_end?: string | null
          inspection_start?: string | null
          insurance_end?: string | null
          insurance_start?: string | null
          model: string
          notes?: string | null
          photos?: string[]
          plate: string
          service_interval_km?: number
          status?: Database["public"]["Enums"]["motorcycle_status"]
          updated_at?: string
          year?: number | null
        }
        Update: {
          brand?: string
          color?: string | null
          created_at?: string
          current_km?: number
          id?: string
          inspection_end?: string | null
          inspection_start?: string | null
          insurance_end?: string | null
          insurance_start?: string | null
          model?: string
          notes?: string | null
          photos?: string[]
          plate?: string
          service_interval_km?: number
          status?: Database["public"]["Enums"]["motorcycle_status"]
          updated_at?: string
          year?: number | null
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          read: boolean
          related_id: string | null
          title: string
          type: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          read?: boolean
          related_id?: string | null
          title: string
          type: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          read?: boolean
          related_id?: string | null
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      payment_schedule: {
        Row: {
          amount: number
          created_at: string
          due_date: string
          id: string
          note: string | null
          paid_amount: number
          paid_at: string | null
          rental_id: string
          status: Database["public"]["Enums"]["payment_status"]
        }
        Insert: {
          amount: number
          created_at?: string
          due_date: string
          id?: string
          note?: string | null
          paid_amount?: number
          paid_at?: string | null
          rental_id: string
          status?: Database["public"]["Enums"]["payment_status"]
        }
        Update: {
          amount?: number
          created_at?: string
          due_date?: string
          id?: string
          note?: string | null
          paid_amount?: number
          paid_at?: string | null
          rental_id?: string
          status?: Database["public"]["Enums"]["payment_status"]
        }
        Relationships: [
          {
            foreignKeyName: "payment_schedule_rental_id_fkey"
            columns: ["rental_id"]
            isOneToOne: false
            referencedRelation: "rentals"
            referencedColumns: ["id"]
          },
        ]
      }
      payment_settings: {
        Row: {
          account_holder: string
          bank_name: string
          created_at: string
          iban: string
          id: string
          updated_at: string
        }
        Insert: {
          account_holder?: string
          bank_name?: string
          created_at?: string
          iban?: string
          id?: string
          updated_at?: string
        }
        Update: {
          account_holder?: string
          bank_name?: string
          created_at?: string
          iban?: string
          id?: string
          updated_at?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          created_at: string
          fleet_id: string | null
          full_name: string | null
          id: string
          is_active: boolean
          phone: string | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          fleet_id?: string | null
          full_name?: string | null
          id: string
          is_active?: boolean
          phone?: string | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          fleet_id?: string | null
          full_name?: string | null
          id?: string
          is_active?: boolean
          phone?: string | null
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "profiles_fleet_id_fkey"
            columns: ["fleet_id"]
            isOneToOne: false
            referencedRelation: "fleets"
            referencedColumns: ["id"]
          },
        ]
      }
      rentals: {
        Row: {
          contract_end_date: string | null
          created_at: string
          daily_rate: number
          deposit_amount: number
          deposit_paid_amount: number
          deposit_paid_at: string | null
          deposit_returned: boolean
          deposit_returned_at: string | null
          deposit_status: string
          end_date: string
          end_km: number | null
          id: string
          monthly_rate: number
          motorcycle_id: string
          notes: string | null
          start_date: string
          start_km: number | null
          status: Database["public"]["Enums"]["rental_status"]
          tenant_id: string
          total_amount: number
          updated_at: string
        }
        Insert: {
          contract_end_date?: string | null
          created_at?: string
          daily_rate: number
          deposit_amount?: number
          deposit_paid_amount?: number
          deposit_paid_at?: string | null
          deposit_returned?: boolean
          deposit_returned_at?: string | null
          deposit_status?: string
          end_date: string
          end_km?: number | null
          id?: string
          monthly_rate?: number
          motorcycle_id: string
          notes?: string | null
          start_date: string
          start_km?: number | null
          status?: Database["public"]["Enums"]["rental_status"]
          tenant_id: string
          total_amount: number
          updated_at?: string
        }
        Update: {
          contract_end_date?: string | null
          created_at?: string
          daily_rate?: number
          deposit_amount?: number
          deposit_paid_amount?: number
          deposit_paid_at?: string | null
          deposit_returned?: boolean
          deposit_returned_at?: string | null
          deposit_status?: string
          end_date?: string
          end_km?: number | null
          id?: string
          monthly_rate?: number
          motorcycle_id?: string
          notes?: string | null
          start_date?: string
          start_km?: number | null
          status?: Database["public"]["Enums"]["rental_status"]
          tenant_id?: string
          total_amount?: number
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "rentals_motorcycle_id_fkey"
            columns: ["motorcycle_id"]
            isOneToOne: false
            referencedRelation: "motorcycles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "rentals_tenant_id_fkey"
            columns: ["tenant_id"]
            isOneToOne: false
            referencedRelation: "tenants"
            referencedColumns: ["id"]
          },
        ]
      }
      service_records: {
        Row: {
          cost: number | null
          created_at: string
          created_by: string | null
          description: string
          id: string
          km_at_service: number
          motorcycle_id: string
          photo_url: string | null
          service_date: string
        }
        Insert: {
          cost?: number | null
          created_at?: string
          created_by?: string | null
          description: string
          id?: string
          km_at_service: number
          motorcycle_id: string
          photo_url?: string | null
          service_date: string
        }
        Update: {
          cost?: number | null
          created_at?: string
          created_by?: string | null
          description?: string
          id?: string
          km_at_service?: number
          motorcycle_id?: string
          photo_url?: string | null
          service_date?: string
        }
        Relationships: [
          {
            foreignKeyName: "service_records_motorcycle_id_fkey"
            columns: ["motorcycle_id"]
            isOneToOne: false
            referencedRelation: "motorcycles"
            referencedColumns: ["id"]
          },
        ]
      }
      tenants: {
        Row: {
          address: string | null
          created_at: string
          email: string | null
          full_name: string
          id: string
          id_number: string | null
          license_number: string | null
          notes: string | null
          phone: string | null
          updated_at: string
          user_id: string | null
        }
        Insert: {
          address?: string | null
          created_at?: string
          email?: string | null
          full_name: string
          id?: string
          id_number?: string | null
          license_number?: string | null
          notes?: string | null
          phone?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Update: {
          address?: string | null
          created_at?: string
          email?: string | null
          full_name?: string
          id?: string
          id_number?: string | null
          license_number?: string | null
          notes?: string | null
          phone?: string | null
          updated_at?: string
          user_id?: string | null
        }
        Relationships: []
      }
      user_locations: {
        Row: {
          accuracy: number | null
          latitude: number
          longitude: number
          updated_at: string
          user_id: string
        }
        Insert: {
          accuracy?: number | null
          latitude: number
          longitude: number
          updated_at?: string
          user_id: string
        }
        Update: {
          accuracy?: number | null
          latitude?: number
          longitude?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      fleet_access_active: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_staff_or_admin: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "staff" | "tenant"
      motorcycle_status: "available" | "rented" | "service" | "inactive"
      payment_status: "pending" | "paid" | "overdue" | "partial"
      rental_status: "active" | "completed" | "cancelled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "staff", "tenant"],
      motorcycle_status: ["available", "rented", "service", "inactive"],
      payment_status: ["pending", "paid", "overdue", "partial"],
      rental_status: ["active", "completed", "cancelled"],
    },
  },
} as const
