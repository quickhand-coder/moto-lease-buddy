import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useSession, useRoles } from "@/lib/auth-hooks";
import { Loader2 } from "lucide-react";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  const { user, loading } = useSession();
  const roles = useRoles(user?.id);
  if (loading || (user && roles.isLoading)) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (!user) return <Navigate to="/auth" replace />;
  const rs = roles.data ?? [];
  if (rs.includes("tenant") && !rs.some((r) => r === "admin" || r === "staff")) {
    return <Navigate to="/my-rentals" replace />;
  }
  return <Navigate to="/dashboard" replace />;
}
