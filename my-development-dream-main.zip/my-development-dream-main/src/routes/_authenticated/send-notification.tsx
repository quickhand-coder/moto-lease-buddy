import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Badge } from "@/components/ui/badge";
import { Loader2, Send, Search } from "lucide-react";
import { toast } from "sonner";
import { listAppUsers } from "@/lib/admin-users.functions";
import { sendBroadcastNotification } from "@/lib/notifications.functions";
import { useSession, useRoles } from "@/lib/auth-hooks";

export const Route = createFileRoute("/_authenticated/send-notification")({
  head: () => ({ meta: [{ title: "Bildirim Gönder — MTY Filo" }] }),
  component: SendNotificationPage,
});

type Target = "single" | "multi" | "all";

function SendNotificationPage() {
  const session = useSession();
  const { data: roles } = useRoles(session.user?.id);
  const isAllowed = !!roles && (roles.includes("admin") || roles.includes("staff"));

  const list = useServerFn(listAppUsers);
  const send = useServerFn(sendBroadcastNotification);

  const [target, setTarget] = useState<Target>("single");
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [search, setSearch] = useState("");
  const [sending, setSending] = useState(false);

  const users = useQuery({
    queryKey: ["app-users-notify"],
    queryFn: () => list(),
    enabled: !!isAllowed,
  });

  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase("tr-TR");
    const rows = users.data ?? [];
    if (!q) return rows;
    return rows.filter((u) =>
      [u.full_name ?? "", u.email ?? "", u.phone ?? ""].some((v) =>
        v.toLocaleLowerCase("tr-TR").includes(q),
      ),
    );
  }, [users.data, search]);

  if (roles && !isAllowed) {
    return <p className="p-6 text-sm text-muted-foreground">Bu sayfaya erişim yetkiniz yok.</p>;
  }

  function toggle(id: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      if (target === "single" && next.size > 1) {
        // keep only the most recent selection
        return new Set([id]);
      }
      return next;
    });
  }

  function onTargetChange(v: string) {
    const t = v as Target;
    setTarget(t);
    if (t === "all") setSelected(new Set());
    if (t === "single" && selected.size > 1) {
      const first = Array.from(selected)[0];
      setSelected(new Set([first]));
    }
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim() || !message.trim()) {
      toast.error("Başlık ve mesaj zorunludur");
      return;
    }
    if (target !== "all" && selected.size === 0) {
      toast.error("En az bir kullanıcı seçin");
      return;
    }
    if (target === "single" && selected.size !== 1) {
      toast.error("Tek kullanıcı için tam olarak bir kişi seçin");
      return;
    }
    setSending(true);
    try {
      const res = await send({
        data: {
          title: title.trim(),
          message: message.trim(),
          target,
          userIds: target === "all" ? undefined : Array.from(selected),
        },
      });
      toast.success(`${res.count} kullanıcıya bildirim gönderildi`);
      setTitle("");
      setMessage("");
      setSelected(new Set());
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="space-y-4 max-w-3xl">
      <div className="flex items-center gap-2">
        <Send className="h-5 w-5" />
        <h1 className="text-2xl font-semibold">Bildirim Gönder</h1>
      </div>

      <form onSubmit={submit} className="space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Alıcı Seçimi</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <RadioGroup value={target} onValueChange={onTargetChange} className="grid gap-2 sm:grid-cols-3">
              <label className="flex items-center gap-2 rounded-md border p-3 cursor-pointer hover:bg-muted/50">
                <RadioGroupItem value="single" />
                <span className="text-sm">Tek kullanıcı</span>
              </label>
              <label className="flex items-center gap-2 rounded-md border p-3 cursor-pointer hover:bg-muted/50">
                <RadioGroupItem value="multi" />
                <span className="text-sm">Birden fazla kullanıcı</span>
              </label>
              <label className="flex items-center gap-2 rounded-md border p-3 cursor-pointer hover:bg-muted/50">
                <RadioGroupItem value="all" />
                <span className="text-sm">Tüm kullanıcılar</span>
              </label>
            </RadioGroup>

            {target !== "all" && (
              <div className="space-y-2">
                <div className="relative">
                  <Search className="pointer-events-none absolute left-2 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    className="pl-8"
                    placeholder="İsim, e-posta veya telefon ara"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                </div>
                <div className="rounded-md border max-h-72 overflow-y-auto divide-y">
                  {users.isLoading ? (
                    <div className="flex justify-center p-4">
                      <Loader2 className="animate-spin text-muted-foreground" />
                    </div>
                  ) : !filtered.length ? (
                    <p className="p-4 text-sm text-muted-foreground text-center">Kullanıcı bulunamadı</p>
                  ) : (
                    filtered.map((u) => {
                      const checked = selected.has(u.id);
                      return (
                        <label
                          key={u.id}
                          className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-muted/50"
                        >
                          <Checkbox checked={checked} onCheckedChange={() => toggle(u.id)} />
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-medium truncate">
                              {u.full_name ?? "İsimsiz"}
                            </div>
                            <div className="text-xs text-muted-foreground truncate">{u.email}</div>
                          </div>
                          <div className="flex flex-wrap gap-1 justify-end">
                            {u.roles.map((r) => (
                              <Badge key={r} variant="secondary" className="text-[10px]">
                                {r}
                              </Badge>
                            ))}
                          </div>
                        </label>
                      );
                    })
                  )}
                </div>
                <div className="text-xs text-muted-foreground">
                  Seçili: {selected.size}
                  {target === "single" && " (yalnızca 1 kişi)"}
                </div>
              </div>
            )}

            {target === "all" && (
              <p className="text-sm text-muted-foreground">
                Sistemdeki tüm kullanıcılara ({users.data?.length ?? "…"}) bildirim gönderilecek.
              </p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Bildirim İçeriği</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="space-y-1.5">
              <Label>Başlık *</Label>
              <Input
                value={title}
                maxLength={120}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Örn: Sistem bakımı"
                required
              />
            </div>
            <div className="space-y-1.5">
              <Label>Mesaj *</Label>
              <Textarea
                value={message}
                rows={5}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Kullanıcılara iletmek istediğiniz mesajı yazın"
                required
              />
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end">
          <Button type="submit" disabled={sending}>
            {sending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            <Send className="h-4 w-4 mr-1" />
            Gönder
          </Button>
        </div>
      </form>
    </div>
  );
}
