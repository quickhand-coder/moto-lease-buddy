import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bike, Users, FileText, AlertTriangle, Plus, ArrowRight, TrendingUp, Wrench, Loader2 } from "lucide-react";
import { differenceInDays, parseISO, format, startOfMonth, subMonths, isSameMonth, parseISO as parseDate } from "date-fns";
import { tr } from "date-fns/locale";
import { AreaChart, Area, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";
import { useSession, useRoles } from "@/lib/auth-hooks";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({ meta: [{ title: "Panel — MTY Filo" }] }),
  component: DashboardPage,
});

function DashboardPage() {
  const { user, loading } = useSession();
  const roles = useRoles(user?.id);
  const rs = roles.data ?? [];
  const isStaff = rs.some((r) => r === "admin" || r === "staff");
  const enabled = !loading && !roles.isLoading && isStaff;

  const stats = useQuery({
    queryKey: ["dashboard-stats"],
    enabled,
    queryFn: async () => {
      const [motos, activeRentals, pendingPayments, tenants, inService] = await Promise.all([
        supabase.from("motorcycles").select("*", { count: "exact", head: true }),
        supabase.from("rentals").select("*", { count: "exact", head: true }).eq("status", "active"),
        supabase.from("payment_schedule").select("*", { count: "exact", head: true }).in("status", ["pending", "overdue"]),
        supabase.from("tenants").select("*", { count: "exact", head: true }),
        supabase.from("motorcycles").select("*", { count: "exact", head: true }).eq("status", "service"),
      ]);
      return {
        motos: motos.count ?? 0,
        activeRentals: activeRentals.count ?? 0,
        pendingPayments: pendingPayments.count ?? 0,
        tenants: tenants.count ?? 0,
        inService: inService.count ?? 0,
      };
    },
  });


  const alerts = useQuery({
    queryKey: ["dashboard-alerts"],
    enabled,
    queryFn: async () => {
      const { data: motos } = await supabase
        .from("motorcycles")
        .select("id, plate, brand, model, insurance_end, inspection_end");
      const { data: rentals } = await supabase
        .from("rentals")
        .select("id, contract_end_date, status, tenants(full_name), motorcycles(plate)")
        .eq("status", "active");
      const today = new Date();
      const items: { type: string; label: string; date: string; days: number; severity: "critical" | "warning" | "notice" }[] = [];
      (motos ?? []).forEach((m) => {
        if (m.insurance_end) {
          const d = differenceInDays(parseISO(m.insurance_end), today);
          if (d <= 30) {
            items.push({
              type: "Sigorta",
              label: `${m.plate} · ${m.brand} ${m.model}`,
              date: m.insurance_end,
              days: d,
              severity: d < 0 ? "critical" : d <= 7 ? "critical" : "warning",
            });
          }
        }
        if (m.inspection_end) {
          const d = differenceInDays(parseISO(m.inspection_end), today);
          if (d <= 30) {
            items.push({
              type: "Muayene",
              label: `${m.plate} · ${m.brand} ${m.model}`,
              date: m.inspection_end,
              days: d,
              severity: d < 0 ? "critical" : d <= 7 ? "critical" : "warning",
            });
          }
        }
      });
      (rentals ?? []).forEach((r) => {
        if (r.contract_end_date) {
          const d = differenceInDays(parseISO(r.contract_end_date), today);
          if (d <= 15) {
            const t = r.tenants as { full_name: string } | null;
            const m = r.motorcycles as { plate: string } | null;
            items.push({
              type: "Sözleşme",
              label: `${t?.full_name ?? ""} · ${m?.plate ?? ""}`,
              date: r.contract_end_date,
              days: d,
              severity: d < 0 ? "critical" : d <= 7 ? "critical" : "warning",
            });
          }
        }
      });
      return items.sort((a, b) => a.days - b.days);
    },
  });

  const motos = useQuery({
    queryKey: ["dashboard-motorcycles"],
    enabled,
    queryFn: async () => {
      const { data, error } = await supabase.from("motorcycles").select("status");
      if (error) throw error;
      const counts: Record<string, number> = {};
      data.forEach((m) => {
        counts[m.status] = (counts[m.status] || 0) + 1;
      });
      return counts;
    },
  });

  const revenue = useQuery({
    queryKey: ["dashboard-revenue"],
    enabled,
    queryFn: async () => {
      const { data } = await supabase
        .from("payment_schedule")
        .select("amount, paid_at, status")
        .eq("status", "paid")
        .not("paid_at", "is", null)
        .order("paid_at", { ascending: true });
      const months: { name: string; amount: number }[] = [];
      for (let i = 5; i >= 0; i--) {
        const d = subMonths(startOfMonth(new Date()), i);
        months.push({ name: format(d, "MMM", { locale: tr }), amount: 0 });
      }
      (data ?? []).forEach((p) => {
        if (!p.paid_at) return;
        const paid = parseISO(p.paid_at);
        months.forEach((m) => {
          if (m.name === format(paid, "MMM", { locale: tr })) {
            m.amount += Number(p.amount || 0);
          }
        });
      });
      return months;
    },
  });

  const upcomingPayments = useQuery({
    queryKey: ["dashboard-upcoming-payments"],
    enabled,
    queryFn: async () => {
      const { data } = await supabase
        .from("payment_schedule")
        .select("id, due_date, amount, status, rentals(tenants(full_name), motorcycles(plate))")
        .in("status", ["pending", "overdue"])
        .order("due_date", { ascending: true })
        .limit(5);
      return (data ?? []).map((p) => {
        const r = p.rentals as {
          tenants: { full_name: string } | null;
          motorcycles: { plate: string } | null;
        } | null;
        return {
          id: p.id,
          dueDate: p.due_date,
          amount: Number(p.amount),
          status: p.status,
          tenant: r?.tenants?.full_name ?? "—",
          plate: r?.motorcycles?.plate ?? "—",
        };
      });
    },
  });

  if (loading || roles.isLoading) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  if (!isStaff) {
    return <Navigate to="/my-rentals" replace />;
  }

  const cards = [

    { label: "Motosikletler", value: stats.data?.motos, icon: Bike, sub: `${stats.data?.inService ?? 0} serviste` },
    { label: "Aktif Kiralar", value: stats.data?.activeRentals, icon: FileText, sub: "şu an kirada" },
    { label: "Bekleyen Ödeme", value: stats.data?.pendingPayments, icon: AlertTriangle, sub: "takipte" },
    { label: "Kiracılar", value: stats.data?.tenants, icon: Users, sub: "kayıtlı" },
  ];

  const statusData = [
    { name: "Müsait", value: motos.data?.available ?? 0, key: "available" },
    { name: "Kirada", value: motos.data?.rented ?? 0, key: "rented" },
    { name: "Serviste", value: motos.data?.service ?? 0, key: "service" },
    { name: "Pasif", value: motos.data?.inactive ?? 0, key: "inactive" },
  ].filter((d) => d.value > 0);

  const statusColors: Record<string, string> = {
    available: "var(--chart-2)",
    rented: "var(--chart-1)",
    service: "var(--chart-4)",
    inactive: "var(--chart-5)",
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Panel</h1>
          <p className="text-sm text-muted-foreground">Operasyonunuzun güncel özetini görün.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild size="sm" variant="outline">
            <Link to="/motorcycles">
              <Plus className="h-4 w-4 mr-1" />
              Motosiklet
            </Link>
          </Button>
          <Button asChild size="sm" variant="outline">
            <Link to="/rentals">
              <Plus className="h-4 w-4 mr-1" />
              Kira
            </Link>
          </Button>
          <Button asChild size="sm" variant="outline">
            <Link to="/tenants">
              <Plus className="h-4 w-4 mr-1" />
              Kiracı
            </Link>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((c) => (
          <Card key={c.label} className="relative overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">{c.label}</CardTitle>
              <div className="rounded-md bg-primary/10 p-1.5">
                <c.icon className="h-4 w-4 text-primary" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold tracking-tight">{c.value ?? "—"}</div>
              <p className="text-xs text-muted-foreground mt-1">{c.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base font-semibold">Aylık Tahsilat</CardTitle>
                <CardDescription>Son 6 ayda ödenen kira ödemeleri</CardDescription>
              </div>
              <div className="rounded-md bg-primary/10 p-1.5">
                <TrendingUp className="h-4 w-4 text-primary" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              {revenue.isLoading ? (
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Yükleniyor...</div>
              ) : revenue.data?.every((d) => d.amount === 0) ? (
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Henüz ödeme kaydı yok.</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={revenue.data} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
                    <defs>
                      <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="var(--color-primary)" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="var(--color-primary)" stopOpacity={0} />
                      </linearGradient>
                    </defs>
                    <XAxis dataKey="name" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
                    <YAxis
                      tick={{ fontSize: 12 }}
                      axisLine={false}
                      tickLine={false}
                      tickFormatter={(v) => `${(v / 1000).toFixed(0)}k`}
                    />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--color-card)",
                        border: "1px solid var(--color-border)",
                        borderRadius: "var(--radius-md)",
                      }}
                      labelStyle={{ color: "var(--color-card-foreground)" }}
                      itemStyle={{ color: "var(--color-card-foreground)" }}
                      formatter={(value: number) => [`${value.toLocaleString("tr-TR")} ₺`, "Tahsilat"]} />
                    <Area type="monotone" dataKey="amount" stroke="var(--color-primary)" strokeWidth={2} fill="url(#colorRevenue)" />
                  </AreaChart>
                </ResponsiveContainer>
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base font-semibold">Araç Durumu</CardTitle>
                <CardDescription>Filo dağılımı</CardDescription>
              </div>
              <div className="rounded-md bg-primary/10 p-1.5">
                <Bike className="h-4 w-4 text-primary" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              {motos.isLoading ? (
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Yükleniyor...</div>
              ) : !statusData.length ? (
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">Araç kaydı yok.</div>
              ) : (
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={statusData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={4}
                      strokeWidth={0}
                    >
                      {statusData.map((entry) => (
                        <Cell key={entry.key} fill={statusColors[entry.key]} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: "var(--color-card)",
                        border: "1px solid var(--color-border)",
                        borderRadius: "var(--radius-md)",
                      }}
                      labelStyle={{ color: "var(--color-card-foreground)" }}
                      itemStyle={{ color: "var(--color-card-foreground)" }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              )}
            </div>
            <div className="flex flex-wrap justify-center gap-3 mt-2">
              {statusData.map((s) => (
                <div key={s.key} className="flex items-center gap-1.5 text-xs">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ backgroundColor: statusColors[s.key] }} />
                  <span className="text-muted-foreground">{s.name}</span>
                  <span className="font-medium">{s.value}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base font-semibold">Yaklaşan Uyarılar</CardTitle>
                <CardDescription>Sigorta, muayene ve sözleşme bitişleri</CardDescription>
              </div>
              <div className="rounded-md bg-destructive/10 p-1.5">
                <AlertTriangle className="h-4 w-4 text-destructive" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {alerts.isLoading ? (
              <p className="text-sm text-muted-foreground">Yükleniyor...</p>
            ) : !alerts.data?.length ? (
              <div className="rounded-md border border-dashed p-6 text-center">
                <p className="text-sm text-muted-foreground">Yaklaşan uyarı yok.</p>
              </div>
            ) : (
              <ul className="space-y-2">
                {alerts.data.slice(0, 6).map((a, i) => (
                  <li key={i} className="flex items-center justify-between gap-3 rounded-lg border p-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Badge variant={a.severity === "critical" ? "destructive" : "outline"} className="text-[10px] uppercase">
                          {a.type}
                        </Badge>
                        <span className="font-medium truncate">{a.label}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{format(parseISO(a.date), "dd MMMM yyyy", { locale: tr })}</p>
                    </div>
                    <div className={`text-sm font-medium whitespace-nowrap ${a.days < 0 ? "text-destructive" : a.days <= 7 ? "text-orange-600" : "text-muted-foreground"}`}>
                      {a.days < 0 ? `${Math.abs(a.days)} gün geçti` : `${a.days} gün kaldı`}
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-base font-semibold">Yaklaşan Ödemeler</CardTitle>
                <CardDescription>Bekleyen ve gecikmiş taksitler</CardDescription>
              </div>
              <div className="rounded-md bg-primary/10 p-1.5">
                <Wrench className="h-4 w-4 text-primary" />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {upcomingPayments.isLoading ? (
              <p className="text-sm text-muted-foreground">Yükleniyor...</p>
            ) : !upcomingPayments.data?.length ? (
              <div className="rounded-md border border-dashed p-6 text-center">
                <p className="text-sm text-muted-foreground">Yaklaşan ödeme yok.</p>
              </div>
            ) : (
              <ul className="space-y-2">
                {upcomingPayments.data.map((p) => (
                  <li key={p.id} className="flex items-center justify-between gap-3 rounded-lg border p-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <Badge variant={p.status === "overdue" ? "destructive" : "outline"} className="text-[10px] uppercase">
                          {p.status === "overdue" ? "Gecikti" : "Bekliyor"}
                        </Badge>
                        <span className="font-medium truncate">{p.tenant}</span>
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">{p.plate} · {format(parseISO(p.dueDate), "dd MMMM yyyy", { locale: tr })}</p>
                    </div>
                    <div className="text-sm font-semibold whitespace-nowrap">{p.amount.toLocaleString("tr-TR")} ₺</div>
                  </li>
                ))}
              </ul>
            )}
            <Button asChild variant="ghost" className="w-full mt-3 text-muted-foreground hover:text-foreground">
              <Link to="/rentals" className="flex items-center justify-center gap-1">
                Tüm kiraları gör
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
