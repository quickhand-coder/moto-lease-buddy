import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Loader2, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { format, parseISO, differenceInDays, addMonths } from "date-fns";
import { EditRentalDialog } from "@/components/edit-rental-dialog";

export const Route = createFileRoute("/_authenticated/rentals")({
  head: () => ({ meta: [{ title: "Kiralar — MTY Filo" }] }),
  component: RentalsPage,
});

const statusLabels: Record<string, string> = {
  active: "Aktif",
  completed: "Tamamlandı",
  cancelled: "İptal",
};

function RentalsPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const { data, isLoading } = useQuery({
    queryKey: ["rentals-list"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("rentals")
        .select(
          "id, start_date, end_date, contract_end_date, monthly_rate, total_amount, deposit_amount, status, motorcycle_id, tenant_id, notes, tenants(full_name), motorcycles(plate, brand, model)",
        )
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Kiralar</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-1" />
              Yeni Kira
            </Button>
          </DialogTrigger>
          <RentalForm
            onDone={() => {
              setOpen(false);
              qc.invalidateQueries();
            }}
          />
        </Dialog>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Kira Listesi</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <Loader2 className="mx-auto my-6 animate-spin" />
          ) : !data?.length ? (
            <p className="text-sm text-muted-foreground">Kira kaydı yok.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Kiracı</TableHead>
                    <TableHead>Motosiklet</TableHead>
                    <TableHead>Başlangıç</TableHead>
                    <TableHead>Bitiş</TableHead>
                    <TableHead>Aylık Ücret</TableHead>
                    <TableHead>Depozito</TableHead>
                    <TableHead>Toplam</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.map((r) => {
                    const t = r.tenants as { full_name: string } | null;
                    const m = r.motorcycles as { plate: string; brand: string; model: string } | null;
                    return (
                      <TableRow key={r.id}>
                        <TableCell className="font-medium">{t?.full_name}</TableCell>
                        <TableCell>
                          {m?.plate} — {m?.brand} {m?.model}
                        </TableCell>
                        <TableCell>{format(parseISO(r.start_date), "dd.MM.yyyy")}</TableCell>
                        <TableCell>{format(parseISO(r.end_date), "dd.MM.yyyy")}</TableCell>
                        <TableCell>{Number(r.monthly_rate).toLocaleString("tr-TR")} ₺</TableCell>
                        <TableCell>{Number(r.deposit_amount).toLocaleString("tr-TR")} ₺</TableCell>
                        <TableCell>{Number(r.total_amount).toLocaleString("tr-TR")} ₺</TableCell>
                        <TableCell>
                          <Badge variant={r.status === "active" ? "default" : "secondary"}>
                            {statusLabels[r.status]}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-1">
                            <Button asChild size="sm" variant="ghost">
                              <Link to="/rentals/$id" params={{ id: r.id }}>
                                Detay
                              </Link>
                            </Button>
                            <EditRentalDialog
                              rental={{
                                id: r.id,
                                motorcycle_id: r.motorcycle_id,
                                tenant_id: r.tenant_id,
                                start_date: r.start_date,
                                end_date: r.end_date,
                                contract_end_date: r.contract_end_date,
                                monthly_rate: Number(r.monthly_rate ?? 0),
                                deposit_amount: Number(r.deposit_amount ?? 0),
                                notes: r.notes,
                              }}
                              iconOnly
                              onDone={() => qc.invalidateQueries()}
                            />
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button
                                  size="icon"
                                  variant="ghost"
                                  className="h-8 w-8 text-destructive hover:text-destructive"
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Kirayı sil?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Bu kira kaydı ve tüm ödeme planı kalıcı olarak silinecek.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>İptal</AlertDialogCancel>
                                  <AlertDialogAction
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                    onClick={async () => {
                                      const { error } = await supabase.from("rentals").delete().eq("id", r.id);
                                      if (error) {
                                        toast.error(error.message);
                                        return;
                                      }
                                      // motosikleti serbest bırak
                                      if (r.motorcycle_id) {
                                        await supabase
                                          .from("motorcycles")
                                          .update({ status: "available" })
                                          .eq("id", r.motorcycle_id);
                                      }
                                      toast.success("Kira silindi");
                                      qc.invalidateQueries();
                                    }}
                                  >
                                    Sil
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function RentalForm({ onDone }: { onDone: () => void }) {
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    motorcycle_id: "",
    tenant_id: "",
    start_date: format(new Date(), "yyyy-MM-dd"),
    months: "1",
    contract_end_date: "",
    monthly_rate: "8500",
    deposit_amount: "",
    notes: "",
  });

  const motos = useQuery({
    queryKey: ["motos-available"],
    queryFn: async () => {
      const { data } = await supabase
        .from("motorcycles")
        .select("id, plate, brand, model, status")
        .in("status", ["available"]);
      return data ?? [];
    },
  });
  const tenants = useQuery({
    queryKey: ["tenants-list"],
    queryFn: async () => {
      const { data } = await supabase.from("tenants").select("id, full_name").order("full_name");
      return data ?? [];
    },
  });

  const months = Math.max(1, parseInt(form.months) || 1);
  const monthlyRate = parseFloat(form.monthly_rate) || 0;
  const total = monthlyRate * months;
  const endDate = format(addMonths(parseISO(form.start_date), months), "yyyy-MM-dd");
  const days = Math.max(1, differenceInDays(parseISO(endDate), parseISO(form.start_date)));
  const dailyRate = total / days;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { data: rental, error } = await supabase
      .from("rentals")
      .insert({
        motorcycle_id: form.motorcycle_id,
        tenant_id: form.tenant_id,
        start_date: form.start_date,
        end_date: endDate,
        contract_end_date: form.contract_end_date || endDate,
        monthly_rate: monthlyRate,
        daily_rate: dailyRate,
        total_amount: total,
        deposit_amount: parseFloat(form.deposit_amount) || 0,
        status: "active",
        notes: form.notes || null,
      })
      .select()
      .single();
    if (error || !rental) {
      setSaving(false);
      toast.error("Kira oluşturulamadı", { description: error?.message });
      return;
    }

    // motosikleti kirada olarak işaretle
    await supabase.from("motorcycles").update({ status: "rented" }).eq("id", form.motorcycle_id);

    // Ödeme planı: kira PEŞİN alınır — ilk ödeme başlangıç günü, sonrakiler ay başında.
    const rows = Array.from({ length: months }, (_, i) => ({
      rental_id: rental.id,
      due_date: format(addMonths(parseISO(form.start_date), i), "yyyy-MM-dd"),
      amount: monthlyRate,
      status: "pending" as const,
    }));
    await supabase.from("payment_schedule").insert(rows);

    setSaving(false);
    toast.success("Kira ve aylık ödeme planı oluşturuldu");
    onDone();
  }

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle>Yeni Kira</DialogTitle>
      </DialogHeader>
      <form onSubmit={submit} className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5 col-span-2">
            <Label>Motosiklet *</Label>
            <select
              required
              className="w-full border rounded h-9 px-2 text-sm bg-background"
              value={form.motorcycle_id}
              onChange={(e) => setForm({ ...form, motorcycle_id: e.target.value })}
            >
              <option value="">Seçiniz — sadece müsait olanlar</option>
              {motos.data?.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.plate} — {m.brand} {m.model}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label>Kiracı *</Label>
            <select
              required
              className="w-full border rounded h-9 px-2 text-sm bg-background"
              value={form.tenant_id}
              onChange={(e) => setForm({ ...form, tenant_id: e.target.value })}
            >
              <option value="">Seçiniz</option>
              {tenants.data?.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.full_name}
                </option>
              ))}
            </select>
          </div>
          <div className="space-y-1.5">
            <Label>Başlangıç *</Label>
            <Input
              type="date"
              required
              value={form.start_date}
              onChange={(e) => setForm({ ...form, start_date: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Kira Süresi (Ay) *</Label>
            <Input
              type="number"
              min="1"
              required
              value={form.months}
              onChange={(e) => setForm({ ...form, months: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Aylık Ücret (₺) *</Label>
            <Input
              type="number"
              step="0.01"
              required
              value={form.monthly_rate}
              onChange={(e) => setForm({ ...form, monthly_rate: e.target.value })}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Depozito (₺)</Label>
            <Input
              type="number"
              step="0.01"
              value={form.deposit_amount}
              onChange={(e) => setForm({ ...form, deposit_amount: e.target.value })}
            />
          </div>
          <div className="space-y-1.5 col-span-2">
            <Label>Sözleşme Bitiş (opsiyonel)</Label>
            <Input
              type="date"
              value={form.contract_end_date}
              onChange={(e) => setForm({ ...form, contract_end_date: e.target.value })}
            />
          </div>
        </div>
        <div className="text-sm text-muted-foreground border rounded p-2 bg-muted/40 space-y-0.5">
          <div>
            Kira bitişi: <strong>{format(parseISO(endDate), "dd.MM.yyyy")}</strong> ({months} ay)
          </div>
          <div>
            Ödemeler her ayın{" "}
            <strong>{parseISO(form.start_date).getDate()}.</strong> günü
          </div>
        </div>
        <DialogFooter>
          <Button type="submit" disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kira Oluştur
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}