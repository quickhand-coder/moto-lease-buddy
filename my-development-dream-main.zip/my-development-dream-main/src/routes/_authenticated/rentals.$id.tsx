import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ArrowLeft, Loader2, Check, RotateCcw, Pencil, Trash2 } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useState } from "react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { EditRentalDialog } from "@/components/edit-rental-dialog";

export const Route = createFileRoute("/_authenticated/rentals/$id")({
  head: () => ({ meta: [{ title: "Kira Detay — MTY Filo" }] }),
  component: RentalDetail,
});

function RentalDetail() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const navigate = useNavigate();

  const rental = useQuery({
    queryKey: ["rental", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("rentals").select("*, tenants(*), motorcycles(*)").eq("id", id).single();
      if (error) throw error;
      return data;
    },
  });

  const payments = useQuery({
    queryKey: ["rental-payments", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("payment_schedule").select("*").eq("rental_id", id).order("due_date");
      if (error) throw error;
      return data;
    },
  });

  if (rental.isLoading || !rental.data) return <div className="flex justify-center py-8"><Loader2 className="animate-spin" /></div>;
  const r = rental.data;
  const t = r.tenants as { full_name: string; phone: string | null; email: string | null } | null;
  const m = r.motorcycles as { plate: string; brand: string; model: string } | null;

  async function markPaid(pid: string, current: string) {
    const next = current === "paid" ? "pending" : "paid";
    const { error } = await supabase.from("payment_schedule").update({
      status: next,
      paid_at: next === "paid" ? new Date().toISOString() : null,
    }).eq("id", pid);
    if (error) { toast.error(error.message); return; }
    toast.success(next === "paid" ? "Ödendi olarak işaretlendi" : "İşaret geri alındı");
    qc.invalidateQueries({ queryKey: ["rental-payments", id] });
  }

  async function toggleDeposit() {
    const { error } = await supabase.from("rentals").update({
      deposit_returned: !r.deposit_returned,
      deposit_returned_at: !r.deposit_returned ? new Date().toISOString() : null,
    }).eq("id", r.id);
    if (error) { toast.error(error.message); return; }
    qc.invalidateQueries({ queryKey: ["rental", id] });
  }

  async function completeRental() {
    const { error } = await supabase.from("rentals").update({ status: "completed" }).eq("id", r.id);
    if (!error) await supabase.from("motorcycles").update({ status: "available" }).eq("id", r.motorcycle_id);
    if (error) { toast.error(error.message); return; }
    toast.success("Kira tamamlandı");
    qc.invalidateQueries();
  }

  const paidTotal = (payments.data ?? []).filter((p) => p.status === "paid").reduce((a, p) => a + Number(p.amount), 0);
  const dueTotal = Number(r.total_amount) - paidTotal;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Button asChild variant="ghost" size="sm"><Link to="/rentals"><ArrowLeft className="h-4 w-4 mr-1" />Geri</Link></Button>
        <h1 className="text-2xl font-semibold">Kira Detayı</h1>
        <div className="ml-auto flex gap-2">
          <EditRentalDialog rental={r} onDone={() => qc.invalidateQueries({ queryKey: ["rental", id] })} />
          {r.status === "active" && <Button size="sm" variant="outline" onClick={completeRental}>Kirayı Tamamla</Button>}
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button size="sm" variant="outline" className="text-destructive hover:text-destructive">
                <Trash2 className="h-4 w-4 mr-1" />Sil
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Kirayı sil?</AlertDialogTitle>
                <AlertDialogDescription>
                  Kira ve tüm ödeme planı kalıcı olarak silinecek.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>İptal</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                  onClick={async () => {
                    const { error } = await supabase.from("rentals").delete().eq("id", r.id);
                    if (error) { toast.error(error.message); return; }
                    if (r.motorcycle_id) {
                      await supabase.from("motorcycles").update({ status: "available" }).eq("id", r.motorcycle_id);
                    }
                    toast.success("Kira silindi");
                    navigate({ to: "/rentals" });
                  }}
                >
                  Sil
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <Card><CardHeader><CardTitle>Kiracı</CardTitle></CardHeader><CardContent className="text-sm space-y-1">
          <div className="font-semibold">{t?.full_name}</div>
          <div className="text-muted-foreground">{t?.phone} · {t?.email}</div>
        </CardContent></Card>
        <Card><CardHeader><CardTitle>Motosiklet</CardTitle></CardHeader><CardContent className="text-sm space-y-1">
          <div className="font-semibold">{m?.plate}</div>
          <div className="text-muted-foreground">{m?.brand} {m?.model}</div>
        </CardContent></Card>
      </div>

      <Card><CardHeader><CardTitle>Kira Bilgileri</CardTitle></CardHeader><CardContent className="grid sm:grid-cols-3 gap-3 text-sm">
        <Info label="Başlangıç" value={format(parseISO(r.start_date), "dd.MM.yyyy")} />
        <Info label="Bitiş" value={format(parseISO(r.end_date), "dd.MM.yyyy")} />
        <Info label="Sözleşme Bitişi" value={r.contract_end_date ? format(parseISO(r.contract_end_date), "dd.MM.yyyy") : "—"} />
        <Info label="Aylık Ücret" value={`${Number(r.monthly_rate ?? 0).toLocaleString("tr-TR")} ₺`} />
        <Info label="Toplam" value={`${Number(r.total_amount).toLocaleString("tr-TR")} ₺`} />
        <Info label="Durum" value={<Badge>{r.status}</Badge>} />
        <Info label="Depozito" value={`${Number(r.deposit_amount).toLocaleString("tr-TR")} ₺`} />
        <Info label="Depozito İade" value={
          <Button size="sm" variant={r.deposit_returned ? "default" : "outline"} onClick={toggleDeposit}>
            {r.deposit_returned ? <><Check className="h-3 w-3 mr-1" />İade Edildi</> : "İade Et"}
          </Button>
        } />
        <Info label="Kalan Ödeme" value={<span className={dueTotal > 0 ? "text-orange-600 font-semibold" : "text-green-600 font-semibold"}>{dueTotal.toLocaleString("tr-TR")} ₺</span>} />
      </CardContent></Card>

      <Card>
        <CardHeader><CardTitle>Ödeme Planı</CardTitle></CardHeader>
        <CardContent>
          {!payments.data?.length ? <p className="text-sm text-muted-foreground">Ödeme planı yok.</p> : (
            <Table>
              <TableHeader><TableRow><TableHead>Vade</TableHead><TableHead>Tutar</TableHead><TableHead>Durum</TableHead><TableHead>Ödeme Tarihi</TableHead><TableHead /></TableRow></TableHeader>
              <TableBody>
                {payments.data.map((p) => {
                  const overdue = p.status === "pending" && parseISO(p.due_date) < new Date();
                  return (
                    <TableRow key={p.id}>
                      <TableCell>{format(parseISO(p.due_date), "dd.MM.yyyy")}</TableCell>
                      <TableCell>{Number(p.amount).toLocaleString("tr-TR")} ₺</TableCell>
                      <TableCell>
                        <Badge variant={p.status === "paid" ? "default" : overdue ? "destructive" : "secondary"}>
                          {p.status === "paid" ? "Ödendi" : overdue ? "Gecikti" : "Bekliyor"}
                        </Badge>
                      </TableCell>
                      <TableCell>{p.paid_at ? format(parseISO(p.paid_at), "dd.MM.yyyy") : "—"}</TableCell>
                      <TableCell>
                        <Button size="sm" variant="ghost" onClick={() => markPaid(p.id, p.status)}>
                          {p.status === "paid" ? <><RotateCcw className="h-3 w-3 mr-1" />Geri Al</> : <><Check className="h-3 w-3 mr-1" />Ödendi</>}
                        </Button>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function Info({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div><div className="text-xs text-muted-foreground">{label}</div><div className="font-medium mt-1">{value}</div></div>
  );
}
