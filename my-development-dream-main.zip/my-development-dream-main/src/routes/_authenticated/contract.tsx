import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { FileText } from "lucide-react";

export const Route = createFileRoute("/_authenticated/contract")({
  head: () => ({
    meta: [
      { title: "Kira Sözleşmesi — MTY Filo Takip Sistemi" },
      { name: "description", content: "MTY Filo motosiklet kira sözleşmesi maddeleri." },
    ],
  }),
  component: ContractPage,
});

type Section = { id: string; title: string; items: { no: string; text: string }[] };

const SECTIONS: Section[] = [
  {
    id: "A",
    title: "A. Kiralama Süresi, Ödeme ve Fesih",
    items: [
      { no: "1.1", text: "Kiralama süresi 6 ay (180 gün) olup, bu süre dolmadan kiralamanın kiracı tarafından herhangi bir sebeple sonlandırılması halinde; son ay kira bedeli ve alınan depozito kesinlikle iade edilmez." },
      { no: "1.2", text: "Kiralamanın sonlandırılabilmesi için kiracının; geçmiş dönem kira borcu, depozito farkı veya herhangi bir bakiye borcunun bulunmaması zorunludur. Borç bulunması halinde sözleşme tek taraflı olarak sonlandırılamaz." },
      { no: "1.3", text: "Kira başlangıç günü, aracın kiracıya teslim edildiği gündür. Kira bedeli, her ay aynı gün ödenir. Kira ödeme gününün geçirilmesi halinde, 500 TL kira gecikme bedeli kiracıya yansıtılır." },
      { no: "1.4", text: "Mevcut asgari ücret artışları ve genel ekonomik koşullar doğrultusunda kira bedelleri, kiraya veren tarafından güncellenebilir." },
      { no: "1.5", text: "Kiracının sözleşme hükümlerine aykırı davranması halinde, kiraya veren sözleşmeyi tek taraflı olarak derhal feshetme ve aracı geri alma hakkına sahiptir. Bu durumda ödenmiş kira bedelleri ve depozito iade edilmez." },
    ],
  },
  {
    id: "B",
    title: "B. Araç Teslim, İade ve Depozito",
    items: [
      { no: "2.1", text: "Kiralanan araç, kiracıya tam sağlam ve çalışır durumda teslim edilir. Araç, kiralama bitiminde aynı şekilde tam sağlam ve çalışır durumda iade edilmelidir." },
      { no: "2.2", text: "Araç kiralama tesliminden itibaren 24 saat içerisinde kiraya verene bildirilmeyen hasar, eksik veya kusurlar kiracı tarafından kabul edilmiş sayılır." },
      { no: "2.3", text: "Araç iade tesliminde kiracı, aracı temiz şekilde teslim etmekle yükümlüdür. Kirli teslim edilmesi halinde, araç yıkama bedeli kiracıya yansıtılır." },
      { no: "2.4", text: "Kiralanan araca ilişkin depozito iadesi; aracın tesliminden sonra yapılacak hasar, borç, ceza ve kullanım kontrollerinin tamamlanmasını takiben, en geç 7 iş günü içerisinde, kiracının bildirmiş olduğu banka hesabına havale/EFT yoluyla yapılır." },
      { no: "2.5", text: "Sözleşmenin tamamlanmaması halinde, kiracı tarafından bulunan ve kiralayanın şartlarına uygun yeni bir kiracıya sözleşmenin devredilmesi durumunda, devir işleminin tamamlanmasını takiben depozito bedeli 7 (yedi) iş günü içinde kiracıya iade edilir." },
    ],
  },
  {
    id: "C",
    title: "C. Kaza, Hasar ve Sigorta",
    items: [
      { no: "3.1", text: "Kiralanan araç ile kaza yapılması ve kazada kiracının haksız taraf olması durumunda; kiracı 3.500 TL sigorta hasarsızlık bozum bedelini kiraya verene ödemekle birlikte, aracın tüm hasar bedellerini de karşılamakla yükümlüdür." },
      { no: "3.2", text: "Kazaya ilişkin sigorta dosyası açılması halinde, sigorta şirketi süreci tamamlanıncaya ve aracın mevcut hasarı giderilinceye kadar kira bedeli işlemeye devam eder. Bu süreçte herhangi bir ikame araç kiraya veren tarafından taahhüt edilmez." },
      { no: "3.3", text: "Kiralayanın veya üçüncü bir şahsın kusuruyla meydana gelen kazalar neticesinde, kiralanan aracın uğrayacağı değer kaybı bedelinin tamamını, kiracı peşinen kabul, beyan ve taahhüt eder." },
    ],
  },
  {
    id: "D",
    title: "D. Bakım, Mekanik ve Teknik Yükümlülükler",
    items: [
      { no: "4.1", text: "Kiralanan aracın bakım başlangıç kilometresi kiracıya bildirilir. Bakım kilometre takibini sağlamak kiracının sorumluluğundadır. Bakım için belirlenen kilometreden ±50 km sapma payı bulunmaktadır. Bu sınırların dışında ve zamanında bakıma getirilmemesi halinde, 4.500 TL araç yıpranma bedeli kiracıdan tahsil edilir." },
      { no: "4.2", text: "Kiracı, her bakımda yapılan işlemleri aracın güncel kilometre fotoğrafı ile birlikte kiraya verene bildirmekle yükümlüdür. Yapılan bakımın bildirilmemesi halinde, bakım yapılmamış kabul edilir." },
      { no: "4.3", text: "Kiralanan aracın motor yağı kontrolü kiracıya aittir. Aracın yağsız kalması sebebiyle oluşacak motor arızaları ve tüm tamir bedelleri kiracıya fatura edilir." },
      { no: "4.4", text: "Kiralanan araca elektronik müdahale (elcik ısıtma vb.) yapılması halinde, elektronik aksamlarda meydana gelen her türlü arıza, tamir ve bakım masrafı kiracıya fatura edilir." },
    ],
  },
  {
    id: "E",
    title: "E. Kullanım Sınırları ve Yasaklar",
    items: [
      { no: "5.1", text: "Kiralanan aracın aylık kilometre sınırı 4.500 km'dir. Bu sınırın aşılması halinde, 1 km dahi aşım olması durumunda 3.000 TL kilometre aşım bedeli, aşım yapılan aya ait kira dönemine yansıtılır." },
      { no: "5.2", text: "Kiralanan araç, sözleşmede adı geçen kiracı dışında üçüncü kişilere kesinlikle kullandırılamaz. Aksi durumda doğacak her türlü hasar, ceza, hukuki ve cezai sorumluluk tamamen kiracıya ait olup, kiraya veren sözleşmeyi tek taraflı ve derhal feshetme hakkına sahiptir." },
      { no: "5.3", text: "Kiralanan aracın alkol, uyuşturucu veya uyarıcı madde etkisi altında, ehliyetsiz veya yetersiz ehliyetle kullanılması halinde meydana gelecek tüm zararlar sigorta kapsamı dışında kalır ve oluşacak her türlü maddi zarar tamamen kiracı tarafından karşılanır." },
      { no: "5.4", text: "Kiralanan araç; amacı dışında, yarış, gösteri, arazi kullanımı, yük taşıma veya üretici tavsiyelerine aykırı şekilde kullanılamaz. Bu şekilde kullanımdan doğacak tüm hasar ve zararlar kiracıya aittir." },
      { no: "5.5", text: "Kiralanan aracın akrobatik hareketler, ani manevralar, makas atma, tehlikeli sürüş veya kullanım amacı dışında kullanıldığının tespit edilmesi halinde, 3.500 TL bedel depozitodan kesinti olarak tahsil edilir. Bu durumun ayrıca hasara yol açması halinde, doğan tüm zararlar ayrıca kiracıya fatura edilir." },
      { no: "5.6", text: "Kiralanan araçların tamamında bulunan çantalar ruhsata işli olup, bu nedenle kiralanan araçlara ikinci bir kişi bindirilmesi kesinlikle yasaktır. Bu kurala aykırı kullanım nedeniyle doğabilecek her türlü ceza, hasar, sigorta dışı kalma durumu ve hukuki sorumluluk tamamen kiracıya aittir." },
      { no: "5.7", text: "Araç, kiralayanın yazılı/onaylı bilgisi olmaksızın şehir dışına veya uzun yola çıkarılamaz. Bu hükme aykırı kullanımın tespiti halinde kiralayan, sözleşmeyi tek taraflı olarak feshetme ve depozitodan kesinti yapma hakkına sahiptir." },
    ],
  },
  {
    id: "F",
    title: "F. Çalınma, Park ve Muhafaza",
    items: [
      { no: "6.1", text: "Kiralanan aracın kiralama süresi içerisinde her ne sebeple olursa olsun çalınması halinde, kusur, ihmal, üçüncü kişi fiili, zorlayıcı sebep veya başka herhangi bir şart aranmaksızın, aracın çalınmasına ilişkin tüm maddi ve hukuki sorumluluk kiracıya aittir. Bu kapsamda sigorta tarafından karşılanmayan bedeller ile doğabilecek her türlü zarar kiracıdan tahsil edilir." },
      { no: "6.2", text: "Kiracı, kiralanan aracı güvenli, kilitli ve uygun park koşullarında muhafaza etmekle yükümlüdür. Uygunsuz park, devrilme, dış etkenler veya yeterli önlem alınmaması nedeniyle oluşacak hasarlar kiracı sorumluluğunda kabul edilir." },
    ],
  },
  {
    id: "G",
    title: "G. Kullanılmama, Servis ve Kira Devamı",
    items: [
      { no: "7.1", text: "Kiralanan aracın uzun süre çalıştırılmaması veya kullanılmaması sonucu oluşabilecek akü bitmesi, lastik deformasyonu, mekanik aksamda meydana gelen problemler ve benzeri arızalar kiracının sorumluluğundadır. Bu kapsamda oluşacak tüm masraflar kiracıya fatura edilir." },
      { no: "7.2", text: "Kiralanan araca ait lastikler, sibop, egzoz, jant ve benzeri sarf malzemeleri kiracının sorumluluğundadır. Lastiklerin 10.000 km dolmadan aşınması, patlaması veya kullanılamaz hale gelmesi durumunda, lastik değişim bedeli kiracıya fatura edilir." },
      { no: "7.3", text: "Kiracı, kiraladığı aracın değişimini talep edemez; herhangi bir sebeple aracı kısmen veya tamamen kullanamaması halinde ücret iadesi veya ücret indirimi talebinde bulunamaz." },
      { no: "7.4", text: "Kiralanan aracın, kararlaştırılan iade gün ve saatinde teslim edilmemesi halinde; gecikilen her gün için günlük kira bedeli işlemeye devam eder." },
      { no: "7.6", text: "Kiralanan aracın iade sırasında kullanılamaz durumda teslim edilmesi halinde, araç kullanıma hazır hale getirilinceye kadar kira bedeli işlemeye devam eder. Bu süreçte oluşacak her türlü masraf kiracıya aittir." },
      { no: "7.7", text: "Kiralanan aracın, serviste, tamirde veya onarımda kaldığı süre boyunca, araç fiilen kullanılamasa dahi kira bedeli işlemeye devam eder." },
    ],
  },
  {
    id: "H",
    title: "H. Masraf, Muayene, Bildirim ve Diğer Hükümler",
    items: [
      { no: "8.1", text: "Kiralanan araca ilişkin arıza, hasar veya olağan dışı durumların kiraya verene zamanında bildirilmemesi nedeniyle oluşan veya büyüyen ilave zararlar ve zincirleme hasarlar kiracıya aittir." },
      { no: "8.2", text: "Kiracı, kiralanan araç ile ilgili yapmış olduğu hiçbir masrafı, kiraya verenin yazılı onayı olmaksızın, kira bedelinden tek taraflı olarak mahsup edemez. Kiracı tarafından yapılan masraflar, ancak kiraya verenin yazılı kabulü bulunması halinde ayrıca değerlendirilir." },
      { no: "8.3", text: "Kiralama süresi içerisinde aracın muayene süresinin dolması halinde, kiracı aracı zamanında muayeneye götürmekle yükümlüdür. Muayene ücreti kiraya veren tarafından karşılanacaktır. Ancak aracın zamanında muayeneye götürülmemesi sebebiyle doğacak idari para cezaları, bağlama, çekici ve otopark ücretleri kiracıya aittir." },
      { no: "8.4", text: "Doğal afet, savaş, grev, yangın, resmi makam kararları ve benzeri mücbir sebeplerden kaynaklanan gecikme, zarar veya aksaklıklardan kiraya veren sorumlu tutulamaz." },
      { no: "8.5", text: "Kiracı; araçta meydana gelen her türlü arıza, kaza, hasar veya olağan dışı durumu derhal kiraya verene bildirmekle yükümlüdür." },
      { no: "8.6", text: "Kiralanan araca ait anahtar, ruhsat fotokopisi, çanta, aparat, aksesuar ve ekipmanların kaybolması, çalınması veya zarar görmesi halinde, yenileme ve temin bedellerinin tamamı kiracıdan tahsil edilir." },
    ],
  },
  {
    id: "I",
    title: "I. Cezalar, Bağlama ve Resmi İşlemler",
    items: [
      { no: "9.1", text: "Kiralama süresi boyunca kiralanan araca yazılan tüm trafik cezaları, otoyol/OGS-HGS geçiş ihlalleri ve her türlü idari para cezaları kiracıya aittir. Bu bedellerin kiraya veren tarafından ödenmesi halinde, ilgili tutarlar kiracıya aynen yansıtılır ve depozitodan mahsup edilir." },
      { no: "9.2", text: "Kiralanan araca ait ruhsat, plaka veya resmi evrakların kaybolması halinde; kiraya veren tarafından yapılması gereken emniyet, noter ve ilgili resmi işlemler ile işçilik ve zaman kaybı karşılığı olarak 2.000 TL işlem ücreti kiracıya yansıtılır. Bu bedel, doğabilecek diğer masraflardan ayrı olarak tahsil edilir." },
      { no: "9.3", text: "Kiracının kusuru veya ihmali sonucu (aracın eksikliklerini kontrol etmemesi de dâhil olmak üzere) kiralanan aracın emniyet birimlerince trafikten men edilmesi veya bağlanması halinde; emniyet, otopark ve ilgili resmi işlemler ile işçilik ve zaman kaybı karşılığı olarak 2.000 TL işlem ücreti kiracıdan tahsil edilir. Bu bedel, doğabilecek çekici, otopark ve diğer masraflara ek olarak uygulanır." },
      { no: "9.4", text: "Kiracı, işbu sözleşmede yer alan tüm maddeleri okuduğunu, anladığını ve kayıtsız şartsız kabul ettiğini beyan eder." },
    ],
  },
];

function ContractPage() {
  return (
    <div className="mx-auto max-w-4xl space-y-4 p-4">
      <div className="flex items-center gap-2">
        <FileText className="h-5 w-5 text-primary" />
        <h1 className="text-2xl font-semibold">Kira Sözleşmesi</h1>
      </div>
      <p className="text-sm text-muted-foreground">
        Aşağıdaki başlıklara tıklayarak sözleşme maddelerini okuyabilirsiniz.
      </p>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">Motosiklet Kira Sözleşmesi Maddeleri</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" className="w-full">
            {SECTIONS.map((s) => (
              <AccordionItem key={s.id} value={s.id}>
                <AccordionTrigger className="text-left">{s.title}</AccordionTrigger>
                <AccordionContent>
                  <ul className="space-y-3">
                    {s.items.map((it) => (
                      <li key={it.no} className="flex gap-3 text-sm leading-relaxed">
                        <span className="min-w-[2.5rem] font-medium text-primary">{it.no}</span>
                        <span className="text-foreground/90">{it.text}</span>
                      </li>
                    ))}
                  </ul>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  );
}