import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, AlertCircle, Plus, Wrench, Image as ImageIcon } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { format, parseISO, differenceInDays } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useEffect, useState } from "react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/my-rentals")({
  head: () => ({ meta: [{ title: "Kiralamalarım — MTY Filo" }] }),
  component: MyRentals,
});

function MyRentals() {
  const qc = useQueryClient();
  const rentals = useQuery({
    queryKey: ["my-rentals"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("rentals")
        .select(
          "*, motorcycles(id, plate, brand, model, current_km, service_interval_km), payment_schedule(*)",
        )
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  useEffect(() => {
    if (!rentals.data) return;
    void generatePaymentNotifications(rentals.data);
  }, [rentals.data]);

  if (rentals.isLoading)
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="animate-spin" />
      </div>
    );
  if (!rentals.data?.length)
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-semibold">Kiralamalarım</h1>
        <Card>
          <CardContent className="py-6 text-sm text-muted-foreground text-center">
            Kayıtlı kiralama bulunmuyor.
          </CardContent>
        </Card>
      </div>
    );

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Kiralamalarım</h1>
      {rentals.data.map((r) => {
        const m = r.motorcycles as {
          id: string;
          plate: string;
          brand: string;
          model: string;
          current_km: number;
          service_interval_km: number;
        } | null;
        const payments = (r.payment_schedule ?? []) as {
          id: string;
          due_date: string;
          amount: number;
          status: string;
          paid_at: string | null;
        }[];
        const pending = payments.filter((p) => p.status !== "paid");
        const overdue = pending.filter((p) => parseISO(p.due_date) < new Date());

        return (
          <Card key={r.id}>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 flex-wrap">
                {m?.plate} — {m?.brand} {m?.model}
                <Badge variant={r.status === "active" ? "default" : "secondary"}>{r.status}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-sm">
              <div className="grid sm:grid-cols-4 gap-3">
                <Info label="Başlangıç" value={format(parseISO(r.start_date), "dd.MM.yyyy")} />
                <Info label="Bitiş" value={format(parseISO(r.end_date), "dd.MM.yyyy")} />
                <Info label="Aylık Ücret" value={`${Number(r.monthly_rate ?? 0).toLocaleString("tr-TR")} ₺`} />
                <Info label="Depozito" value={`${Number(r.deposit_amount).toLocaleString("tr-TR")} ₺`} />
                <Info label="Depozito Durumu" value={r.deposit_returned ? "İade edildi" : "Henüz iade edilmedi"} />
                <Info label="Güncel KM" value={m ? m.current_km.toLocaleString("tr-TR") : "—"} />
                <Info
                  label="Bakım Aralığı"
                  value={m ? `${m.service_interval_km.toLocaleString("tr-TR")} km` : "—"}
                />
              </div>

              {overdue.length > 0 && (
                <div className="border border-destructive/40 bg-destructive/10 text-destructive rounded p-3 flex items-start gap-2">
                  <AlertCircle className="h-4 w-4 mt-0.5" />
                  <div className="text-sm">
                    <strong>{overdue.length} adet geciken ödeme var.</strong> Lütfen en kısa sürede iletişime geçiniz.
                  </div>
                </div>
              )}

              {m && (
                <ServiceBlock
                  motorcycleId={m.id}
                  currentKm={m.current_km}
                  intervalKm={m.service_interval_km}
                  onDone={() => qc.invalidateQueries({ queryKey: ["my-rentals"] })}
                />
              )}

              <div>
                <h3 className="font-medium mb-2">Ödeme Planı</h3>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Vade</TableHead>
                      <TableHead>Tutar</TableHead>
                      <TableHead>Durum</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {payments
                      .sort((a, b) => a.due_date.localeCompare(b.due_date))
                      .map((p) => {
                        const isOverdue = p.status !== "paid" && parseISO(p.due_date) < new Date();
                        const days = differenceInDays(parseISO(p.due_date), new Date());
                        return (
                          <TableRow key={p.id}>
                            <TableCell>
                              {format(parseISO(p.due_date), "dd.MM.yyyy")}
                              {p.status !== "paid" && days >= 0 && days <= 3 && (
                                <span className="ml-2 text-orange-600 text-xs">({days} gün kaldı)</span>
                              )}
                            </TableCell>
                            <TableCell>{Number(p.amount).toLocaleString("tr-TR")} ₺</TableCell>
                            <TableCell>
                              <Badge
                                variant={p.status === "paid" ? "default" : isOverdue ? "destructive" : "secondary"}
                              >
                                {p.status === "paid" ? "Ödendi" : isOverdue ? "Gecikti" : "Bekliyor"}
                              </Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}

function Info({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div>
      <div className="text-xs text-muted-foreground">{label}</div>
      <div className="font-medium mt-0.5">{value}</div>
    </div>
  );
}

const SERVICE_TYPES = [
  "Yağ Değişimi",
  "Kayış Değişimi",
  "Ön Balata Değişimi",
  "Arka Balata Değişimi",
  "Müşür Değişimi",
  "Ön Lastik Değişimi",
  "Arka Lastik Değişimi",
  "Motor Yapıldı",
] as const;

type ServiceRecord = {
  id: string;
  service_date: string;
  km_at_service: number;
  description: string | null;
  photo_url: string | null;
};

function recordHasType(rec: ServiceRecord, type: string): boolean {
  return (rec.description ?? "").includes(type);
}

function computeNextService(records: ServiceRecord[], intervalKm: number): { km: number; label: string } {
  // Sort ascending by km
  const sorted = [...records].sort((a, b) => a.km_at_service - b.km_at_service);
  const lastMotor = [...sorted].reverse().find((r) => recordHasType(r, "Motor Yapıldı"));
  const oilOrRodaj = sorted.filter(
    (r) => recordHasType(r, "Yağ Değişimi") || recordHasType(r, "Rodaj"),
  );

  if (lastMotor) {
    const mk = lastMotor.km_at_service;
    const afterMotor = oilOrRodaj.filter((r) => r.km_at_service >= mk);
    if (afterMotor.length === 0) return { km: mk + 500, label: "Rodaj Bakımı" };
    if (afterMotor.length === 1) return { km: mk + 2000, label: "Yağ Değişimi" };
    const latest = afterMotor[afterMotor.length - 1];
    return { km: latest.km_at_service + 2000, label: "Yağ Değişimi" };
  }

  if (oilOrRodaj.length > 0) {
    const latest = oilOrRodaj[oilOrRodaj.length - 1];
    return { km: latest.km_at_service + 2000, label: "Yağ Değişimi" };
  }

  return { km: intervalKm, label: "Yağ Değişimi" };
}

function ServiceBlock({
  motorcycleId,
  currentKm,
  intervalKm,
  onDone,
}: {
  motorcycleId: string;
  currentKm: number;
  intervalKm: number;
  onDone: () => void;
}) {
  const qc = useQueryClient();
  const services = useQuery({
    queryKey: ["my-services", motorcycleId],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("service_records")
        .select("*")
        .eq("motorcycle_id", motorcycleId)
        .order("service_date", { ascending: false });
      if (error) throw error;
      return (data ?? []) as ServiceRecord[];
    },
  });

  const lastServiceKm =
    services.data && services.data.length > 0
      ? Math.max(...services.data.map((s) => s.km_at_service))
      : 0;
  const next = computeNextService(services.data ?? [], intervalKm);
  const nextServiceKm = next.km;
  const remainingKm = Math.max(0, nextServiceKm - currentKm);
  const overdue = currentKm >= nextServiceKm;

  return (
    <div className="rounded-lg border p-4 space-y-3 bg-muted/30">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 font-medium">
          <Wrench className="h-4 w-4" />
          Bakım Takibi
        </div>
        <AddServiceDialog
          motorcycleId={motorcycleId}
          currentKm={currentKm}
          lastServiceKm={lastServiceKm}
          onDone={() => {
            qc.invalidateQueries({ queryKey: ["my-services", motorcycleId] });
            onDone();
          }}
        />

      </div>

      <div className="grid sm:grid-cols-3 gap-3 text-sm">
        <Info label="Son Bakım KM" value={lastServiceKm > 0 ? lastServiceKm.toLocaleString("tr-TR") : "—"} />
        <Info
          label="Sonraki Bakım"
          value={
            <span className={overdue ? "text-destructive font-semibold" : ""}>
              {nextServiceKm.toLocaleString("tr-TR")} km
              <span className="text-xs text-muted-foreground font-normal ml-1">({next.label})</span>
            </span>
          }
        />
        <Info
          label="Kalan"
          value={
            overdue ? (
              <span className="text-destructive font-semibold">
                {(currentKm - nextServiceKm).toLocaleString("tr-TR")} km geçildi
              </span>
            ) : (
              <span className={remainingKm <= 200 ? "text-orange-600 font-semibold" : ""}>
                {remainingKm.toLocaleString("tr-TR")} km
              </span>
            )
          }
        />
      </div>

      <div>
        <h4 className="text-sm font-medium mb-2">Bakım Geçmişi</h4>
        {services.isLoading ? (
          <Loader2 className="animate-spin" />
        ) : !services.data?.length ? (
          <p className="text-xs text-muted-foreground">Henüz bakım kaydı yok. İlk bakımı eklemek için yukarıdaki butonu kullanın.</p>
        ) : (
          <ul className="divide-y">
            {services.data.map((s) => (
              <li key={s.id} className="py-2 flex gap-3 items-start">
                <ServicePhoto path={s.photo_url} />
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">{s.description}</div>
                  <div className="text-xs text-muted-foreground">
                    {format(parseISO(s.service_date), "dd.MM.yyyy")} · {s.km_at_service.toLocaleString("tr-TR")} km
                  </div>
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function ServicePhoto({ path }: { path: string | null }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!path) return;
    let active = true;
    supabase.storage
      .from("motorcycle-photos")
      .createSignedUrl(path, 3600)
      .then(({ data }) => {
        if (active && data?.signedUrl) setUrl(data.signedUrl);
      });
    return () => {
      active = false;
    };
  }, [path]);
  if (!path) {
    return (
      <div className="w-14 h-14 rounded bg-muted flex items-center justify-center text-muted-foreground shrink-0">
        <ImageIcon className="h-4 w-4" />
      </div>
    );
  }
  return (
    <a href={url ?? "#"} target="_blank" rel="noreferrer" className="shrink-0">
      {url ? (
        <img src={url} alt="Bakım" className="w-14 h-14 object-cover rounded" />
      ) : (
        <div className="w-14 h-14 rounded bg-muted animate-pulse" />
      )}
    </a>
  );
}

function AddServiceDialog({
  motorcycleId,
  currentKm,
  lastServiceKm,
  onDone,
}: {
  motorcycleId: string;
  currentKm: number;
  lastServiceKm: number;
  onDone: () => void;
}) {

  const [open, setOpen] = useState(false);
  const [kmStr, setKmStr] = useState(String(currentKm || ""));
  const [selected, setSelected] = useState<string[]>([]);
  const [note, setNote] = useState("");
  const [photo, setPhoto] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  const today = format(new Date(), "yyyy-MM-dd");

  function toggleType(type: string) {
    setSelected((prev) => (prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]));
  }

  function resetForm() {
    setKmStr("");
    setSelected([]);
    setNote("");
    setPhoto(null);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (selected.length === 0 && !note.trim()) {
      toast.error("En az bir bakım türü seçin veya not ekleyin");
      return;
    }
    const km = parseInt(kmStr);
    if (Number.isNaN(km)) {
      toast.error("KM bilgisi geçersiz");
      return;
    }
    if (lastServiceKm > 0 && km < lastServiceKm) {
      toast.error(
        `KM son bakım kilometresinden (${lastServiceKm.toLocaleString("tr-TR")} km) düşük olamaz`,
      );
      return;
    }
    setSaving(true);


    let photo_url: string | null = null;
    if (photo) {
      const ext = photo.name.split(".").pop() || "jpg";
      const path = `service/${motorcycleId}/${Date.now()}.${ext}`;
      const up = await supabase.storage.from("motorcycle-photos").upload(path, photo, { upsert: false });
      if (up.error) {
        setSaving(false);
        toast.error("Fotoğraf yüklenemedi", { description: up.error.message });
        return;
      }
      photo_url = up.data.path;
    }

    const description = [
      selected.join(", "),
      note.trim() ? `Not: ${note.trim()}` : "",
    ]
      .filter(Boolean)
      .join("\n\n");

    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from("service_records").insert({
      motorcycle_id: motorcycleId,
      service_date: today,
      km_at_service: km,
      description,
      photo_url,
      created_by: userData.user?.id ?? null,
    });
    if (!error && km > currentKm) {
      await supabase.from("motorcycles").update({ current_km: km }).eq("id", motorcycleId).lt("current_km", km);
    }
    setSaving(false);
    if (error) {
      toast.error("Kaydedilemedi", { description: error.message });
      return;
    }
    toast.success("Bakım kaydı eklendi");
    setOpen(false);
    resetForm();
    onDone();
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(o) => {
        setOpen(o);
        if (!o) resetForm();
        else setKmStr(String(currentKm || ""));
      }}
    >
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="h-4 w-4 mr-1" />
          Yeni Bakım Ekle
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Yeni Bakım Kaydı</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Tarih</Label>
              <Input type="date" value={today} readOnly disabled />
            </div>
            <div className="space-y-1.5">
              <Label>KM *</Label>
              <Input
                type="number"
                required
                inputMode="numeric"
                value={kmStr}
                onChange={(e) => setKmStr(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Bakım Türü (birden fazla seçebilirsiniz)</Label>
            <div className="rounded-md border divide-y">
              {SERVICE_TYPES.map((type) => {
                const checked = selected.includes(type);
                return (
                  <label
                    key={type}
                    className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-muted/50"
                  >
                    <Checkbox checked={checked} onCheckedChange={() => toggleType(type)} />
                    <span className="text-sm">{type}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Not Ekle</Label>
            <Textarea
              rows={3}
              placeholder="Harici yapılan işlemleri lütfen buraya yazınız."
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Fotoğraf (opsiyonel)</Label>
            <Input type="file" accept="image/*" onChange={(e) => setPhoto(e.target.files?.[0] ?? null)} />
          </div>

          <DialogFooter>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

type RentalRow = {
  id: string;
  motorcycles: { plate: string } | null;
  payment_schedule: { id: string; due_date: string; amount: number; status: string }[] | null;
};

async function generatePaymentNotifications(rows: RentalRow[]) {
  const { data: userData } = await supabase.auth.getUser();
  const userId = userData.user?.id;
  if (!userId) return;

  const now = new Date();
  const toNotify: {
    rentalId: string;
    plate: string;
    paymentId: string;
    dueDate: string;
    amount: number;
    overdue: boolean;
  }[] = [];
  rows.forEach((r) => {
    (r.payment_schedule ?? []).forEach((p) => {
      if (p.status === "paid") return;
      const days = differenceInDays(parseISO(p.due_date), now);
      if (days <= 3) {
        toNotify.push({
          rentalId: r.id,
          plate: r.motorcycles?.plate ?? "",
          paymentId: p.id,
          dueDate: p.due_date,
          amount: Number(p.amount),
          overdue: days < 0,
        });
      }
    });
  });
  if (toNotify.length === 0) return;

  const relatedIds = toNotify.map((n) => n.paymentId);
  const { data: existing } = await supabase
    .from("notifications")
    .select("related_id")
    .eq("user_id", userId)
    .in("related_id", relatedIds);
  const existingSet = new Set((existing ?? []).map((e) => e.related_id));

  const newRows = toNotify
    .filter((n) => !existingSet.has(n.paymentId))
    .map((n) => ({
      user_id: userId,
      type: n.overdue ? "payment_overdue" : "payment_due",
      title: n.overdue ? "Geciken ödeme" : "Ödeme bekleniyor",
      message: `${n.plate} kirası için ${format(parseISO(n.dueDate), "dd.MM.yyyy")} vadeli ${n.amount.toLocaleString("tr-TR")} ₺ tutarındaki ödemeniz ${
        n.overdue ? "gecikmiştir" : "yaklaşmaktadır"
      }.`,
      related_id: n.paymentId,
    }));
  if (newRows.length) await supabase.from("notifications").insert(newRows);
}