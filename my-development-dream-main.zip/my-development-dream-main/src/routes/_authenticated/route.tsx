import { createFileRoute, Outlet, Navigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useSession, useRoles } from "@/lib/auth-hooks";
import { AppShell } from "@/components/app-shell";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  component: AuthedLayout,
});

function AuthedLayout() {
  const { user, loading } = useSession();
  const roles = useRoles(user?.id);
  const [fleetChecked, setFleetChecked] = useState(false);
  const [fleetBlocked, setFleetBlocked] = useState(false);

  useEffect(() => {
    if (!user) {
      setFleetChecked(true);
      return;
    }
    supabase
      .rpc("fleet_access_active", { _user_id: user.id })
      .then(({ data, error }) => {
        if (error) {
          setFleetChecked(true);
          return;
        }
        if (data === false) {
          setFleetBlocked(true);
          toast.error("Filo erişiminiz kapalı veya süresi dolmuş");
          supabase.auth.signOut();
        }
        setFleetChecked(true);
      });
  }, [user]);

  if (loading || (user && roles.isLoading) || !fleetChecked) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }
  if (!user || fleetBlocked) return <Navigate to="/auth" replace />;

  return (
    <AppShell roles={roles.data ?? []}>
      <Outlet />
    </AppShell>
  );
}
