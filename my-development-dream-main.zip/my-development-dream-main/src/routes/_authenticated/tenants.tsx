import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Loader2, UserCheck, Pencil, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/tenants")({
  head: () => ({ meta: [{ title: "Kiracılar — MTY Filo" }] }),
  component: TenantsPage,
});

function TenantsPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const { data, isLoading } = useQuery({
    queryKey: ["tenants"],
    queryFn: async () => {
      const { data, error } = await supabase.from("tenants").select("*").order("full_name");
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Kiracılar</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1" />Yeni Kiracı</Button></DialogTrigger>
          <TenantForm onDone={() => { setOpen(false); qc.invalidateQueries({ queryKey: ["tenants"] }); }} />
        </Dialog>
      </div>
      <Card>
        <CardHeader><CardTitle>Kiracı Listesi</CardTitle></CardHeader>
        <CardContent>
          {isLoading ? <Loader2 className="animate-spin mx-auto my-6" /> : !data?.length ? (
            <p className="text-sm text-muted-foreground">Kiracı yok.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead>Ad Soyad</TableHead><TableHead>Telefon</TableHead><TableHead>E-posta</TableHead>
                  <TableHead>Kimlik</TableHead><TableHead>Ehliyet</TableHead><TableHead>Hesap</TableHead>
                  <TableHead className="text-right">İşlemler</TableHead>
                </TableRow></TableHeader>
                <TableBody>
                  {data.map((t) => (
                    <TableRow key={t.id}>
                      <TableCell className="font-medium">{t.full_name}</TableCell>
                      <TableCell>{t.phone ?? "—"}</TableCell>
                      <TableCell>{t.email ?? "—"}</TableCell>
                      <TableCell>{t.id_number ?? "—"}</TableCell>
                      <TableCell>{t.license_number ?? "—"}</TableCell>
                      <TableCell>
                        {t.user_id ? <Badge variant="default" className="gap-1"><UserCheck className="h-3 w-3" />Bağlı</Badge> : <Badge variant="outline">Bağlı değil</Badge>}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <EditTenantDialog tenant={t} onDone={() => qc.invalidateQueries({ queryKey: ["tenants"] })} />
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Kiracıyı sil?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  <strong>{t.full_name}</strong> kalıcı olarak silinecek. Aktif kirası varsa silme başarısız olur.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>İptal</AlertDialogCancel>
                                <AlertDialogAction
                                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  onClick={async () => {
                                    const { error } = await supabase.from("tenants").delete().eq("id", t.id);
                                    if (error) { toast.error(error.message); return; }
                                    toast.success("Kiracı silindi");
                                    qc.invalidateQueries({ queryKey: ["tenants"] });
                                  }}
                                >
                                  Sil
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

type Tenant = {
  id: string;
  full_name: string;
  phone: string | null;
  email: string | null;
  id_number: string | null;
  address: string | null;
  license_number: string | null;
  notes: string | null;
};

function EditTenantDialog({ tenant, onDone }: { tenant: Tenant; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    full_name: tenant.full_name,
    phone: tenant.phone ?? "",
    email: tenant.email ?? "",
    id_number: tenant.id_number ?? "",
    address: tenant.address ?? "",
    license_number: tenant.license_number ?? "",
    notes: tenant.notes ?? "",
  });
  const [saving, setSaving] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase.from("tenants").update({
      full_name: form.full_name.trim(),
      phone: form.phone || null,
      email: form.email || null,
      id_number: form.id_number || null,
      address: form.address || null,
      license_number: form.license_number || null,
      notes: form.notes || null,
    }).eq("id", tenant.id);
    setSaving(false);
    if (error) { toast.error("Kaydedilemedi", { description: error.message }); return; }
    toast.success("Güncellendi");
    setOpen(false);
    onDone();
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="icon" variant="ghost" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Kiracıyı Düzenle</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5 col-span-2"><Label>Ad Soyad *</Label><Input required value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Telefon</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>E-posta</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>T.C. / Kimlik No</Label><Input value={form.id_number} onChange={(e) => setForm({ ...form, id_number: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Ehliyet No</Label><Input value={form.license_number} onChange={(e) => setForm({ ...form, license_number: e.target.value })} /></div>
            <div className="space-y-1.5 col-span-2"><Label>Adres</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div className="space-y-1.5 col-span-2"><Label>Notlar</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <DialogFooter><Button type="submit" disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function TenantForm({ onDone }: { onDone: () => void }) {
  const [form, setForm] = useState({ full_name: "", phone: "", email: "", id_number: "", address: "", license_number: "", notes: "" });
  const [saving, setSaving] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase.from("tenants").insert({
      full_name: form.full_name.trim(),
      phone: form.phone || null,
      email: form.email || null,
      id_number: form.id_number || null,
      address: form.address || null,
      license_number: form.license_number || null,
      notes: form.notes || null,
    });
    setSaving(false);
    if (error) { toast.error("Kaydedilemedi", { description: error.message }); return; }
    toast.success("Kiracı eklendi");
    onDone();
  }
  return (
    <DialogContent className="max-w-lg">
      <DialogHeader><DialogTitle>Yeni Kiracı</DialogTitle></DialogHeader>
      <form onSubmit={submit} className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1.5 col-span-2"><Label>Ad Soyad *</Label><Input required value={form.full_name} onChange={(e) => setForm({ ...form, full_name: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Telefon</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>E-posta</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>T.C. / Kimlik No</Label><Input value={form.id_number} onChange={(e) => setForm({ ...form, id_number: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Ehliyet No</Label><Input value={form.license_number} onChange={(e) => setForm({ ...form, license_number: e.target.value })} /></div>
          <div className="space-y-1.5 col-span-2"><Label>Adres</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
          <div className="space-y-1.5 col-span-2"><Label>Notlar</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
        </div>
        <p className="text-xs text-muted-foreground">Kiracının giriş yapabilmesi için Kullanıcılar sayfasından hesap oluşturun ve bu kiracıya bağlayın.</p>
        <DialogFooter><Button type="submit" disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet</Button></DialogFooter>
      </form>
    </DialogContent>
  );
}