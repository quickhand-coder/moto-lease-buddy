import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, CheckCheck, Trash2 } from "lucide-react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/notifications")({
  head: () => ({ meta: [{ title: "Bildirimler — Kira Takip" }] }),
  component: NotificationsPage,
});

function NotificationsPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["notifications-all"],
    queryFn: async () => {
      const { data, error } = await supabase.from("notifications").select("*").order("created_at", { ascending: false }).limit(200);
      if (error) throw error;
      return data;
    },
  });

  async function markAllRead() {
    const { data: userData } = await supabase.auth.getUser();
    if (!userData.user) return;
    const { error } = await supabase.from("notifications").update({ read: true }).eq("user_id", userData.user.id).eq("read", false);
    if (error) { toast.error(error.message); return; }
    toast.success("Tüm bildirimler okundu olarak işaretlendi");
    qc.invalidateQueries({ queryKey: ["notifications-all"] });
    qc.invalidateQueries({ queryKey: ["notifications", "unread-count"] });
  }

  async function markRead(id: string) {
    await supabase.from("notifications").update({ read: true }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["notifications-all"] });
    qc.invalidateQueries({ queryKey: ["notifications", "unread-count"] });
  }

  async function remove(id: string) {
    const { error } = await supabase.from("notifications").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Bildirim silindi");
    qc.invalidateQueries({ queryKey: ["notifications-all"] });
    qc.invalidateQueries({ queryKey: ["notifications", "unread-count"] });
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Bildirimler</h1>
        <Button size="sm" variant="outline" onClick={markAllRead}><CheckCheck className="h-4 w-4 mr-1" />Tümünü Okundu İşaretle</Button>
      </div>
      <Card>
        <CardHeader><CardTitle>Son Bildirimler</CardTitle></CardHeader>
        <CardContent>
          {isLoading ? <Loader2 className="mx-auto my-6 animate-spin" /> : !data?.length ? (
            <p className="text-sm text-muted-foreground">Bildirim yok.</p>
          ) : (
            <ul className="divide-y">
              {data.map((n) => (
                <li key={n.id} className={`py-3 flex items-start justify-between gap-2 ${!n.read ? "bg-muted/30 -mx-6 px-6" : ""}`}>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{n.title}</span>
                      {!n.read && <Badge variant="destructive" className="text-[10px] h-4 px-1">yeni</Badge>}
                    </div>
                    <div className="text-sm text-muted-foreground">{n.message}</div>
                    <div className="text-xs text-muted-foreground mt-0.5">{format(parseISO(n.created_at), "dd.MM.yyyy HH:mm")}</div>
                  </div>
                  <div className="flex items-center gap-1 shrink-0">
                    {!n.read && <Button size="sm" variant="ghost" onClick={() => markRead(n.id)}>Okundu</Button>}
                    <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive" onClick={() => remove(n.id)}>
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}