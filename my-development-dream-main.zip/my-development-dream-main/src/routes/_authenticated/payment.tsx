import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPaymentSettings } from "@/lib/payment-settings.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, Copy, Building2, User, CreditCard, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/payment")({
  head: () => ({ meta: [{ title: "Ödeme Yap — Kira Takip" }] }),
  component: PaymentPage,
});

function PaymentPage() {
  const fetchSettings = useServerFn(getPaymentSettings);
  const { data, isLoading } = useQuery({
    queryKey: ["payment-settings"],
    queryFn: () => fetchSettings(),
  });

  function copy(v: string) {
    if (!v) return;
    navigator.clipboard.writeText(v).then(() => toast.success("Kopyalandı"));
  }

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  const empty = !data?.bank_name && !data?.account_holder && !data?.iban;

  return (
    <div className="space-y-4 max-w-2xl">
      <div>
        <h1 className="text-2xl font-semibold">Ödeme Yap</h1>
        <p className="text-sm text-muted-foreground">Aşağıdaki hesap bilgilerine ödeme yapabilirsiniz.</p>
      </div>

      {empty ? (
        <Card>
          <CardContent className="py-8 text-sm text-muted-foreground text-center">
            Henüz ödeme bilgileri tanımlanmamış. Lütfen yönetici ile iletişime geçin.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>Hesap Bilgileri</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Row icon={<Building2 className="h-4 w-4" />} label="Banka Adı" value={data?.bank_name ?? ""} onCopy={copy} />
            <Row icon={<User className="h-4 w-4" />} label="Hesap Sahibi" value={data?.account_holder ?? ""} onCopy={copy} />
            <Row icon={<CreditCard className="h-4 w-4" />} label="IBAN" value={data?.iban ?? ""} onCopy={copy} mono />
          </CardContent>
        </Card>
      )}

      <div className="flex items-start gap-2 rounded-md border border-amber-500/40 bg-amber-500/10 p-3 text-sm">
        <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
        <div>
          <div className="font-medium">Uyarı</div>
          <div className="text-muted-foreground">Lütfen açıklama kısmını boş bırakınız.</div>
        </div>
      </div>
    </div>
  );
}

function Row({
  icon,
  label,
  value,
  onCopy,
  mono,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  onCopy: (v: string) => void;
  mono?: boolean;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-md border p-3">
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
          {icon}
          {label}
        </div>
        <div className={`mt-1 truncate ${mono ? "font-mono text-sm" : "text-sm"}`}>{value || "—"}</div>
      </div>
      <Button size="sm" variant="ghost" onClick={() => onCopy(value)} disabled={!value}>
        <Copy className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}
