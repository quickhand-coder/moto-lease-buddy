import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2, MapPin } from "lucide-react";
import { useEffect, useMemo, useRef } from "react";
import { format, parseISO } from "date-fns";

export const Route = createFileRoute("/_authenticated/locations")({
  head: () => ({ meta: [{ title: "Konumlar — MTY Filo" }] }),
  component: LocationsPage,
});

type LocationRow = {
  user_id: string;
  latitude: number;
  longitude: number;
  accuracy: number | null;
  updated_at: string;
};

type TenantWithMoto = {
  user_id: string | null;
  full_name: string;
  plate: string | null;
  brand: string | null;
  model: string | null;
};

function LocationsPage() {
  const locations = useQuery({
    queryKey: ["user-locations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("user_locations")
        .select("*")
        .order("updated_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as LocationRow[];
    },
    refetchInterval: 60_000,
  });

  const tenants = useQuery({
    queryKey: ["locations-tenants"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("tenants")
        .select("user_id, full_name, rentals!inner(status, motorcycles(plate, brand, model))")
        .eq("rentals.status", "active");
      if (error) throw error;
      const rows: TenantWithMoto[] = (data ?? []).map((t) => {
        const rentals = (t.rentals ?? []) as Array<{
          motorcycles: { plate: string; brand: string; model: string } | null;
        }>;
        const m = rentals[0]?.motorcycles ?? null;
        return {
          user_id: t.user_id,
          full_name: t.full_name,
          plate: m?.plate ?? null,
          brand: m?.brand ?? null,
          model: m?.model ?? null,
        };
      });
      return rows;
    },
  });

  const merged = useMemo(() => {
    if (!locations.data) return [];
    const byUser = new Map<string, TenantWithMoto>();
    (tenants.data ?? []).forEach((t) => {
      if (t.user_id) byUser.set(t.user_id, t);
    });
    return locations.data.map((loc) => ({
      ...loc,
      tenant: byUser.get(loc.user_id) ?? null,
    }));
  }, [locations.data, tenants.data]);

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold flex items-center gap-2">
          <MapPin className="h-6 w-6" />
          Kullanıcı Konumları
        </h1>
        <p className="text-sm text-muted-foreground">
          Kullanıcıların uygulamaya son giriş yaptıkları konum harita üzerinde plaka bilgileriyle gösterilir.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Harita</CardTitle>
        </CardHeader>
        <CardContent>
          {locations.isLoading ? (
            <div className="flex justify-center py-8">
              <Loader2 className="animate-spin" />
            </div>
          ) : !merged.length ? (
            <p className="text-sm text-muted-foreground py-4">
              Henüz konum bilgisi paylaşan bir kullanıcı yok. Kullanıcılar giriş yaptığında tarayıcı konum izni ister,
              onay verildiğinde son konumları burada görünür.
            </p>
          ) : (
            <LeafletMap points={merged} />
          )}
        </CardContent>
      </Card>

      {!!merged.length && (
        <Card>
          <CardHeader>
            <CardTitle>Liste</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="divide-y">
              {merged.map((p) => (
                <li key={p.user_id} className="py-2 flex items-center justify-between gap-3 text-sm">
                  <div>
                    <div className="font-medium">{p.tenant?.full_name ?? "Bilinmeyen kullanıcı"}</div>
                    <div className="text-xs text-muted-foreground">
                      {p.tenant?.plate ? `${p.tenant.plate} — ${p.tenant.brand} ${p.tenant.model}` : "Aktif kira yok"}
                    </div>
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    <div>{format(parseISO(p.updated_at), "dd.MM.yyyy HH:mm")}</div>
                    <div className="font-mono">
                      {p.latitude.toFixed(4)}, {p.longitude.toFixed(4)}
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

type MergedPoint = LocationRow & { tenant: TenantWithMoto | null };

function LeafletMap({ points }: { points: MergedPoint[] }) {
  const containerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    let cleanup = () => {};
    let cancelled = false;
    (async () => {
      if (!containerRef.current || points.length === 0) return;
      const L = (await import("leaflet")).default;
      if (cancelled || !containerRef.current) return;

      // Fix default icon paths (marker assets served from unpkg)
      // @ts-expect-error _getIconUrl override for bundled builds
      delete L.Icon.Default.prototype._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
        iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
        shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
      });

      const map = L.map(containerRef.current, { scrollWheelZoom: true }).setView(
        [points[0].latitude, points[0].longitude],
        11,
      );
      L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        maxZoom: 19,
      }).addTo(map);

      const group = L.featureGroup();
      points.forEach((p) => {
        const plate = p.tenant?.plate ?? "—";
        const name = p.tenant?.full_name ?? "Bilinmeyen kullanıcı";
        const marker = L.marker([p.latitude, p.longitude]).bindPopup(
          `<div style="font-family: inherit;">
            <div style="font-weight:600;font-size:14px;">${escapeHtml(plate)}</div>
            <div style="font-size:12px;">${escapeHtml(name)}</div>
            <div style="font-size:11px;color:#666;margin-top:4px;">${format(parseISO(p.updated_at), "dd.MM.yyyy HH:mm")}</div>
          </div>`,
        );
        group.addLayer(marker);
      });
      group.addTo(map);
      if (points.length > 1) map.fitBounds(group.getBounds().pad(0.2));

      cleanup = () => map.remove();
    })();
    return () => {
      cancelled = true;
      cleanup();
    };
  }, [points]);

  return <div ref={containerRef} className="h-[500px] w-full rounded-md overflow-hidden" />;
}

function escapeHtml(s: string) {
  return s.replace(/[&<>"']/g, (c) =>
    c === "&" ? "&amp;" : c === "<" ? "&lt;" : c === ">" ? "&gt;" : c === '"' ? "&quot;" : "&#39;",
  );
}