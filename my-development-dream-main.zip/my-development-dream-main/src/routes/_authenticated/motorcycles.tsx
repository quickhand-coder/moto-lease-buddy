import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Plus, Loader2, Trash2 } from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { toast } from "sonner";
import { format, parseISO, differenceInDays } from "date-fns";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { EditMotoDialog } from "@/components/edit-moto-dialog";

export const Route = createFileRoute("/_authenticated/motorcycles")({
  head: () => ({ meta: [{ title: "Motosikletler — MTY Filo" }] }),
  component: MotosPage,
});

type MotoStatus = "available" | "rented" | "service" | "inactive";

const statusLabels: Record<MotoStatus, string> = {
  available: "Müsait",
  rented: "Kirada",
  service: "Serviste",
  inactive: "Pasif",
};

function MotosPage() {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);

  const { data, isLoading } = useQuery({
    queryKey: ["motorcycles"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("motorcycles")
        .select("*")
        .order("created_at", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Motosikletler</h1>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus className="h-4 w-4 mr-1" />
              Yeni Motosiklet
            </Button>
          </DialogTrigger>
          <MotoForm onDone={() => { setOpen(false); qc.invalidateQueries({ queryKey: ["motorcycles"] }); }} />
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Araç Listesi</CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-6"><Loader2 className="h-5 w-5 animate-spin" /></div>
          ) : !data?.length ? (
            <p className="text-sm text-muted-foreground">Henüz motosiklet eklenmemiş.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Plaka</TableHead>
                    <TableHead>Marka / Model</TableHead>
                    <TableHead>Yıl</TableHead>
                    <TableHead>KM</TableHead>
                    <TableHead>Durum</TableHead>
                    <TableHead>Sigorta Bitiş</TableHead>
                    <TableHead>Muayene Bitiş</TableHead>
                    <TableHead className="text-right">İşlemler</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {data.map((m) => (
                    <TableRow key={m.id}>
                      <TableCell className="font-mono font-semibold">{m.plate}</TableCell>
                      <TableCell>{m.brand} {m.model}</TableCell>
                      <TableCell>{m.year ?? "—"}</TableCell>
                      <TableCell>{m.current_km.toLocaleString("tr-TR")}</TableCell>
                      <TableCell>
                        <Badge variant={m.status === "available" ? "default" : m.status === "rented" ? "secondary" : "outline"}>
                          {statusLabels[m.status as MotoStatus]}
                        </Badge>
                      </TableCell>
                      <TableCell><DateCell date={m.insurance_end} /></TableCell>
                      <TableCell><DateCell date={m.inspection_end} /></TableCell>
                      <TableCell className="text-right">
                        <div className="flex justify-end gap-1">
                          <Button asChild size="sm" variant="ghost">
                            <Link to="/motorcycles/$id" params={{ id: m.id }}>Detay</Link>
                          </Button>
                          <EditMotoDialog
                            moto={m}
                            triggerVariant="ghost"
                            iconOnly
                            onDone={() => qc.invalidateQueries({ queryKey: ["motorcycles"] })}
                          />
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>Motosikleti sil?</AlertDialogTitle>
                                <AlertDialogDescription>
                                  <strong>{m.plate}</strong> plakalı motosiklet kalıcı olarak silinecek. Aktif bir kira varsa silme başarısız olur.
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>İptal</AlertDialogCancel>
                                <AlertDialogAction
                                  className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                  onClick={async () => {
                                    const { error } = await supabase.from("motorcycles").delete().eq("id", m.id);
                                    if (error) { toast.error(error.message); return; }
                                    toast.success("Motosiklet silindi");
                                    qc.invalidateQueries({ queryKey: ["motorcycles"] });
                                  }}
                                >
                                  Sil
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function DateCell({ date }: { date: string | null }) {
  if (!date) return <span className="text-muted-foreground">—</span>;
  const days = differenceInDays(parseISO(date), new Date());
  const color = days < 0 ? "text-destructive" : days <= 30 ? "text-orange-600" : "";
  return (
    <span className={color}>
      {format(parseISO(date), "dd.MM.yyyy")}
      {days <= 30 && (
        <span className="ml-1 text-xs">({days < 0 ? `${-days}g geçti` : `${days}g`})</span>
      )}
    </span>
  );
}

function MotoForm({ onDone }: { onDone: () => void }) {
  const [form, setForm] = useState({
    plate: "",
    brand: "",
    model: "",
    year: "",
    color: "",
    current_km: "0",
    status: "available" as MotoStatus,
    insurance_start: "",
    insurance_end: "",
    inspection_start: "",
    inspection_end: "",
    notes: "",
  });
  const [saving, setSaving] = useState(false);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase.from("motorcycles").insert({
      plate: form.plate.trim().toUpperCase(),
      brand: form.brand.trim(),
      model: form.model.trim(),
      year: form.year ? parseInt(form.year) : null,
      color: form.color || null,
      current_km: parseInt(form.current_km) || 0,
      status: form.status,
      insurance_start: form.insurance_start || null,
      insurance_end: form.insurance_end || null,
      inspection_start: form.inspection_start || null,
      inspection_end: form.inspection_end || null,
      notes: form.notes || null,
    });
    setSaving(false);
    if (error) {
      toast.error("Kaydedilemedi", { description: error.message });
      return;
    }
    toast.success("Motosiklet eklendi");
    onDone();
  }

  return (
    <DialogContent className="max-w-lg">
      <DialogHeader>
        <DialogTitle>Yeni Motosiklet</DialogTitle>
      </DialogHeader>
      <form onSubmit={onSubmit} className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Plaka *"><Input required value={form.plate} onChange={(e) => setForm({ ...form, plate: e.target.value })} /></Field>
          <Field label="Durum">
            <Select value={form.status} onValueChange={(v) => setForm({ ...form, status: v as MotoStatus })}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {(["available", "rented", "service", "inactive"] as MotoStatus[]).map((s) => (
                  <SelectItem key={s} value={s}>{statusLabels[s]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Marka *"><Input required value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} /></Field>
          <Field label="Model *"><Input required value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} /></Field>
          <Field label="Yıl"><Input type="number" value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} /></Field>
          <Field label="Renk"><Input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} /></Field>
          <Field label="Güncel KM"><Input type="number" min="0" value={form.current_km} onChange={(e) => setForm({ ...form, current_km: e.target.value })} /></Field>
          <div />
          <Field label="Sigorta Başlangıç"><Input type="date" value={form.insurance_start} onChange={(e) => setForm({ ...form, insurance_start: e.target.value })} /></Field>
          <Field label="Sigorta Bitiş"><Input type="date" value={form.insurance_end} onChange={(e) => setForm({ ...form, insurance_end: e.target.value })} /></Field>
          <Field label="Muayene Başlangıç"><Input type="date" value={form.inspection_start} onChange={(e) => setForm({ ...form, inspection_start: e.target.value })} /></Field>
          <Field label="Muayene Bitiş"><Input type="date" value={form.inspection_end} onChange={(e) => setForm({ ...form, inspection_end: e.target.value })} /></Field>
        </div>
        <Field label="Notlar"><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></Field>
        <DialogFooter>
          <Button type="submit" disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Kaydet
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label className="text-xs">{label}</Label>
      {children}
    </div>
  );
}