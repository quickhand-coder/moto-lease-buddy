import { createFileRoute, Navigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useRoles, hasAnyRole } from "@/lib/auth-hooks";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Loader2,
  Plus,
  Target,
  TrendingUp,
  Fuel,
  Wallet,
  Clock,
  Package,
  Trophy,
  Trash2,
  Calendar as CalendarIcon,
} from "lucide-react";
import {
  ResponsiveContainer,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  Legend,
} from "recharts";
import { format, parseISO, startOfWeek, startOfMonth, subDays, subMonths, startOfYear, isAfter, isEqual, endOfMonth } from "date-fns";
import { tr } from "date-fns/locale";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/earnings")({
  head: () => ({ meta: [{ title: "Kazanç Takibi — MTY Filo" }] }),
  component: EarningsPage,
});

type EarningsRecord = {
  id: string;
  user_id: string;
  entry_date: string;
  gross_amount: number;
  hours_worked: number;
  deliveries_count: number;
  fuel_expense: number;
  other_expense: number;
  note: string | null;
  created_at: string;
};

type EarningsGoal = {
  id: string;
  user_id: string;
  month: string;
  target_amount: number;
};

const fmtTL = (n: number) =>
  new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY", maximumFractionDigits: 0 }).format(n || 0);

function netOf(r: EarningsRecord) {
  return Number(r.gross_amount) - Number(r.fuel_expense) - Number(r.other_expense);
}

function EarningsPage() {
  const { user, loading } = useSession();
  const roles = useRoles(user?.id);

  const records = useQuery({
    queryKey: ["earnings-records", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("earnings_records")
        .select("*")
        .order("entry_date", { ascending: false });
      if (error) throw error;
      return (data ?? []) as EarningsRecord[];
    },
  });

  const currentMonthKey = format(startOfMonth(new Date()), "yyyy-MM-dd");
  const goal = useQuery({
    queryKey: ["earnings-goal", user?.id, currentMonthKey],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("earnings_goals")
        .select("*")
        .eq("month", currentMonthKey)
        .maybeSingle();
      if (error) throw error;
      return (data ?? null) as EarningsGoal | null;
    },
  });

  if (loading || roles.isLoading) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  // Yalnızca kiracılar
  if (!hasAnyRole(roles.data, ["tenant"])) {
    return <Navigate to="/dashboard" replace />;
  }

  const list = records.data ?? [];
  return (
    <div className="mx-auto w-full max-w-7xl space-y-6 p-4 md:p-6">
      <header className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Kazanç Takibi</h1>
          <p className="text-sm text-muted-foreground">Günlük kazançlarınızı ve giderlerinizi takip edin.</p>
        </div>
        <AddRecordDialog userId={user!.id} existingDates={list.map((r) => r.entry_date)} />
      </header>

      <SummaryCards records={list} />
      <GoalCard userId={user!.id} monthKey={currentMonthKey} goal={goal.data ?? null} records={list} />

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Genel</TabsTrigger>
          <TabsTrigger value="charts">Grafikler</TabsTrigger>
          <TabsTrigger value="records">Kayıtlar</TabsTrigger>
          <TabsTrigger value="stats">İstatistikler</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <ChartsSection records={list} compact />
          <BadgesSection records={list} goal={goal.data ?? null} />
        </TabsContent>
        <TabsContent value="charts" className="space-y-6">
          <ChartsSection records={list} />
        </TabsContent>
        <TabsContent value="records">
          <RecordsTable records={list} />
        </TabsContent>
        <TabsContent value="stats">
          <StatsSection records={list} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// ---------- Summary ----------

function SummaryCards({ records }: { records: EarningsRecord[] }) {
  const now = new Date();
  const todayKey = format(now, "yyyy-MM-dd");
  const weekStart = startOfWeek(now, { weekStartsOn: 1 });
  const monthStart = startOfMonth(now);

  const inRange = (d: string, from: Date) => {
    const dt = parseISO(d);
    return isAfter(dt, subDays(from, 1)) || isEqual(dt, from);
  };

  const today = records.filter((r) => r.entry_date === todayKey);
  const week = records.filter((r) => inRange(r.entry_date, weekStart));
  const month = records.filter((r) => inRange(r.entry_date, monthStart));

  const sum = (arr: EarningsRecord[], k: (r: EarningsRecord) => number) => arr.reduce((a, r) => a + Number(k(r) || 0), 0);

  const monthGross = sum(month, (r) => r.gross_amount);
  const monthFuel = sum(month, (r) => r.fuel_expense);
  const monthOther = sum(month, (r) => r.other_expense);
  const monthNet = monthGross - monthFuel - monthOther;
  const monthDeliveries = sum(month, (r) => r.deliveries_count);
  const monthHours = sum(month, (r) => r.hours_worked);
  const daysWithRecord = month.length || 1;

  const cards = [
    { title: "Bugünkü Net", value: fmtTL(sum(today, netOf)), icon: TrendingUp, tone: "text-emerald-500" },
    { title: "Bu Hafta Kazanç", value: fmtTL(sum(week, (r) => r.gross_amount)), icon: Wallet, tone: "text-blue-500" },
    { title: "Bu Ay Kazanç", value: fmtTL(monthGross), icon: Wallet, tone: "text-blue-500" },
    { title: "Bu Ay Yakıt Gideri", value: fmtTL(monthFuel), icon: Fuel, tone: "text-orange-500" },
    { title: "Bu Ay Diğer Giderler", value: fmtTL(monthOther), icon: Package, tone: "text-rose-500" },
    { title: "Bu Ay Net Kazanç", value: fmtTL(monthNet), icon: TrendingUp, tone: "text-emerald-500" },
    { title: "Bu Ay Teslimat", value: monthDeliveries.toLocaleString("tr-TR"), icon: Package, tone: "text-violet-500" },
    { title: "Günlük Ortalama", value: fmtTL(monthGross / daysWithRecord), icon: CalendarIcon, tone: "text-cyan-500" },
    { title: "Saatlik Ortalama", value: fmtTL(monthHours ? monthGross / monthHours : 0), icon: Clock, tone: "text-cyan-500" },
    {
      title: "Teslimat Başı Ort.",
      value: fmtTL(monthDeliveries ? monthGross / monthDeliveries : 0),
      icon: Package,
      tone: "text-cyan-500",
    },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-5">
      {cards.map((c) => (
        <Card key={c.title} className="overflow-hidden">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <span className="text-xs text-muted-foreground">{c.title}</span>
              <c.icon className={`h-4 w-4 ${c.tone}`} />
            </div>
            <div className="mt-2 text-lg font-semibold tracking-tight">{c.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

// ---------- Goal ----------

function GoalCard({
  userId,
  monthKey,
  goal,
  records,
}: {
  userId: string;
  monthKey: string;
  goal: EarningsGoal | null;
  records: EarningsRecord[];
}) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState<string>(goal?.target_amount ? String(goal.target_amount) : "");

  const monthGross = records
    .filter((r) => r.entry_date >= monthKey && r.entry_date <= format(endOfMonth(parseISO(monthKey)), "yyyy-MM-dd"))
    .reduce((a, r) => a + Number(r.gross_amount), 0);

  const target = Number(goal?.target_amount ?? 0);
  const pct = target > 0 ? Math.min(100, Math.round((monthGross / target) * 100)) : 0;
  const remaining = Math.max(0, target - monthGross);

  const save = useMutation({
    mutationFn: async (v: number) => {
      const payload = { user_id: userId, month: monthKey, target_amount: v };
      const { error } = await (supabase as any).from("earnings_goals").upsert(payload, { onConflict: "user_id,month" });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["earnings-goal"] });
      toast.success("Hedef güncellendi");
      setOpen(false);
    },
    onError: (e: any) => toast.error(e.message ?? "Kaydedilemedi"),
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <div>
          <CardTitle className="flex items-center gap-2 text-base">
            <Target className="h-4 w-4 text-primary" /> Aylık Kazanç Hedefi
          </CardTitle>
          <CardDescription>{format(parseISO(monthKey), "MMMM yyyy", { locale: tr })}</CardDescription>
        </div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" variant="outline">
              {goal ? "Düzenle" : "Hedef Belirle"}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Aylık Hedef</DialogTitle>
            </DialogHeader>
            <div className="space-y-2">
              <Label>Hedef Tutar (TL)</Label>
              <Input
                type="number"
                inputMode="decimal"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="100000"
              />
            </div>
            <DialogFooter>
              <Button
                onClick={() => save.mutate(Number(amount) || 0)}
                disabled={save.isPending || !Number(amount)}
              >
                {save.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </CardHeader>
      <CardContent className="space-y-3">
        {target > 0 ? (
          <>
            <div className="flex items-baseline justify-between">
              <span className="text-2xl font-semibold">{fmtTL(monthGross)}</span>
              <span className="text-sm text-muted-foreground">/ {fmtTL(target)}</span>
            </div>
            <Progress value={pct} className="h-3" />
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>%{pct} tamamlandı</span>
              <span>Kalan: {fmtTL(remaining)}</span>
            </div>
          </>
        ) : (
          <p className="text-sm text-muted-foreground">Henüz bir hedef belirlemediniz.</p>
        )}
      </CardContent>
    </Card>
  );
}

// ---------- Add Record ----------

function AddRecordDialog({ userId, existingDates }: { userId: string; existingDates: string[] }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    entry_date: format(new Date(), "yyyy-MM-dd"),
    gross_amount: "",
    hours_worked: "",
    deliveries_count: "",
    fuel_expense: "",
    other_expense: "",
    note: "",
  });

  const create = useMutation({
    mutationFn: async () => {
      const payload = {
        user_id: userId,
        entry_date: form.entry_date,
        gross_amount: Number(form.gross_amount) || 0,
        hours_worked: Number(form.hours_worked) || 0,
        deliveries_count: Number(form.deliveries_count) || 0,
        fuel_expense: Number(form.fuel_expense) || 0,
        other_expense: Number(form.other_expense) || 0,
        note: form.note || null,
      };
      const { error } = await (supabase as any)
        .from("earnings_records")
        .upsert(payload, { onConflict: "user_id,entry_date" });
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["earnings-records"] });
      toast.success("Kayıt eklendi");
      setOpen(false);
      setForm({
        entry_date: format(new Date(), "yyyy-MM-dd"),
        gross_amount: "",
        hours_worked: "",
        deliveries_count: "",
        fuel_expense: "",
        other_expense: "",
        note: "",
      });
    },
    onError: (e: any) => toast.error(e.message ?? "Kaydedilemedi"),
  });

  const net =
    (Number(form.gross_amount) || 0) - (Number(form.fuel_expense) || 0) - (Number(form.other_expense) || 0);
  const isDuplicate = existingDates.includes(form.entry_date);

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="h-4 w-4" /> Günlük Kayıt Ekle
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle>Günlük Kazanç Kaydı</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-2 gap-3">
          <div className="col-span-2 space-y-1">
            <Label>Tarih</Label>
            <Input
              type="date"
              value={form.entry_date}
              onChange={(e) => setForm({ ...form, entry_date: e.target.value })}
            />
            {isDuplicate && (
              <p className="text-xs text-amber-500">Bu tarihte kayıt var. Kaydetmek üzerine yazar.</p>
            )}
          </div>
          <Field label="Toplam Kazanç (TL)" value={form.gross_amount} onChange={(v) => setForm({ ...form, gross_amount: v })} />
          <Field label="Çalışılan Saat" value={form.hours_worked} onChange={(v) => setForm({ ...form, hours_worked: v })} />
          <Field label="Teslimat" value={form.deliveries_count} onChange={(v) => setForm({ ...form, deliveries_count: v })} />
          <Field label="Yakıt (TL)" value={form.fuel_expense} onChange={(v) => setForm({ ...form, fuel_expense: v })} />
          <Field label="Diğer Gider (TL)" value={form.other_expense} onChange={(v) => setForm({ ...form, other_expense: v })} />
          <div className="col-span-2 space-y-1">
            <Label>Not</Label>
            <Textarea
              rows={2}
              value={form.note}
              onChange={(e) => setForm({ ...form, note: e.target.value })}
              placeholder="Opsiyonel"
            />
          </div>
          <div className="col-span-2 rounded-md bg-muted/50 px-3 py-2 text-sm">
            Net Kazanç: <span className="font-semibold">{fmtTL(net)}</span>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={() => create.mutate()} disabled={create.isPending}>
            {create.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div className="space-y-1">
      <Label>{label}</Label>
      <Input type="number" inputMode="decimal" value={value} onChange={(e) => onChange(e.target.value)} placeholder="0" />
    </div>
  );
}

// ---------- Charts ----------

function ChartsSection({ records, compact }: { records: EarningsRecord[]; compact?: boolean }) {
  const last7 = useMemo(() => buildDaily(records, 7), [records]);
  const last30 = useMemo(() => buildDaily(records, 30), [records]);
  const monthly = useMemo(() => buildMonthly(records, 12), [records]);

  return (
    <div className={`grid gap-4 ${compact ? "md:grid-cols-2" : "md:grid-cols-2"}`}>
      <ChartCard title="Son 7 Gün — Kazanç / Net">
        <ResponsiveContainer width="100%" height={220}>
          <LineChart data={last7}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
            <XAxis dataKey="label" fontSize={11} />
            <YAxis fontSize={11} />
            <Tooltip formatter={(v: any) => fmtTL(Number(v))} />
            <Legend />
            <Line type="monotone" name="Kazanç" dataKey="gross" stroke="hsl(var(--primary))" strokeWidth={2} />
            <Line type="monotone" name="Net" dataKey="net" stroke="hsl(142 76% 45%)" strokeWidth={2} />
          </LineChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Son 30 Gün — Net Kazanç">
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={last30}>
            <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
            <XAxis dataKey="label" fontSize={10} interval={3} />
            <YAxis fontSize={11} />
            <Tooltip formatter={(v: any) => fmtTL(Number(v))} />
            <Bar dataKey="net" name="Net" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      {!compact && (
        <ChartCard title="Aylık Kazanç">
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={monthly}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="label" fontSize={11} />
              <YAxis fontSize={11} />
              <Tooltip formatter={(v: any) => fmtTL(Number(v))} />
              <Legend />
              <Bar dataKey="gross" name="Kazanç" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
              <Bar dataKey="net" name="Net" fill="hsl(142 76% 45%)" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </ChartCard>
      )}

      {!compact && (
        <ChartCard title="Son 30 Gün — Yakıt Gideri">
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={last30}>
              <CartesianGrid strokeDasharray="3 3" opacity={0.2} />
              <XAxis dataKey="label" fontSize={10} interval={3} />
              <YAxis fontSize={11} />
              <Tooltip formatter={(v: any) => fmtTL(Number(v))} />
              <Line type="monotone" dataKey="fuel" name="Yakıt" stroke="hsl(25 95% 55%)" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </ChartCard>
      )}
    </div>
  );
}

function ChartCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-sm font-medium">{title}</CardTitle>
      </CardHeader>
      <CardContent>{children}</CardContent>
    </Card>
  );
}

function buildDaily(records: EarningsRecord[], days: number) {
  const map = new Map(records.map((r) => [r.entry_date, r]));
  const out: { label: string; date: string; gross: number; net: number; fuel: number }[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = subDays(new Date(), i);
    const key = format(d, "yyyy-MM-dd");
    const r = map.get(key);
    out.push({
      label: format(d, days > 10 ? "d MMM" : "EEE", { locale: tr }),
      date: key,
      gross: r ? Number(r.gross_amount) : 0,
      net: r ? netOf(r) : 0,
      fuel: r ? Number(r.fuel_expense) : 0,
    });
  }
  return out;
}

function buildMonthly(records: EarningsRecord[], months: number) {
  const out: { label: string; gross: number; net: number }[] = [];
  for (let i = months - 1; i >= 0; i--) {
    const d = startOfMonth(subMonths(new Date(), i));
    const key = format(d, "yyyy-MM");
    const inMonth = records.filter((r) => r.entry_date.startsWith(key));
    const gross = inMonth.reduce((a, r) => a + Number(r.gross_amount), 0);
    const net = inMonth.reduce((a, r) => a + netOf(r), 0);
    out.push({ label: format(d, "MMM", { locale: tr }), gross, net });
  }
  return out;
}

// ---------- Records Table + Filter ----------

type FilterKey = "today" | "week" | "month" | "q3" | "q6" | "year" | "all";

function RecordsTable({ records }: { records: EarningsRecord[] }) {
  const qc = useQueryClient();
  const [filter, setFilter] = useState<FilterKey>("month");

  const filtered = useMemo(() => {
    const now = new Date();
    const from = (() => {
      switch (filter) {
        case "today": return now;
        case "week": return startOfWeek(now, { weekStartsOn: 1 });
        case "month": return startOfMonth(now);
        case "q3": return subMonths(now, 3);
        case "q6": return subMonths(now, 6);
        case "year": return startOfYear(now);
        default: return null;
      }
    })();
    if (!from) return records;
    const fromKey = format(from, "yyyy-MM-dd");
    return records.filter((r) => r.entry_date >= fromKey);
  }, [records, filter]);

  const del = useMutation({
    mutationFn: async (id: string) => {
      const { error } = await (supabase as any).from("earnings_records").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["earnings-records"] });
      toast.success("Silindi");
    },
  });

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between space-y-0">
        <CardTitle className="text-base">Kayıtlar</CardTitle>
        <Select value={filter} onValueChange={(v) => setFilter(v as FilterKey)}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="today">Bugün</SelectItem>
            <SelectItem value="week">Bu Hafta</SelectItem>
            <SelectItem value="month">Bu Ay</SelectItem>
            <SelectItem value="q3">Son 3 Ay</SelectItem>
            <SelectItem value="q6">Son 6 Ay</SelectItem>
            <SelectItem value="year">Bu Yıl</SelectItem>
            <SelectItem value="all">Tümü</SelectItem>
          </SelectContent>
        </Select>
      </CardHeader>
      <CardContent className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Tarih</TableHead>
              <TableHead className="text-right">Kazanç</TableHead>
              <TableHead className="text-right">Saat</TableHead>
              <TableHead className="text-right">Teslimat</TableHead>
              <TableHead className="text-right">Yakıt</TableHead>
              <TableHead className="text-right">Diğer</TableHead>
              <TableHead className="text-right">Net</TableHead>
              <TableHead />
            </TableRow>
          </TableHeader>
          <TableBody>
            {filtered.length === 0 && (
              <TableRow>
                <TableCell colSpan={8} className="py-8 text-center text-sm text-muted-foreground">
                  Kayıt yok
                </TableCell>
              </TableRow>
            )}
            {filtered.map((r) => (
              <TableRow key={r.id}>
                <TableCell>{format(parseISO(r.entry_date), "d MMM yyyy", { locale: tr })}</TableCell>
                <TableCell className="text-right">{fmtTL(Number(r.gross_amount))}</TableCell>
                <TableCell className="text-right">{Number(r.hours_worked)}</TableCell>
                <TableCell className="text-right">{r.deliveries_count}</TableCell>
                <TableCell className="text-right">{fmtTL(Number(r.fuel_expense))}</TableCell>
                <TableCell className="text-right">{fmtTL(Number(r.other_expense))}</TableCell>
                <TableCell className="text-right font-medium text-emerald-600">{fmtTL(netOf(r))}</TableCell>
                <TableCell>
                  <Button size="icon" variant="ghost" onClick={() => del.mutate(r.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

// ---------- Stats ----------

function StatsSection({ records }: { records: EarningsRecord[] }) {
  const s = useMemo(() => {
    if (!records.length) return null;
    const totalGross = records.reduce((a, r) => a + Number(r.gross_amount), 0);
    const totalFuel = records.reduce((a, r) => a + Number(r.fuel_expense), 0);
    const totalOther = records.reduce((a, r) => a + Number(r.other_expense), 0);
    const totalHours = records.reduce((a, r) => a + Number(r.hours_worked), 0);
    const totalDeliveries = records.reduce((a, r) => a + r.deliveries_count, 0);
    const days = records.length;
    const best = records.reduce((a, r) => (Number(r.gross_amount) > Number(a.gross_amount) ? r : a), records[0]);
    const mostDel = records.reduce((a, r) => (r.deliveries_count > a.deliveries_count ? r : a), records[0]);
    return {
      totalGross,
      totalFuel,
      totalOther,
      totalHours,
      totalDeliveries,
      avgDaily: totalGross / days,
      avgWeekly: (totalGross / days) * 7,
      avgMonthly: (totalGross / days) * 30,
      avgHourly: totalHours ? totalGross / totalHours : 0,
      avgPerDelivery: totalDeliveries ? totalGross / totalDeliveries : 0,
      best,
      mostDel,
    };
  }, [records]);

  if (!s) {
    return <Card><CardContent className="py-10 text-center text-sm text-muted-foreground">Henüz kayıt yok</CardContent></Card>;
  }

  const rows: [string, string][] = [
    ["En yüksek kazanç günü", `${format(parseISO(s.best.entry_date), "d MMM yyyy", { locale: tr })} — ${fmtTL(Number(s.best.gross_amount))}`],
    ["En çok teslimat günü", `${format(parseISO(s.mostDel.entry_date), "d MMM yyyy", { locale: tr })} — ${s.mostDel.deliveries_count} teslimat`],
    ["Ortalama günlük kazanç", fmtTL(s.avgDaily)],
    ["Ortalama haftalık kazanç", fmtTL(s.avgWeekly)],
    ["Ortalama aylık kazanç", fmtTL(s.avgMonthly)],
    ["Ortalama saatlik kazanç", fmtTL(s.avgHourly)],
    ["Teslimat başına ortalama", fmtTL(s.avgPerDelivery)],
    ["Toplam çalışma saati", `${s.totalHours.toLocaleString("tr-TR")} saat`],
    ["Toplam teslimat", s.totalDeliveries.toLocaleString("tr-TR")],
    ["Toplam yakıt gideri", fmtTL(s.totalFuel)],
    ["Toplam diğer giderler", fmtTL(s.totalOther)],
  ];

  return (
    <Card>
      <CardHeader><CardTitle className="text-base">İstatistikler</CardTitle></CardHeader>
      <CardContent>
        <div className="divide-y">
          {rows.map(([k, v]) => (
            <div key={k} className="flex items-center justify-between py-2 text-sm">
              <span className="text-muted-foreground">{k}</span>
              <span className="font-medium">{v}</span>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

// ---------- Badges ----------

function BadgesSection({ records, goal }: { records: EarningsRecord[]; goal: EarningsGoal | null }) {
  const totalGross = records.reduce((a, r) => a + Number(r.gross_amount), 0);
  const totalDeliveries = records.reduce((a, r) => a + r.deliveries_count, 0);

  // 30 gün üst üste — basit kontrol: son 30 farklı tarihte kayıt var mı
  const last30Streak = (() => {
    const set = new Set(records.map((r) => r.entry_date));
    for (let i = 0; i < 30; i++) {
      if (!set.has(format(subDays(new Date(), i), "yyyy-MM-dd"))) return false;
    }
    return true;
  })();

  const currentMonth = format(new Date(), "yyyy-MM");
  const monthGross = records.filter((r) => r.entry_date.startsWith(currentMonth)).reduce((a, r) => a + Number(r.gross_amount), 0);
  const goalHit = !!goal && goal.target_amount > 0 && monthGross >= Number(goal.target_amount);

  const badges = [
    { key: "first", label: "İlk Kazanç", desc: "İlk kaydı oluşturdunuz", earned: records.length >= 1, emoji: "🏅" },
    { key: "streak", label: "İstikrarlı Kurye", desc: "30 gün üst üste kayıt", earned: last30Streak, emoji: "🔥" },
    { key: "master", label: "Usta Kurye", desc: "1000 teslimat", earned: totalDeliveries >= 1000, emoji: "🏆" },
    { key: "gold", label: "Altın Kurye", desc: "500.000 TL toplam kazanç", earned: totalGross >= 500000, emoji: "🥇" },
    { key: "goal", label: "Hedef Avcısı", desc: "Aylık hedef tamamlandı", earned: goalHit, emoji: "🎯" },
  ];

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="flex items-center gap-2 text-base">
          <Trophy className="h-4 w-4 text-amber-500" /> Rozetler
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-3 md:grid-cols-5">
          {badges.map((b) => (
            <div
              key={b.key}
              className={`rounded-lg border p-3 text-center transition ${
                b.earned ? "border-primary/40 bg-primary/5" : "opacity-50"
              }`}
            >
              <div className="text-2xl">{b.emoji}</div>
              <div className="mt-1 text-sm font-medium">{b.label}</div>
              <div className="text-xs text-muted-foreground">{b.desc}</div>
              {b.earned && <Badge variant="secondary" className="mt-2">Kazanıldı</Badge>}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
