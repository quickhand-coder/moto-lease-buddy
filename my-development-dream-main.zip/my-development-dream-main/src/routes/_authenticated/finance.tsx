import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useRoles } from "@/lib/auth-hooks";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, TrendingUp, Wallet, ArrowDownCircle, ArrowUpCircle, Wrench } from "lucide-react";
import { format, parseISO, startOfMonth, subMonths, addMonths } from "date-fns";
import { tr } from "date-fns/locale";
import { toast } from "sonner";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  Legend,
  CartesianGrid,
} from "recharts";

export const Route = createFileRoute("/_authenticated/finance")({
  head: () => ({ meta: [{ title: "Finans — MTY Filo" }] }),
  component: FinancePage,
});

const fmtTRY = (n: number) =>
  new Intl.NumberFormat("tr-TR", { style: "currency", currency: "TRY", maximumFractionDigits: 0 }).format(n);

type CellKind = "rent" | "deposit";

type PaymentCell = {
  kind: CellKind;
  id: string; // payment_schedule id OR rental id (for deposit)
  amount: number;
  paid_amount: number;
  status: "pending" | "paid" | "overdue" | "partial";
  due_date: string;
  paid_at: string | null;
};

type ExpenseKind = "deposit_refund" | "maintenance";

type ExpenseRow = {
  id: string;
  month: string; // yyyy-MM-dd
  kind: ExpenseKind;
  amount: number;
  note: string | null;
};

type MonthRow = {
  key: string;
  label: string;
  rent: number;
  deposit: number;
  maintenance: number; // negative for chart display
  depositRefund: number; // negative for chart display
  net: number;
};

function FinancePage() {
  const { user, loading } = useSession();
  const rolesQuery = useRoles(user?.id);
  const isAdmin = rolesQuery.data?.includes("admin") ?? false;
  const [range, setRange] = useState<"1" | "6" | "12" | "24">("12");
  const [matrixData, setMatrixData] = useState<{
    rentByMonth: Record<string, number>;
    depositTotal: number;
  } | null>(null);

  if (loading || rolesQuery.isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="animate-spin" />
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-semibold">Finans</h1>
        <Card>
          <CardContent className="py-6 text-sm text-muted-foreground text-center">
            Bu sayfa yalnızca yönetici hesapları için erişilebilir.
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Finans</h1>
          <p className="text-sm text-muted-foreground">
            Kira peşin alınır. Tahsilatlar ve depozitolar matriste hücreye tıklanarak yönetilir.
          </p>
        </div>
        <Select value={range} onValueChange={(v) => setRange(v as "1" | "6" | "12" | "24")}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">Son 1 ay</SelectItem>
            <SelectItem value="6">Son 6 ay</SelectItem>
            <SelectItem value="12">Son 12 ay</SelectItem>
            <SelectItem value="24">Son 24 ay</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <PaymentMatrix onDataChange={setMatrixData} />
      <MonthlySummary range={range} matrixData={matrixData} />
    </div>
  );
}

/* ================= Payment Matrix (tenants × last 6 months + deposit) ================= */

function PaymentMatrix({
  onDataChange,
}: {
  onDataChange: (d: { rentByMonth: Record<string, number>; depositTotal: number }) => void;
}) {
  const qc = useQueryClient();
  const [editing, setEditing] = useState<PaymentCell | null>(null);
  const [creating, setCreating] = useState<{
    tenantId: string;
    tenantName: string;
    monthKey: string;
    monthLabel: string;
    rentals: { id: string; plate: string; monthlyRate: number }[];
  } | null>(null);
  const [creatingDeposit, setCreatingDeposit] = useState<{
    tenantId: string;
    tenantName: string;
    rentals: { id: string; plate: string }[];
  } | null>(null);
  const [expenseDialog, setExpenseDialog] = useState<{
    monthKey: string;
    monthLabel: string;
    editing?: ExpenseRow | null;
  } | null>(null);

  const months = useMemo(() => {
    const now = startOfMonth(new Date());
    return Array.from({ length: 6 }, (_, i) => startOfMonth(subMonths(now, 5 - i)));
  }, []);
  const rangeStart = months[0];
  const rangeEnd = addMonths(months[5], 1);

  const paymentsQuery = useQuery({
    queryKey: ["payment-matrix", format(rangeStart, "yyyy-MM")],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("payment_schedule")
        .select(
          "id, amount, paid_amount, status, due_date, paid_at, rentals!inner(id, tenant_id, tenants!inner(id, full_name), motorcycles(plate))",
        )
        .gte("due_date", format(rangeStart, "yyyy-MM-dd"))
        .lt("due_date", format(rangeEnd, "yyyy-MM-dd"))
        .order("due_date");
      if (error) throw error;
      return data as unknown as Array<{
        id: string;
        amount: number;
        paid_amount: number;
        status: PaymentCell["status"];
        due_date: string;
        paid_at: string | null;
        rentals: {
          id: string;
          tenant_id: string;
          tenants: { id: string; full_name: string };
          motorcycles: { plate: string } | null;
        };
      }>;
    },
  });

  const rentalsQuery = useQuery({
    queryKey: ["deposit-matrix"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("rentals")
        .select(
          "id, monthly_rate, deposit_amount, deposit_status, deposit_paid_amount, deposit_paid_at, start_date, tenant_id, tenants!inner(id, full_name), motorcycles(plate)",
        );
      if (error) throw error;
      return data as unknown as Array<{
        id: string;
        monthly_rate: number | null;
        deposit_amount: number | null;
        deposit_status: "pending" | "paid" | "partial";
        deposit_paid_amount: number;
        deposit_paid_at: string | null;
        start_date: string;
        tenants: { id: string; full_name: string };
        motorcycles: { plate: string } | null;
      }>;
    },
  });

  const expensesQuery = useQuery({
    queryKey: ["expense-matrix", format(rangeStart, "yyyy-MM")],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("monthly_expenses")
        .select("id, month, kind, amount, note")
        .gte("month", format(rangeStart, "yyyy-MM-dd"))
        .lt("month", format(rangeEnd, "yyyy-MM-dd"))
        .order("month");
      if (error) throw error;
      return (data ?? []) as ExpenseRow[];
    },
  });

  const expensesByMonth = useMemo(() => {
    const map: Record<string, ExpenseRow[]> = {};
    for (const e of expensesQuery.data ?? []) {
      const k = format(parseISO(e.month), "yyyy-MM");
      (map[k] ||= []).push(e);
    }
    return map;
  }, [expensesQuery.data]);


  type TenantRentalRef = { id: string; plate: string; monthlyRate: number };
  const grouped = useMemo(() => {
    const tenants = new Map<
      string,
      {
        id: string;
        name: string;
        plates: Set<string>;
        cells: Record<string, PaymentCell[]>;
        deposits: PaymentCell[];
        rentals: TenantRentalRef[];
        allRentals: { id: string; plate: string }[];
        paymentDay: number | null;
      }
    >();
    const ensure = (id: string, name: string) => {
      if (!tenants.has(id))
        tenants.set(id, {
          id,
          name,
          plates: new Set(),
          cells: {},
          deposits: [],
          rentals: [],
          allRentals: [],
          paymentDay: null,
        });
      return tenants.get(id)!;
    };

    for (const p of paymentsQuery.data ?? []) {
      const t = ensure(p.rentals.tenants.id, p.rentals.tenants.full_name);
      if (p.rentals.motorcycles?.plate) t.plates.add(p.rentals.motorcycles.plate);
      const monthKey = format(parseISO(p.due_date), "yyyy-MM");
      (t.cells[monthKey] ||= []).push({
        kind: "rent",
        id: p.id,
        amount: Number(p.amount),
        paid_amount: Number(p.paid_amount),
        status: p.status,
        due_date: p.due_date,
        paid_at: p.paid_at,
      });
    }
    for (const r of rentalsQuery.data ?? []) {
      const t = ensure(r.tenants.id, r.tenants.full_name);
      if (r.motorcycles?.plate) t.plates.add(r.motorcycles.plate);
      t.rentals.push({
        id: r.id,
        plate: r.motorcycles?.plate ?? "—",
        monthlyRate: Number(r.monthly_rate ?? 0),
      });
      t.allRentals.push({ id: r.id, plate: r.motorcycles?.plate ?? "—" });
      const day = parseISO(r.start_date).getDate();
      if (t.paymentDay === null || day < t.paymentDay) t.paymentDay = day;
      if (Number(r.deposit_amount ?? 0) > 0) {
        t.deposits.push({
          kind: "deposit",
          id: r.id,
          amount: Number(r.deposit_amount),
          paid_amount: Number(r.deposit_paid_amount ?? 0),
          status: r.deposit_status,
          due_date: r.start_date,
          paid_at: r.deposit_paid_at,
        });
      }
    }
    return Array.from(tenants.values()).sort((a, b) => {
      const da = a.paymentDay ?? 99;
      const db = b.paymentDay ?? 99;
      if (da !== db) return da - db;
      return a.name.localeCompare(b.name, "tr");
    });
  }, [paymentsQuery.data, rentalsQuery.data]);

  // Compute matrix-derived totals for the chart
  // Rent is attributed to the month of its due_date; deposit is attributed to the month it was paid.
  useEffect(() => {
    if (paymentsQuery.isLoading || rentalsQuery.isLoading) return;
    const rentByMonth: Record<string, number> = {};
    for (const p of paymentsQuery.data ?? []) {
      if (p.status !== "paid" && p.status !== "partial") continue;
      const key = format(parseISO(p.due_date), "yyyy-MM");
      rentByMonth[key] = (rentByMonth[key] ?? 0) + Number(p.paid_amount ?? 0);
    }
    let depositTotal = 0;
    for (const r of rentalsQuery.data ?? []) {
      if (r.deposit_status === "paid") depositTotal += Number(r.deposit_amount ?? 0);
      else if (r.deposit_status === "partial") depositTotal += Number(r.deposit_paid_amount ?? 0);
    }
    onDataChange({ rentByMonth, depositTotal });
  }, [paymentsQuery.data, rentalsQuery.data, paymentsQuery.isLoading, rentalsQuery.isLoading, onDataChange]);

  const loading = paymentsQuery.isLoading || rentalsQuery.isLoading;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Ödeme Takip Matrisi</CardTitle>
        <CardDescription>
          Kiracı × son 6 ay + sabit depozito sütunu. Hücreye tıklayarak ödendi / kısmi / ödenmedi olarak işaretleyin.
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        {loading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="animate-spin" />
          </div>
        ) : grouped.length === 0 ? (
          <div className="py-6 text-center text-sm text-muted-foreground">
            Bu aralıkta ödeme kaydı bulunmuyor.
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm border-collapse">
              <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="text-left px-3 py-2 sticky left-0 bg-muted/50 z-10">Kiracı</th>
                  {months.map((m) => (
                    <th key={m.toISOString()} className="text-center px-3 py-2 min-w-[110px]">
                      {format(m, "LLL yyyy", { locale: tr })}
                    </th>
                  ))}
                  <th className="text-center px-3 py-2 min-w-[120px] bg-blue-500/10 text-blue-700 dark:text-blue-300 sticky right-0 z-10">
                    Depozito
                  </th>
                </tr>
              </thead>
              <tbody>
                {grouped.map((t) => (
                  <tr key={t.id} className="border-t">
                    <td className="px-3 py-2 sticky left-0 bg-background z-10">
                      <div className="font-medium">{t.name}</div>
                      {t.paymentDay !== null && (
                        <div className="text-xs text-primary/80">
                          Ödeme günü: her ayın {t.paymentDay}.
                        </div>
                      )}
                      {t.plates.size > 0 && (
                        <div className="text-xs text-muted-foreground">
                          {Array.from(t.plates).join(", ")}
                        </div>
                      )}
                    </td>
                    {months.map((m) => {
                      const key = format(m, "yyyy-MM");
                      const cells = t.cells[key] ?? [];
                      return (
                        <td key={key} className="px-1.5 py-1 align-top">
                          {cells.length === 0 ? (
                            <button
                              type="button"
                              onClick={() =>
                                t.rentals.length === 0
                                  ? toast.error("Kiracının aktif kiralaması yok")
                                  : setCreating({
                                      tenantId: t.id,
                                      tenantName: t.name,
                                      monthKey: key,
                                      monthLabel: format(m, "LLLL yyyy", { locale: tr }),
                                      rentals: t.rentals,
                                    })
                              }
                              className="h-14 w-full rounded border border-dashed border-muted-foreground/25 text-muted-foreground/60 hover:border-primary/40 hover:text-primary hover:bg-primary/5 transition text-lg"
                              title="Ödeme ekle"
                            >
                              +
                            </button>
                          ) : (
                            <div className="space-y-1">
                              {cells.map((c) => (
                                <CellButton key={c.id} cell={c} onClick={() => setEditing(c)} />
                              ))}
                            </div>
                          )}
                        </td>
                      );
                    })}
                    <td className="px-1.5 py-1 align-top bg-blue-500/5 sticky right-0 z-10">
                      {t.deposits.length === 0 ? (
                        <button
                          type="button"
                          onClick={() =>
                            t.allRentals.length === 0
                              ? toast.error("Kiracının kiralaması yok")
                              : setCreatingDeposit({
                                  tenantId: t.id,
                                  tenantName: t.name,
                                  rentals: t.allRentals,
                                })
                          }
                          className="h-14 w-full rounded border border-dashed border-blue-500/30 text-blue-500/70 hover:border-blue-500/60 hover:text-blue-600 hover:bg-blue-500/10 transition text-lg"
                          title="Depozito ekle"
                        >
                          +
                        </button>
                      ) : (
                        <div className="space-y-1">
                          {t.deposits.map((c) => (
                            <CellButton key={c.id} cell={c} onClick={() => setEditing(c)} />
                          ))}
                        </div>
                      )}
                    </td>
                  </tr>
                ))}
                <tr className="border-t bg-orange-500/5">
                  <td className="px-3 py-2 sticky left-0 bg-orange-500/5 z-10">
                    <div className="font-medium text-orange-700 dark:text-orange-300">Masraflar</div>
                    <div className="text-xs text-muted-foreground">Bakım + depozito iadesi</div>
                  </td>
                  {months.map((m) => {
                    const key = format(m, "yyyy-MM");
                    const items = expensesByMonth[key] ?? [];
                    return (
                      <td key={key} className="px-1.5 py-1 align-top">
                        <div className="space-y-1">
                          {items.map((e) => (
                            <button
                              key={e.id}
                              type="button"
                              onClick={() =>
                                setExpenseDialog({
                                  monthKey: key,
                                  monthLabel: format(m, "LLLL yyyy", { locale: tr }),
                                  editing: e,
                                })
                              }
                              className="w-full text-left rounded border px-2 py-1.5 bg-orange-500/15 text-orange-700 dark:text-orange-300 border-orange-500/30 hover:bg-orange-500/25 transition"
                              title={e.note ?? ""}
                            >
                              <div className="font-semibold text-xs">−{fmtTRY(Number(e.amount))}</div>
                              <div className="text-[10px]">
                                {e.kind === "maintenance" ? "Bakım" : "Depozito iadesi"}
                              </div>
                            </button>
                          ))}
                          <button
                            type="button"
                            onClick={() =>
                              setExpenseDialog({
                                monthKey: key,
                                monthLabel: format(m, "LLLL yyyy", { locale: tr }),
                                editing: null,
                              })
                            }
                            className="h-8 w-full rounded border border-dashed border-orange-500/30 text-orange-500/70 hover:border-orange-500/60 hover:text-orange-600 hover:bg-orange-500/10 transition text-sm"
                            title="Masraf ekle"
                          >
                            +
                          </button>
                        </div>
                      </td>
                    );
                  })}
                  <td className="px-1.5 py-1 align-top bg-orange-500/5 sticky right-0 z-10">
                    <div className="h-8 rounded border border-dashed border-muted-foreground/20" />
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        )}
      </CardContent>

      <PaymentEditDialog
        cell={editing}
        onClose={() => setEditing(null)}
        onSaved={() => {
          qc.invalidateQueries({ queryKey: ["payment-matrix"] });
          qc.invalidateQueries({ queryKey: ["deposit-matrix"] });
        }}
      />
      <CreateCellDialog
        request={creating}
        onClose={() => setCreating(null)}
        onSaved={() => {
          qc.invalidateQueries({ queryKey: ["payment-matrix"] });
        }}
      />
      <CreateDepositDialog
        request={creatingDeposit}
        onClose={() => setCreatingDeposit(null)}
        onSaved={() => {
          qc.invalidateQueries({ queryKey: ["deposit-matrix"] });
        }}
      />
      <ExpenseDialog
        request={expenseDialog}
        onClose={() => setExpenseDialog(null)}
        onSaved={() => {
          qc.invalidateQueries({ queryKey: ["expense-matrix"] });
          qc.invalidateQueries({ queryKey: ["finance-monthly"] });
        }}
      />
    </Card>
  );
}

function CellButton({ cell, onClick }: { cell: PaymentCell; onClick: () => void }) {
  const remaining = Math.max(0, cell.amount - cell.paid_amount);
  let cls = "bg-red-500/15 text-red-700 dark:text-red-300 border-red-500/30 hover:bg-red-500/25";
  let statusLabel = "Ödenmedi";
  if (cell.status === "paid") {
    cls = "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border-emerald-500/30 hover:bg-emerald-500/25";
    statusLabel = "Ödendi";
  } else if (cell.status === "partial") {
    cls = "bg-amber-500/15 text-amber-700 dark:text-amber-300 border-amber-500/30 hover:bg-amber-500/25";
    statusLabel = "Kısmi";
  }
  return (
    <button
      type="button"
      onClick={onClick}
      className={`w-full text-left rounded border px-2 py-1.5 transition ${cls}`}
      title={`${cell.kind === "deposit" ? "Depozito" : "Kira"} — ${statusLabel} — ${format(parseISO(cell.due_date), "dd.MM.yyyy")}`}
    >
      <div className="font-semibold text-xs">{fmtTRY(cell.amount)}</div>
      {cell.status === "partial" && (
        <div className="text-[10px] leading-tight">
          Ödenen: {fmtTRY(cell.paid_amount)}
          <br />
          Kalan: {fmtTRY(remaining)}
        </div>
      )}
      {cell.status === "paid" && <div className="text-[10px]">Tamamlandı</div>}
      {(cell.status === "pending" || cell.status === "overdue") && (
        <div className="text-[10px]">Bekliyor</div>
      )}
    </button>
  );
}

function PaymentEditDialog({
  cell,
  onClose,
  onSaved,
}: {
  cell: PaymentCell | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [status, setStatus] = useState<"paid" | "pending" | "partial">("paid");
  const [partialAmount, setPartialAmount] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (cell) {
      setStatus(cell.status === "partial" ? "partial" : cell.status === "paid" ? "paid" : "pending");
      setPartialAmount(cell.paid_amount > 0 ? String(cell.paid_amount) : "");
    }
  }, [cell?.id]);

  if (!cell) return null;
  const remaining = Math.max(0, cell.amount - (parseFloat(partialAmount) || 0));

  async function save() {
    if (!cell) return;
    setSaving(true);
    let paid_amount = 0;
    let paid_at: string | null = null;
    if (status === "paid") {
      paid_amount = cell.amount;
      paid_at = new Date().toISOString();
    } else if (status === "partial") {
      paid_amount = parseFloat(partialAmount) || 0;
      if (paid_amount <= 0 || paid_amount >= cell.amount) {
        toast.error("Kısmi tutar 0 ile toplam tutar arasında olmalı");
        setSaving(false);
        return;
      }
      paid_at = new Date().toISOString();
    }

    let error;
    if (cell.kind === "rent") {
      ({ error } = await supabase
        .from("payment_schedule")
        .update({ status, paid_amount, paid_at })
        .eq("id", cell.id));
    } else {
      ({ error } = await supabase
        .from("rentals")
        .update({
          deposit_status: status,
          deposit_paid_amount: paid_amount,
          deposit_paid_at: paid_at,
        })
        .eq("id", cell.id));
    }
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(cell.kind === "deposit" ? "Depozito güncellendi" : "Ödeme güncellendi");
    onSaved();
    onClose();
  }

  async function clearCell() {
    if (!cell) return;
    setSaving(true);
    let error;
    if (cell.kind === "rent") {
      ({ error } = await supabase.from("payment_schedule").delete().eq("id", cell.id));
    } else {
      ({ error } = await supabase
        .from("rentals")
        .update({ deposit_status: "pending", deposit_paid_amount: 0, deposit_paid_at: null })
        .eq("id", cell.id));
    }
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(cell.kind === "deposit" ? "Depozito sıfırlandı" : "Ödeme silindi");
    onSaved();
    onClose();
  }

  return (
    <Dialog open={!!cell} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>{cell.kind === "deposit" ? "Depozito Durumu" : "Ödeme Durumu"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="text-sm text-muted-foreground">
            {cell.kind === "deposit" ? "Kiralama başlangıcı" : "Vade"}: {format(parseISO(cell.due_date), "dd MMMM yyyy", { locale: tr })}
            <br />
            Toplam: <span className="font-semibold text-foreground">{fmtTRY(cell.amount)}</span>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <StatusPill active={status === "paid"} onClick={() => setStatus("paid")} color="emerald" label="Ödendi" />
            <StatusPill active={status === "partial"} onClick={() => setStatus("partial")} color="amber" label="Kısmi" />
            <StatusPill active={status === "pending"} onClick={() => setStatus("pending")} color="red" label="Ödenmedi" />
          </div>
          {status === "partial" && (
            <div className="space-y-2">
              <Label>Ödenen tutar (₺)</Label>
              <Input
                type="number"
                min="0"
                max={cell.amount}
                value={partialAmount}
                onChange={(e) => setPartialAmount(e.target.value)}
                placeholder="0"
              />
              <div className="text-xs text-muted-foreground">
                Kalan: <span className="font-semibold text-amber-600">{fmtTRY(remaining)}</span>
              </div>
            </div>
          )}
        </div>
        <DialogFooter className="flex-col sm:flex-row gap-2 sm:justify-between">
          <Button variant="destructive" onClick={clearCell} disabled={saving} className="sm:mr-auto">
            {cell.kind === "deposit" ? "Sıfırla" : "Boşalt"}
          </Button>
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} disabled={saving}>
              İptal
            </Button>
            <Button onClick={save} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              Kaydet
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function CreateCellDialog({
  request,
  onClose,
  onSaved,
}: {
  request: {
    tenantId: string;
    tenantName: string;
    monthKey: string;
    monthLabel: string;
    rentals: { id: string; plate: string; monthlyRate: number }[];
  } | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [rentalId, setRentalId] = useState<string>("");
  const [amount, setAmount] = useState<string>("");
  const [status, setStatus] = useState<"paid" | "pending" | "partial">("pending");
  const [partialAmount, setPartialAmount] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (request) {
      const first = request.rentals[0];
      setRentalId(first?.id ?? "");
      setAmount(first ? String(first.monthlyRate || "") : "");
      setStatus("pending");
      setPartialAmount("");
    }
  }, [request?.tenantId, request?.monthKey]);

  if (!request) return null;

  function pickRental(id: string) {
    setRentalId(id);
    const r = request!.rentals.find((x) => x.id === id);
    if (r) setAmount(String(r.monthlyRate || ""));
  }

  async function save() {
    if (!request || !rentalId) {
      toast.error("Kiralama seçin");
      return;
    }
    const amt = parseFloat(amount);
    if (!(amt > 0)) {
      toast.error("Tutar 0'dan büyük olmalı");
      return;
    }
    let paid_amount = 0;
    let paid_at: string | null = null;
    if (status === "paid") {
      paid_amount = amt;
      paid_at = new Date().toISOString();
    } else if (status === "partial") {
      paid_amount = parseFloat(partialAmount) || 0;
      if (paid_amount <= 0 || paid_amount >= amt) {
        toast.error("Kısmi tutar 0 ile toplam tutar arasında olmalı");
        return;
      }
      paid_at = new Date().toISOString();
    }
    setSaving(true);
    const due_date = `${request.monthKey}-01`;
    const { error } = await supabase.from("payment_schedule").insert({
      rental_id: rentalId,
      due_date,
      amount: amt,
      paid_amount,
      status,
      paid_at,
    });
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Ödeme eklendi");
    onSaved();
    onClose();
  }

  return (
    <Dialog open={!!request} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Ödeme Ekle</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="text-sm text-muted-foreground">
            {request.tenantName} — {request.monthLabel}
          </div>
          {request.rentals.length > 1 && (
            <div className="space-y-1">
              <Label>Kiralama</Label>
              <Select value={rentalId} onValueChange={pickRental}>
                <SelectTrigger><SelectValue placeholder="Seçin" /></SelectTrigger>
                <SelectContent>
                  {request.rentals.map((r) => (
                    <SelectItem key={r.id} value={r.id}>
                      {r.plate} — {fmtTRY(r.monthlyRate)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          <div className="space-y-1">
            <Label>Tutar (₺)</Label>
            <Input type="number" min="0" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <StatusPill active={status === "paid"} onClick={() => setStatus("paid")} color="emerald" label="Ödendi" />
            <StatusPill active={status === "partial"} onClick={() => setStatus("partial")} color="amber" label="Kısmi" />
            <StatusPill active={status === "pending"} onClick={() => setStatus("pending")} color="red" label="Ödenmedi" />
          </div>
          {status === "partial" && (
            <div className="space-y-1">
              <Label>Ödenen tutar (₺)</Label>
              <Input
                type="number"
                min="0"
                value={partialAmount}
                onChange={(e) => setPartialAmount(e.target.value)}
              />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>İptal</Button>
          <Button onClick={save} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Ekle
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function CreateDepositDialog({
  request,
  onClose,
  onSaved,
}: {
  request: { tenantId: string; tenantName: string; rentals: { id: string; plate: string }[] } | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [rentalId, setRentalId] = useState<string>("");
  const [amount, setAmount] = useState<string>("");
  const [status, setStatus] = useState<"paid" | "pending" | "partial">("pending");
  const [partialAmount, setPartialAmount] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (request) {
      setRentalId(request.rentals[0]?.id ?? "");
      setAmount("");
      setStatus("pending");
      setPartialAmount("");
    }
  }, [request?.tenantId]);

  if (!request) return null;

  async function save() {
    if (!request || !rentalId) {
      toast.error("Kiralama seçin");
      return;
    }
    const amt = parseFloat(amount);
    if (!(amt > 0)) {
      toast.error("Depozito tutarı 0'dan büyük olmalı");
      return;
    }
    let paid_amount = 0;
    let paid_at: string | null = null;
    if (status === "paid") {
      paid_amount = amt;
      paid_at = new Date().toISOString();
    } else if (status === "partial") {
      paid_amount = parseFloat(partialAmount) || 0;
      if (paid_amount <= 0 || paid_amount >= amt) {
        toast.error("Kısmi tutar 0 ile toplam tutar arasında olmalı");
        return;
      }
      paid_at = new Date().toISOString();
    }
    setSaving(true);
    const { error } = await supabase
      .from("rentals")
      .update({
        deposit_amount: amt,
        deposit_status: status,
        deposit_paid_amount: paid_amount,
        deposit_paid_at: paid_at,
      })
      .eq("id", rentalId);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Depozito eklendi");
    onSaved();
    onClose();
  }

  return (
    <Dialog open={!!request} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>Depozito Ekle</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="text-sm text-muted-foreground">{request.tenantName}</div>
          {request.rentals.length > 1 && (
            <div className="space-y-1">
              <Label>Kiralama</Label>
              <Select value={rentalId} onValueChange={setRentalId}>
                <SelectTrigger><SelectValue placeholder="Seçin" /></SelectTrigger>
                <SelectContent>
                  {request.rentals.map((r) => (
                    <SelectItem key={r.id} value={r.id}>{r.plate}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          <div className="space-y-1">
            <Label>Depozito Tutarı (₺)</Label>
            <Input type="number" min="0" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
          <div className="grid grid-cols-3 gap-2">
            <StatusPill active={status === "paid"} onClick={() => setStatus("paid")} color="emerald" label="Ödendi" />
            <StatusPill active={status === "partial"} onClick={() => setStatus("partial")} color="amber" label="Kısmi" />
            <StatusPill active={status === "pending"} onClick={() => setStatus("pending")} color="red" label="Ödenmedi" />
          </div>
          {status === "partial" && (
            <div className="space-y-1">
              <Label>Ödenen tutar (₺)</Label>
              <Input type="number" min="0" value={partialAmount} onChange={(e) => setPartialAmount(e.target.value)} />
            </div>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={saving}>İptal</Button>
          <Button onClick={save} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Ekle
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}


function StatusPill({
  active,
  onClick,
  color,
  label,
}: {
  active: boolean;
  onClick: () => void;
  color: "emerald" | "amber" | "red";
  label: string;
}) {
  const map = {
    emerald: active ? "bg-emerald-500 text-white border-emerald-500" : "border-emerald-500/40 text-emerald-700 dark:text-emerald-300 hover:bg-emerald-500/10",
    amber: active ? "bg-amber-500 text-white border-amber-500" : "border-amber-500/40 text-amber-700 dark:text-amber-300 hover:bg-amber-500/10",
    red: active ? "bg-red-500 text-white border-red-500" : "border-red-500/40 text-red-700 dark:text-red-300 hover:bg-red-500/10",
  };
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded border px-3 py-2 text-sm font-medium transition ${map[color]}`}
    >
      {label}
    </button>
  );
}

/* ================= Monthly summary (chart + totals + table) ================= */

function MonthlySummary({
  range,
  matrixData,
}: {
  range: "1" | "6" | "12" | "24";
  matrixData: { rentByMonth: Record<string, number>; depositTotal: number } | null;
}) {
  // Full range aggregations, matrix-derived
  const financeQuery = useQuery({
    queryKey: ["finance-monthly", range],
    queryFn: async () => {
      const months = parseInt(range, 10);
      const since = startOfMonth(subMonths(new Date(), months - 1));
      const sinceIso = since.toISOString();

      const [paidPayments, paidDeposits, serviceCosts, expenses] = await Promise.all([
        supabase
          .from("payment_schedule")
          .select("paid_amount, due_date, status")
          .in("status", ["paid", "partial"])
          .gte("due_date", since.toISOString().slice(0, 10))
          .lt("due_date", addMonths(since, months).toISOString().slice(0, 10)),
        supabase
          .from("rentals")
          .select("deposit_amount, deposit_paid_amount, deposit_paid_at, deposit_status")
          .in("deposit_status", ["paid", "partial"])
          .gte("deposit_paid_at", sinceIso),
        supabase
          .from("service_records")
          .select("cost, service_date")
          .gte("service_date", since.toISOString().slice(0, 10))
          .lt("service_date", addMonths(since, months).toISOString().slice(0, 10)),
        (supabase as any)
          .from("monthly_expenses")
          .select("kind, amount, month")
          .gte("month", since.toISOString().slice(0, 10))
          .lt("month", addMonths(since, months).toISOString().slice(0, 10)),
      ]);
      if (paidPayments.error) throw paidPayments.error;
      if (paidDeposits.error) throw paidDeposits.error;
      if (serviceCosts.error) throw serviceCosts.error;
      if (expenses.error) throw expenses.error;

      const buckets = new Map<string, MonthRow>();
      for (let i = 0; i < months; i++) {
        const d = startOfMonth(subMonths(new Date(), months - 1 - i));
        const key = format(d, "yyyy-MM");
        buckets.set(key, {
          key,
          label: format(d, "LLL yyyy", { locale: tr }),
          rent: 0,
          deposit: 0,
          maintenance: 0,
          depositRefund: 0,
          net: 0,
        });
      }

      for (const p of paidPayments.data ?? []) {
        const key = format(parseISO(p.due_date), "yyyy-MM");
        const b = buckets.get(key);
        if (b) b.rent += Number(p.paid_amount ?? 0);
      }
      for (const r of paidDeposits.data ?? []) {
        if (!r.deposit_paid_at) continue;
        const key = format(parseISO(r.deposit_paid_at), "yyyy-MM");
        const b = buckets.get(key);
        if (!b) continue;
        b.deposit +=
          r.deposit_status === "paid"
            ? Number(r.deposit_amount ?? 0)
            : Number(r.deposit_paid_amount ?? 0);
      }
      for (const s of serviceCosts.data ?? []) {
        if (!s.cost) continue;
        const key = format(parseISO(s.service_date), "yyyy-MM");
        const b = buckets.get(key);
        if (b) b.maintenance -= Number(s.cost);
      }
      for (const e of (expenses.data ?? []) as ExpenseRow[]) {
        const key = format(parseISO(e.month), "yyyy-MM");
        const b = buckets.get(key);
        if (!b) continue;
        if (e.kind === "maintenance") b.maintenance -= Number(e.amount);
        else b.depositRefund -= Number(e.amount);
      }

      return Array.from(buckets.values()).map((b) => ({
        ...b,
        net: b.rent + b.deposit + b.maintenance + b.depositRefund,
      }));
    },
  });

  const rows = financeQuery.data ?? [];
  const totals = useMemo(
    () =>
      rows.reduce(
        (a, r) => ({
          rent: a.rent + r.rent,
          deposit: a.deposit + r.deposit,
          maintenance: a.maintenance + r.maintenance,
          depositRefund: a.depositRefund + r.depositRefund,
          net: a.net + r.net,
        }),
        { rent: 0, deposit: 0, maintenance: 0, depositRefund: 0, net: 0 },
      ),
    [rows],
  );

  return (
    <>
      <div className="grid gap-4 md:grid-cols-3 lg:grid-cols-5">
        <SummaryCard title="Tahsil Edilen Kira" value={totals.rent} icon={<ArrowUpCircle className="h-4 w-4 text-emerald-500" />} />
        <SummaryCard title="Tahsil Edilen Depozito" value={totals.deposit} icon={<Wallet className="h-4 w-4 text-blue-500" />} />
        <SummaryCard title="Bakım Masrafları" value={totals.maintenance} icon={<Wrench className="h-4 w-4 text-orange-500" />} />
        <SummaryCard title="Depozito İadeleri" value={totals.depositRefund} icon={<ArrowDownCircle className="h-4 w-4 text-rose-500" />} />
        <SummaryCard title="Net Kar" value={totals.net} icon={<TrendingUp className="h-4 w-4 text-primary" />} highlight />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Aylık Grafik</CardTitle>
          <CardDescription>
            Kira vade ayına yazılır. Depozito ödeme gününe göre gösterilir. Bakım ve depozito iadeleri eksi olarak
            görüntülenir; net kar bunları içerir.
          </CardDescription>
        </CardHeader>
        <CardContent>
          {financeQuery.isLoading ? (
            <div className="flex justify-center py-8"><Loader2 className="animate-spin" /></div>
          ) : (
            <div className="h-[340px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={rows}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="label" tick={{ fontSize: 12 }} />
                  <YAxis tick={{ fontSize: 12 }} tickFormatter={(v) => (v >= 1000 ? `${v / 1000}k` : String(v))} />
                  <Tooltip formatter={(v: number) => fmtTRY(v)} contentStyle={{ background: "hsl(var(--popover))", border: "1px solid hsl(var(--border))", borderRadius: 8 }} />
                  <Legend />
                  <Bar dataKey="rent" name="Kira" fill="hsl(var(--primary))" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="deposit" name="Depozito" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="maintenance" name="Bakım" fill="#f97316" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="depositRefund" name="Depozito İadesi" fill="#e11d48" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="net" name="Net Kar" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Aylık Detay</CardTitle></CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-xs uppercase text-muted-foreground">
                <tr>
                  <th className="text-left px-4 py-2">Ay</th>
                  <th className="text-right px-4 py-2">Kira</th>
                  <th className="text-right px-4 py-2">Depozito</th>
                  <th className="text-right px-4 py-2">Bakım</th>
                  <th className="text-right px-4 py-2">Dep. İade</th>
                  <th className="text-right px-4 py-2 font-semibold">Net Kar</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.key} className="border-t">
                    <td className="px-4 py-2 font-medium">{r.label}</td>
                    <td className="px-4 py-2 text-right">{fmtTRY(r.rent)}</td>
                    <td className="px-4 py-2 text-right">{fmtTRY(r.deposit)}</td>
                    <td className="px-4 py-2 text-right text-orange-600">{fmtTRY(r.maintenance)}</td>
                    <td className="px-4 py-2 text-right text-rose-600">{fmtTRY(r.depositRefund)}</td>
                    <td className={`px-4 py-2 text-right font-semibold ${r.net < 0 ? "text-rose-600" : ""}`}>{fmtTRY(r.net)}</td>
                  </tr>
                ))}
                <tr className="border-t bg-muted/30 font-semibold">
                  <td className="px-4 py-2">Toplam</td>
                  <td className="px-4 py-2 text-right">{fmtTRY(totals.rent)}</td>
                  <td className="px-4 py-2 text-right">{fmtTRY(totals.deposit)}</td>
                  <td className="px-4 py-2 text-right text-orange-600">{fmtTRY(totals.maintenance)}</td>
                  <td className="px-4 py-2 text-right text-rose-600">{fmtTRY(totals.depositRefund)}</td>
                  <td className={`px-4 py-2 text-right ${totals.net < 0 ? "text-rose-600" : "text-primary"}`}>{fmtTRY(totals.net)}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {matrixData && null}
    </>
  );
}

function SummaryCard({
  title,
  value,
  icon,
  highlight,
}: {
  title: string;
  value: number;
  icon: React.ReactNode;
  highlight?: boolean;
}) {
  return (
    <Card className={highlight ? "border-primary/50" : undefined}>
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <div className={`text-2xl font-bold ${highlight ? "text-primary" : ""}`}>{fmtTRY(value)}</div>
      </CardContent>
    </Card>
  );
}

function ExpenseDialog({
  request,
  onClose,
  onSaved,
}: {
  request: { monthKey: string; monthLabel: string; editing?: ExpenseRow | null } | null;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [kind, setKind] = useState<ExpenseKind>("maintenance");
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (request) {
      const e = request.editing;
      setKind((e?.kind as ExpenseKind) ?? "maintenance");
      setAmount(e ? String(e.amount) : "");
      setNote(e?.note ?? "");
    }
  }, [request?.monthKey, request?.editing?.id]);

  if (!request) return null;
  const editing = request.editing ?? null;

  async function save() {
    const amt = parseFloat(amount);
    if (!(amt > 0)) {
      toast.error("Tutar 0'dan büyük olmalı");
      return;
    }
    setSaving(true);
    const month = `${request!.monthKey}-01`;
    const payload: any = { kind, amount: amt, note: note.trim() || null, month };
    const client = supabase as any;
    const { error } = editing
      ? await client.from("monthly_expenses").update(payload).eq("id", editing.id)
      : await client.from("monthly_expenses").insert(payload);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(editing ? "Masraf güncellendi" : "Masraf eklendi");
    onSaved();
    onClose();
  }

  async function remove() {
    if (!editing) return;
    setSaving(true);
    const { error } = await (supabase as any).from("monthly_expenses").delete().eq("id", editing.id);
    setSaving(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Masraf silindi");
    onSaved();
    onClose();
  }

  return (
    <Dialog open={!!request} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle>{editing ? "Masrafı Düzenle" : "Masraf Ekle"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="text-sm text-muted-foreground">{request.monthLabel}</div>
          <div className="space-y-1">
            <Label>Tür</Label>
            <Select value={kind} onValueChange={(v) => setKind(v as ExpenseKind)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="deposit_refund">Depozito iade tutarı</SelectItem>
                <SelectItem value="maintenance">Bakım masrafı</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1">
            <Label>Tutar (₺)</Label>
            <Input type="number" min="0" value={amount} onChange={(e) => setAmount(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label>Not (opsiyonel)</Label>
            <Input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Açıklama" />
          </div>
        </div>
        <DialogFooter className="flex-col sm:flex-row gap-2 sm:justify-between">
          {editing ? (
            <Button variant="destructive" onClick={remove} disabled={saving} className="sm:mr-auto">
              Sil
            </Button>
          ) : <div />}
          <div className="flex gap-2">
            <Button variant="outline" onClick={onClose} disabled={saving}>İptal</Button>
            <Button onClick={save} disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {editing ? "Kaydet" : "Ekle"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
