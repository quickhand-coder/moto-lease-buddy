import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getPaymentSettings, updatePaymentSettings } from "@/lib/payment-settings.functions";
import { useSession, useRoles } from "@/lib/auth-hooks";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2 } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/payment-settings")({
  head: () => ({ meta: [{ title: "Ödeme Ayarları — Yönetim" }] }),
  component: PaymentSettingsPage,
});

function PaymentSettingsPage() {
  const { user, loading } = useSession();
  const rolesQ = useRoles(user?.id);
  const isAdmin = rolesQ.data?.includes("admin") ?? false;

  const fetchSettings = useServerFn(getPaymentSettings);
  const updateFn = useServerFn(updatePaymentSettings);
  const qc = useQueryClient();

  const { data } = useQuery({
    queryKey: ["payment-settings"],
    queryFn: () => fetchSettings(),
    enabled: isAdmin,
  });

  const [bank, setBank] = useState("");
  const [holder, setHolder] = useState("");
  const [iban, setIban] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (data) {
      setBank(data.bank_name ?? "");
      setHolder(data.account_holder ?? "");
      setIban(data.iban ?? "");
    }
  }, [data]);

  if (loading || rolesQ.isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="animate-spin" />
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <Card>
        <CardContent className="py-6 text-sm text-muted-foreground text-center">
          Bu sayfa yalnızca yöneticiler için.
        </CardContent>
      </Card>
    );
  }

  async function save() {
    setSaving(true);
    try {
      await updateFn({ data: { bank_name: bank, account_holder: holder, iban } });
      toast.success("Ödeme bilgileri güncellendi");
      qc.invalidateQueries({ queryKey: ["payment-settings"] });
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="space-y-4 max-w-2xl">
      <div>
        <h1 className="text-2xl font-semibold">Ödeme Ayarları</h1>
        <p className="text-sm text-muted-foreground">
          Kiracıların "Ödeme Yap" sayfasında göreceği IBAN bilgileri.
        </p>
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Hesap Bilgileri</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-1.5">
            <Label>Banka Adı</Label>
            <Input value={bank} onChange={(e) => setBank(e.target.value)} placeholder="Örn: Ziraat Bankası" />
          </div>
          <div className="space-y-1.5">
            <Label>Hesap Sahibi</Label>
            <Input value={holder} onChange={(e) => setHolder(e.target.value)} placeholder="Ad Soyad" />
          </div>
          <div className="space-y-1.5">
            <Label>IBAN</Label>
            <Input value={iban} onChange={(e) => setIban(e.target.value)} placeholder="TR00 0000 0000 0000 0000 0000 00" className="font-mono" />
          </div>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
