import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Loader2 } from "lucide-react";
import { format, parseISO, differenceInDays } from "date-fns";

export const Route = createFileRoute("/_authenticated/expirations")({
  head: () => ({ meta: [{ title: "Sigorta & Muayene — MTY Filo" }] }),
  component: ExpirationsPage,
});

function statusColor(dateStr: string | null): string {
  if (!dateStr) return "bg-red-500 text-white font-semibold";
  const days = differenceInDays(parseISO(dateStr), new Date());
  if (days < 0) return "bg-red-500 text-white font-semibold";
  if (days <= 30) return "bg-orange-400 text-white font-semibold";
  if (days <= 90) return "bg-yellow-300 text-neutral-900";
  return "bg-green-400 text-neutral-900";
}

function cell(dateStr: string | null) {
  const cls = statusColor(dateStr);
  const label = dateStr ? format(parseISO(dateStr), "dd.MM.yyyy") : "BİTTİ";
  let extra = "";
  if (dateStr) {
    const d = differenceInDays(parseISO(dateStr), new Date());
    if (d < 0) extra = ` (${-d}g geçti)`;
    else if (d <= 90) extra = ` (${d}g)`;
  }
  return <td className={`px-3 py-2 text-center text-sm ${cls}`}>{label}{extra}</td>;
}

function ExpirationsPage() {
  const { data, isLoading } = useQuery({
    queryKey: ["motos-expirations"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("motorcycles")
        .select("id, plate, insurance_start, insurance_end, inspection_end")
        .order("plate");
      if (error) throw error;
      return data;
    },
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-semibold">Sigorta & Muayene Takibi</h1>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Renk açıklaması</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2 text-sm">
          <span className="px-3 py-1 rounded bg-green-400 text-neutral-900">90+ gün</span>
          <span className="px-3 py-1 rounded bg-yellow-300 text-neutral-900">≤ 90 gün</span>
          <span className="px-3 py-1 rounded bg-orange-400 text-white">≤ 30 gün</span>
          <span className="px-3 py-1 rounded bg-red-500 text-white">Bitmiş / Yok</span>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {isLoading ? (
            <div className="flex justify-center py-10"><Loader2 className="h-5 w-5 animate-spin" /></div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-neutral-900 text-white">
                    <th className="px-3 py-2 text-left text-sm">PLAKA</th>
                    <th className="px-3 py-2 text-center text-sm">Sigorta Başlangıç</th>
                    <th className="px-3 py-2 text-center text-sm">Sigorta Bitiş</th>
                    <th className="px-3 py-2 text-center text-sm">Muayene Bitiş</th>
                  </tr>
                </thead>
                <tbody>
                  {data?.map((m) => (
                    <tr key={m.id} className="border-b border-neutral-200">
                      <td className="px-3 py-2 font-mono font-semibold text-sm">{m.plate}</td>
                      {cell(m.insurance_start)}
                      {cell(m.insurance_end)}
                      {cell(m.inspection_end)}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
