import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useSession, useRoles } from "@/lib/auth-hooks";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Loader2, Pencil, Trash2, ExternalLink } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_authenticated/admin")({
  head: () => ({ meta: [{ title: "Yönetim — Kira Takip" }] }),
  component: AdminPage,
});

type TableKey =
  | "motorcycles"
  | "tenants"
  | "rentals"
  | "payment_schedule"
  | "service_records"
  | "notifications"
  | "user_roles"
  | "profiles";

type TableCfg = {
  key: TableKey;
  label: string;
  summary: (row: Record<string, unknown>) => string;
  detailHref?: (row: Record<string, unknown>) => string | null;
  orderBy?: { column: string; ascending?: boolean };
};

const TABLES: TableCfg[] = [
  {
    key: "motorcycles",
    label: "Motosikletler",
    summary: (r) => `${r.plate} · ${r.brand} ${r.model}`,
    detailHref: (r) => `/motorcycles/${r.id}`,
    orderBy: { column: "created_at", ascending: false },
  },
  {
    key: "tenants",
    label: "Kiracılar",
    summary: (r) => `${r.full_name}${r.phone ? ` · ${r.phone}` : ""}`,
    orderBy: { column: "created_at", ascending: false },
  },
  {
    key: "rentals",
    label: "Kiralar",
    summary: (r) => `${r.start_date} → ${r.end_date} · ${r.status}`,
    detailHref: (r) => `/rentals/${r.id}`,
    orderBy: { column: "created_at", ascending: false },
  },
  {
    key: "payment_schedule",
    label: "Ödemeler",
    summary: (r) => `${r.due_date} · ${r.amount}₺ · ${r.status}`,
    orderBy: { column: "due_date", ascending: true },
  },
  {
    key: "service_records",
    label: "Bakım Kayıtları",
    summary: (r) => `${r.service_date} · ${String(r.description).slice(0, 40)}`,
    orderBy: { column: "service_date", ascending: false },
  },
  {
    key: "notifications",
    label: "Bildirimler",
    summary: (r) => `${r.type} · ${r.title}`,
    orderBy: { column: "created_at", ascending: false },
  },
  {
    key: "user_roles",
    label: "Kullanıcı Rolleri",
    summary: (r) => `${r.role} · ${r.user_id}`,
  },
  {
    key: "profiles",
    label: "Profiller",
    summary: (r) => `${r.full_name ?? "—"} · ${r.phone ?? "—"}`,
  },
];

const READONLY_KEYS = new Set(["id", "created_at", "updated_at"]);

function AdminPage() {
  const { user, loading } = useSession();
  const rolesQuery = useRoles(user?.id);
  const isAdmin = rolesQuery.data?.includes("admin") ?? false;

  if (loading || rolesQuery.isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader2 className="animate-spin" />
      </div>
    );
  }
  if (!isAdmin) {
    return (
      <div className="space-y-4">
        <h1 className="text-2xl font-semibold">Yönetim</h1>
        <Card>
          <CardContent className="py-6 text-sm text-muted-foreground text-center">
            Bu sayfa yalnızca yönetici hesapları için erişilebilir.
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-semibold">Yönetim</h1>
        <p className="text-sm text-muted-foreground">
          Tüm tablolara doğrudan erişim. Her satırı görüntüleyebilir, düzenleyebilir veya silebilirsin.
        </p>
      </div>

      <Tabs defaultValue="motorcycles">
        <TabsList className="flex flex-wrap h-auto">
          {TABLES.map((t) => (
            <TabsTrigger key={t.key} value={t.key}>
              {t.label}
            </TabsTrigger>
          ))}
        </TabsList>
        {TABLES.map((t) => (
          <TabsContent key={t.key} value={t.key} className="mt-4">
            <TablePanel cfg={t} />
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}

function TablePanel({ cfg }: { cfg: TableCfg }) {
  const qc = useQueryClient();
  const [search, setSearch] = useState("");

  const { data, isLoading, error } = useQuery({
    queryKey: ["admin-table", cfg.key],
    queryFn: async () => {
      let q = supabase.from(cfg.key).select("*").limit(500);
      if (cfg.orderBy) q = q.order(cfg.orderBy.column, { ascending: cfg.orderBy.ascending ?? true });
      const { data, error } = await q;
      if (error) throw error;
      return (data ?? []) as Record<string, unknown>[];
    },
  });

  const filtered = useMemo(() => {
    if (!data) return [];
    if (!search.trim()) return data;
    const s = search.toLowerCase();
    return data.filter((row) =>
      Object.values(row).some((v) => v != null && String(v).toLowerCase().includes(s)),
    );
  }, [data, search]);

  async function handleDelete(id: string) {
    const { error } = await supabase.from(cfg.key).delete().eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Kayıt silindi");
    qc.invalidateQueries({ queryKey: ["admin-table", cfg.key] });
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2">
        <CardTitle className="text-base">{cfg.label}</CardTitle>
        <Input
          placeholder="Ara..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="max-w-xs"
        />
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <Loader2 className="mx-auto animate-spin" />
        ) : error ? (
          <p className="text-sm text-destructive">{(error as Error).message}</p>
        ) : !filtered.length ? (
          <p className="text-sm text-muted-foreground py-4 text-center">Kayıt yok.</p>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Özet</TableHead>
                  <TableHead className="w-[220px]">ID</TableHead>
                  <TableHead className="w-[200px] text-right">İşlemler</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((row) => {
                  const id = String(row.id ?? "");
                  const href = cfg.detailHref?.(row) ?? null;
                  return (
                    <TableRow key={id || JSON.stringify(row)}>
                      <TableCell className="max-w-[400px] truncate">{cfg.summary(row)}</TableCell>
                      <TableCell className="font-mono text-xs text-muted-foreground truncate">{id}</TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-1">
                          {href && (
                            <Button asChild size="sm" variant="ghost">
                              <Link to={href}>
                                <ExternalLink className="h-3.5 w-3.5" />
                              </Link>
                            </Button>
                          )}
                          <EditRowDialog cfg={cfg} row={row} />
                          {id && (
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive">
                                  <Trash2 className="h-3.5 w-3.5" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>Kaydı sil?</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    Bu kayıt kalıcı olarak silinecek. Bu işlem geri alınamaz.
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>İptal</AlertDialogCancel>
                                  <AlertDialogAction
                                    className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
                                    onClick={() => handleDelete(id)}
                                  >
                                    Sil
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
        <div className="text-xs text-muted-foreground mt-2">
          {filtered.length} kayıt gösteriliyor{data && data.length !== filtered.length ? ` (toplam ${data.length})` : ""}.
        </div>
      </CardContent>
    </Card>
  );
}

function EditRowDialog({ cfg, row }: { cfg: TableCfg; row: Record<string, unknown> }) {
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const editable = useMemo(() => {
    const out: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(row)) {
      if (READONLY_KEYS.has(k)) continue;
      out[k] = v;
    }
    return out;
  }, [row]);
  const [text, setText] = useState(() => JSON.stringify(editable, null, 2));
  const [saving, setSaving] = useState(false);

  async function save() {
    setSaving(true);
    try {
      let parsed: Record<string, unknown>;
      try {
        parsed = JSON.parse(text);
      } catch (err) {
        toast.error("Geçersiz JSON: " + (err as Error).message);
        return;
      }
      const id = String(row.id ?? "");
      if (!id) {
        toast.error("Bu kaydın ID'si yok, güncellenemez.");
        return;
      }
      // strip readonly just in case
      for (const k of READONLY_KEYS) delete parsed[k];
      const { error } = await (supabase.from(cfg.key) as any).update(parsed).eq("id", id);
      if (error) {
        toast.error(error.message);
        return;
      }
      toast.success("Güncellendi");
      qc.invalidateQueries({ queryKey: ["admin-table", cfg.key] });
      setOpen(false);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (v) setText(JSON.stringify(editable, null, 2));
      }}
    >
      <Button size="sm" variant="ghost" onClick={() => setOpen(true)}>
        <Pencil className="h-3.5 w-3.5" />
      </Button>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Kaydı Düzenle</DialogTitle>
        </DialogHeader>
        <div className="text-xs text-muted-foreground">
          JSON formatında düzenle. <code>id</code>, <code>created_at</code>, <code>updated_at</code>{" "}
          alanları otomatik korunur.
        </div>
        <Textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="font-mono text-xs h-[420px]"
          spellCheck={false}
        />
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>
            İptal
          </Button>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}