import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ArrowLeft, Loader2, Plus, Pencil, ImageIcon, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { format, parseISO } from "date-fns";
import { useSession, useRoles, hasAnyRole } from "@/lib/auth-hooks";
import { EditMotoDialog } from "@/components/edit-moto-dialog";

export const Route = createFileRoute("/_authenticated/motorcycles/$id")({
  head: () => ({ meta: [{ title: "Motosiklet Detay — Kira Takip" }] }),
  component: MotoDetail,
});

function MotoDetail() {
  const { id } = Route.useParams();
  const qc = useQueryClient();
  const { user } = useSession();
  const rolesQ = useRoles(user?.id);
  const isAdmin = hasAnyRole(rolesQ.data, ["admin"]);

  const moto = useQuery({
    queryKey: ["moto", id],
    queryFn: async () => {
      const { data, error } = await supabase.from("motorcycles").select("*").eq("id", id).single();
      if (error) throw error;
      return data;
    },
  });

  const services = useQuery({
    queryKey: ["moto-services", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("service_records")
        .select("*")
        .eq("motorcycle_id", id)
        .order("service_date", { ascending: false });
      if (error) throw error;
      return data;
    },
  });

  if (moto.isLoading) return <div className="flex justify-center py-8"><Loader2 className="animate-spin" /></div>;
  if (!moto.data) return <p>Motosiklet bulunamadı.</p>;

  const m = moto.data;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Button asChild variant="ghost" size="sm">
          <Link to="/motorcycles"><ArrowLeft className="h-4 w-4 mr-1" />Geri</Link>
        </Button>
        <h1 className="text-2xl font-semibold">{m.plate} — {m.brand} {m.model}</h1>
        <EditMotoDialog moto={m} onDone={() => qc.invalidateQueries({ queryKey: ["moto", id] })} />
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader><CardTitle>Araç Bilgileri</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Info label="Plaka" value={m.plate} />
            <Info label="Marka / Model" value={`${m.brand} ${m.model}`} />
            <Info label="Yıl" value={m.year} />
            <Info label="Renk" value={m.color} />
            <Info label="Güncel KM" value={m.current_km.toLocaleString("tr-TR")} />
            <Info label="Durum" value={<Badge variant="secondary">{m.status}</Badge>} />
            <Info label="Notlar" value={m.notes} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>Sigorta & Muayene</CardTitle></CardHeader>
          <CardContent className="space-y-2 text-sm">
            <Info label="Sigorta Başlangıç" value={m.insurance_start ? format(parseISO(m.insurance_start), "dd.MM.yyyy") : "—"} />
            <Info label="Sigorta Bitiş" value={m.insurance_end ? format(parseISO(m.insurance_end), "dd.MM.yyyy") : "—"} />
            <Info label="Muayene Başlangıç" value={m.inspection_start ? format(parseISO(m.inspection_start), "dd.MM.yyyy") : "—"} />
            <Info label="Muayene Bitiş" value={m.inspection_end ? format(parseISO(m.inspection_end), "dd.MM.yyyy") : "—"} />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Servis / Bakım Geçmişi</CardTitle>
            <p className="text-xs text-muted-foreground mt-1">
              Bakım kayıtları motosikletin plakasına bağlıdır ve silinmez. {isAdmin ? "Admin olarak kayıtları düzenleyip silebilirsiniz." : "Yalnızca yeni kayıt ekleyebilirsiniz — düzenleme/silme sadece admin yetkisindedir."}
            </p>
          </div>
          <ServiceDialog motoId={id} defaultKm={m.current_km} onDone={() => qc.invalidateQueries({ queryKey: ["moto-services", id] })} />
        </CardHeader>
        <CardContent>
          {!services.data?.length ? (
            <p className="text-sm text-muted-foreground">Servis kaydı yok.</p>
          ) : (
            <ul className="divide-y">
              {services.data.map((s) => (
                <li key={s.id} className="py-3 flex gap-3 items-start">
                  <ServicePhoto path={s.photo_url} />
                  <div className="flex-1 min-w-0">
                    <div className="font-medium">{s.description}</div>
                    <div className="text-xs text-muted-foreground">
                      {format(parseISO(s.service_date), "dd.MM.yyyy")} · {s.km_at_service.toLocaleString("tr-TR")} km
                    </div>
                  </div>
                  {s.cost != null && <div className="text-sm shrink-0">{Number(s.cost).toLocaleString("tr-TR")} ₺</div>}
                  {isAdmin && (
                    <>
                      <EditServiceDialog
                        record={s}
                        onDone={() => qc.invalidateQueries({ queryKey: ["moto-services", id] })}
                      />
                      <Button
                        size="icon"
                        variant="ghost"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={async () => {
                          if (!confirm("Bu bakım kaydını silmek istiyor musunuz? (yalnızca admin)")) return;
                          const { error } = await supabase.from("service_records").delete().eq("id", s.id);
                          if (error) { toast.error(error.message); return; }
                          toast.success("Bakım kaydı silindi");
                          qc.invalidateQueries({ queryKey: ["moto-services", id] });
                        }}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </>
                  )}
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function ServicePhoto({ path }: { path: string | null }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!path) return;
    let active = true;
    supabase.storage.from("motorcycle-photos").createSignedUrl(path, 3600).then(({ data }) => {
      if (active && data?.signedUrl) setUrl(data.signedUrl);
    });
    return () => { active = false; };
  }, [path]);
  if (!path) {
    return <div className="w-16 h-16 rounded bg-muted flex items-center justify-center text-muted-foreground shrink-0"><ImageIcon className="h-5 w-5" /></div>;
  }
  return (
    <a href={url ?? "#"} target="_blank" rel="noreferrer" className="shrink-0">
      {url ? <img src={url} alt="Bakım" className="w-16 h-16 object-cover rounded" /> : <div className="w-16 h-16 rounded bg-muted animate-pulse" />}
    </a>
  );
}

function Info({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex justify-between border-b border-dashed py-1">
      <span className="text-muted-foreground">{label}</span>
      <span className="font-medium">{value ?? "—"}</span>
    </div>
  );
}

function ServiceDialog({ motoId, defaultKm, onDone }: { motoId: string; defaultKm?: number; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ service_date: format(new Date(), "yyyy-MM-dd"), km_at_service: defaultKm ? String(defaultKm) : "", description: "", cost: "" });
  const [photo, setPhoto] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const km = parseInt(form.km_at_service);
    let photo_url: string | null = null;
    if (photo) {
      const ext = photo.name.split(".").pop() || "jpg";
      const path = `service/${motoId}/${Date.now()}.${ext}`;
      const up = await supabase.storage.from("motorcycle-photos").upload(path, photo, { upsert: false });
      if (up.error) { setSaving(false); toast.error("Fotoğraf yüklenemedi", { description: up.error.message }); return; }
      photo_url = up.data.path;
    }
    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from("service_records").insert({
      motorcycle_id: motoId,
      service_date: form.service_date,
      km_at_service: km,
      description: form.description,
      cost: form.cost ? parseFloat(form.cost) : null,
      photo_url,
      created_by: userData.user?.id ?? null,
    });
    if (!error) {
      await supabase.from("motorcycles").update({ current_km: km }).eq("id", motoId).lt("current_km", km);
    }
    setSaving(false);
    if (error) { toast.error("Kaydedilemedi", { description: error.message }); return; }
    toast.success("Bakım kaydı eklendi");
    setOpen(false);
    setForm({ service_date: format(new Date(), "yyyy-MM-dd"), km_at_service: "", description: "", cost: "" });
    setPhoto(null);
    onDone();
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline"><Plus className="h-4 w-4 mr-1" />Yeni Bakım Ekle</Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Yeni Bakım Kaydı</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Tarih</Label><Input type="date" required value={form.service_date} onChange={(e) => setForm({ ...form, service_date: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>KM</Label><Input type="number" required value={form.km_at_service} onChange={(e) => setForm({ ...form, km_at_service: e.target.value })} /></div>
          </div>
          <div className="space-y-1.5"><Label>Not / Açıklama</Label><Textarea required rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Ücret (₺)</Label><Input type="number" step="0.01" value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Fotoğraf (opsiyonel)</Label><Input type="file" accept="image/*" onChange={(e) => setPhoto(e.target.files?.[0] ?? null)} /></div>
          <DialogFooter><Button type="submit" disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

type ServiceRecord = {
  id: string;
  service_date: string;
  km_at_service: number;
  description: string;
  cost: number | null;
  photo_url: string | null;
};

function EditServiceDialog({ record, onDone }: { record: ServiceRecord; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    service_date: record.service_date,
    km_at_service: String(record.km_at_service),
    description: record.description,
    cost: record.cost != null ? String(record.cost) : "",
  });
  const [saving, setSaving] = useState(false);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase.from("service_records").update({
      service_date: form.service_date,
      km_at_service: parseInt(form.km_at_service),
      description: form.description,
      cost: form.cost ? parseFloat(form.cost) : null,
    }).eq("id", record.id);
    setSaving(false);
    if (error) { toast.error("Kaydedilemedi", { description: error.message }); return; }
    toast.success("Bakım kaydı güncellendi");
    setOpen(false);
    onDone();
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="icon" variant="ghost" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Bakım Kaydını Düzenle</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Tarih</Label><Input type="date" required value={form.service_date} onChange={(e) => setForm({ ...form, service_date: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>KM</Label><Input type="number" required value={form.km_at_service} onChange={(e) => setForm({ ...form, km_at_service: e.target.value })} /></div>
          </div>
          <div className="space-y-1.5"><Label>Not / Açıklama</Label><Textarea required rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} /></div>
          <div className="space-y-1.5"><Label>Ücret (₺)</Label><Input type="number" step="0.01" value={form.cost} onChange={(e) => setForm({ ...form, cost: e.target.value })} /></div>
          <DialogFooter><Button type="submit" disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
