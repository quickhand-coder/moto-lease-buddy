import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Loader2, Pencil, Trash2, Image as ImageIcon, Wrench, Plus } from "lucide-react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";

const SERVICE_TYPES = [
  "Yağ Değişimi",
  "Kayış Değişimi",
  "Ön Balata Değişimi",
  "Arka Balata Değişimi",
  "Müşür Değişimi",
  "Ön Lastik Değişimi",
  "Arka Lastik Değişimi",
  "Motor Yapıldı",
] as const;

type ServiceRecord = {
  id: string;
  motorcycle_id: string;
  service_date: string;
  km_at_service: number;
  description: string | null;
  photo_url: string | null;
};

export const Route = createFileRoute("/_authenticated/service-records")({
  head: () => ({ meta: [{ title: "Bakımlar — MTY Filo" }] }),
  component: ServiceRecordsPage,
});

function ServiceRecordsPage() {
  const qc = useQueryClient();
  const [motorcycleId, setMotorcycleId] = useState<string>("");

  const motos = useQuery({
    queryKey: ["motorcycles-select"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("motorcycles")
        .select("id, plate, brand, model")
        .order("plate");
      if (error) throw error;
      return data ?? [];
    },
  });

  const services = useQuery({
    queryKey: ["service-records", motorcycleId],
    enabled: !!motorcycleId,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("service_records")
        .select("*")
        .eq("motorcycle_id", motorcycleId)
        .order("service_date", { ascending: false })
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data ?? []) as ServiceRecord[];
    },
  });

  const selectedMoto = motos.data?.find((m) => m.id === motorcycleId);

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Wrench className="h-5 w-5" />
        <h1 className="text-2xl font-semibold">Bakımlar</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Motosiklet Seçin</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="max-w-md space-y-1.5">
            <Label>Plaka</Label>
            <Select value={motorcycleId} onValueChange={setMotorcycleId}>
              <SelectTrigger>
                <SelectValue placeholder="Plakaya göre motosiklet seçin" />
              </SelectTrigger>
              <SelectContent>
                {motos.isLoading ? (
                  <div className="px-2 py-1.5 text-sm text-muted-foreground">Yükleniyor…</div>
                ) : !motos.data?.length ? (
                  <div className="px-2 py-1.5 text-sm text-muted-foreground">Motosiklet yok</div>
                ) : (
                  motos.data.map((m) => (
                    <SelectItem key={m.id} value={m.id}>
                      {m.plate} — {m.brand} {m.model}
                    </SelectItem>
                  ))
                )}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {!motorcycleId ? (
        <Card>
          <CardContent className="py-8 text-sm text-muted-foreground text-center">
            Bakım geçmişini görmek için bir motosiklet seçin.
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between gap-2 space-y-0">
            <CardTitle className="text-base">
              {selectedMoto ? `${selectedMoto.plate} — ${selectedMoto.brand} ${selectedMoto.model}` : "Bakım Geçmişi"}
            </CardTitle>
            <AddServiceDialog
              motorcycleId={motorcycleId}
              currentKm={0}
              lastServiceKm={services.data?.[0]?.km_at_service ?? 0}
              onDone={() => qc.invalidateQueries({ queryKey: ["service-records", motorcycleId] })}
            />
          </CardHeader>
          <CardContent>
            {services.isLoading ? (
              <div className="flex justify-center py-6">
                <Loader2 className="animate-spin text-muted-foreground" />
              </div>
            ) : !services.data?.length ? (
              <p className="text-sm text-muted-foreground text-center py-6">
                Bu motosiklet için bakım kaydı bulunmuyor.
              </p>
            ) : (
              <ul className="divide-y">
                {services.data.map((s) => (
                  <ServiceRow
                    key={s.id}
                    record={s}
                    onChanged={() =>
                      qc.invalidateQueries({ queryKey: ["service-records", motorcycleId] })
                    }
                  />
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function AddServiceDialog({
  motorcycleId,
  lastServiceKm,
  onDone,
}: {
  motorcycleId: string;
  currentKm: number;
  lastServiceKm: number;
  onDone: () => void;
}) {
  const [open, setOpen] = useState(false);
  const [date, setDate] = useState(format(new Date(), "yyyy-MM-dd"));
  const [kmStr, setKmStr] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [note, setNote] = useState("");
  const [photo, setPhoto] = useState<File | null>(null);
  const [saving, setSaving] = useState(false);

  function toggleType(type: string) {
    setSelected((prev) => (prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]));
  }

  function resetForm() {
    setDate(format(new Date(), "yyyy-MM-dd"));
    setKmStr("");
    setSelected([]);
    setNote("");
    setPhoto(null);
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (selected.length === 0 && !note.trim()) {
      toast.error("En az bir bakım türü seçin veya not ekleyin");
      return;
    }
    const km = parseInt(kmStr);
    if (Number.isNaN(km)) {
      toast.error("KM bilgisi geçersiz");
      return;
    }
    if (lastServiceKm > 0 && km < lastServiceKm) {
      toast.error(
        `KM son bakım kilometresinden (${lastServiceKm.toLocaleString("tr-TR")} km) düşük olamaz`,
      );
      return;
    }
    setSaving(true);

    let photo_url: string | null = null;
    if (photo) {
      const ext = photo.name.split(".").pop() || "jpg";
      const path = `service/${motorcycleId}/${Date.now()}.${ext}`;
      const up = await supabase.storage.from("motorcycle-photos").upload(path, photo, { upsert: false });
      if (up.error) {
        setSaving(false);
        toast.error("Fotoğraf yüklenemedi", { description: up.error.message });
        return;
      }
      photo_url = up.data.path;
    }

    const description = [
      selected.join(", "),
      note.trim() ? `Not: ${note.trim()}` : "",
    ]
      .filter(Boolean)
      .join("\n\n");

    const { data: userData } = await supabase.auth.getUser();
    const { error } = await supabase.from("service_records").insert({
      motorcycle_id: motorcycleId,
      service_date: date,
      km_at_service: km,
      description,
      photo_url,
      created_by: userData.user?.id ?? null,
    });
    if (!error) {
      await supabase.from("motorcycles").update({ current_km: km }).eq("id", motorcycleId).lt("current_km", km);
    }
    setSaving(false);
    if (error) {
      toast.error("Kaydedilemedi", { description: error.message });
      return;
    }
    toast.success("Bakım kaydı eklendi");
    setOpen(false);
    resetForm();
    onDone();
  }

  return (
    <Dialog open={open} onOpenChange={(o) => { setOpen(o); if (!o) resetForm(); }}>
      <DialogTrigger asChild>
        <Button size="sm">
          <Plus className="h-4 w-4 mr-1" /> Bakım Ekle
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Yeni Bakım Kaydı</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Tarih *</Label>
              <Input type="date" required value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>KM *</Label>
              <Input
                type="number"
                required
                inputMode="numeric"
                value={kmStr}
                onChange={(e) => setKmStr(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Bakım Türü</Label>
            <div className="rounded-md border divide-y">
              {SERVICE_TYPES.map((type) => {
                const checked = selected.includes(type);
                return (
                  <label
                    key={type}
                    className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-muted/50"
                  >
                    <Checkbox checked={checked} onCheckedChange={() => toggleType(type)} />
                    <span className="text-sm">{type}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Not</Label>
            <Textarea
              rows={3}
              placeholder="Harici yapılan işlemleri lütfen buraya yazınız."
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Fotoğraf (opsiyonel)</Label>
            <Input type="file" accept="image/*" onChange={(e) => setPhoto(e.target.files?.[0] ?? null)} />
          </div>

          <DialogFooter>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function parseDescription(description: string | null): { types: string[]; note: string } {
  const text = description ?? "";
  const types: string[] = [];
  for (const t of SERVICE_TYPES) if (text.includes(t)) types.push(t);
  const noteMatch = text.match(/Not:\s*([\s\S]*)$/);
  const note = noteMatch ? noteMatch[1].trim() : "";
  // If no known type found and no "Not:" prefix, treat the whole text as a note.
  if (types.length === 0 && !noteMatch) return { types: [], note: text.trim() };
  return { types, note };
}

function ServiceRow({ record, onChanged }: { record: ServiceRecord; onChanged: () => void }) {
  const parsed = parseDescription(record.description);
  return (
    <li className="py-3 flex gap-3 items-start">
      <ServicePhoto path={record.photo_url} />
      <div className="flex-1 min-w-0 space-y-1">
        <div className="text-xs text-muted-foreground">
          {format(parseISO(record.service_date), "dd.MM.yyyy")} · {record.km_at_service.toLocaleString("tr-TR")} km
        </div>
        {parsed.types.length > 0 && (
          <div className="flex flex-wrap gap-1">
            {parsed.types.map((t) => (
              <span
                key={t}
                className="inline-flex items-center rounded-md bg-primary/10 text-primary px-2 py-0.5 text-xs font-medium"
              >
                {t}
              </span>
            ))}
          </div>
        )}
        {parsed.note && (
          <p className="text-sm whitespace-pre-wrap">
            <span className="text-muted-foreground">Not: </span>
            {parsed.note}
          </p>
        )}
      </div>
      <div className="flex flex-col gap-1 shrink-0">
        <EditServiceDialog record={record} onDone={onChanged} />
        <DeleteServiceButton record={record} onDone={onChanged} />
      </div>
    </li>
  );
}

function ServicePhoto({ path }: { path: string | null }) {
  const [url, setUrl] = useState<string | null>(null);
  useEffect(() => {
    if (!path) return;
    let active = true;
    supabase.storage
      .from("motorcycle-photos")
      .createSignedUrl(path, 3600)
      .then(({ data }) => {
        if (active && data?.signedUrl) setUrl(data.signedUrl);
      });
    return () => {
      active = false;
    };
  }, [path]);
  if (!path) {
    return (
      <div className="w-16 h-16 rounded bg-muted flex items-center justify-center text-muted-foreground shrink-0">
        <ImageIcon className="h-5 w-5" />
      </div>
    );
  }
  return (
    <a href={url ?? "#"} target="_blank" rel="noreferrer" className="shrink-0">
      {url ? (
        <img src={url} alt="Bakım" className="w-16 h-16 object-cover rounded" />
      ) : (
        <div className="w-16 h-16 rounded bg-muted animate-pulse" />
      )}
    </a>
  );
}

function EditServiceDialog({ record, onDone }: { record: ServiceRecord; onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const initial = parseDescription(record.description);
  const [date, setDate] = useState(record.service_date);
  const [kmStr, setKmStr] = useState(String(record.km_at_service));
  const [selected, setSelected] = useState<string[]>(initial.types);
  const [note, setNote] = useState(initial.note);
  const [photo, setPhoto] = useState<File | null>(null);
  const [removePhoto, setRemovePhoto] = useState(false);
  const [saving, setSaving] = useState(false);

  function toggleType(type: string) {
    setSelected((prev) => (prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]));
  }

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    const km = parseInt(kmStr);
    if (Number.isNaN(km)) {
      toast.error("KM bilgisi geçersiz");
      return;
    }
    if (selected.length === 0 && !note.trim()) {
      toast.error("En az bir bakım türü seçin veya not ekleyin");
      return;
    }
    setSaving(true);

    let photo_url: string | null = record.photo_url;
    if (removePhoto) photo_url = null;
    if (photo) {
      const ext = photo.name.split(".").pop() || "jpg";
      const path = `service/${record.motorcycle_id}/${Date.now()}.${ext}`;
      const up = await supabase.storage.from("motorcycle-photos").upload(path, photo, { upsert: false });
      if (up.error) {
        setSaving(false);
        toast.error("Fotoğraf yüklenemedi", { description: up.error.message });
        return;
      }
      photo_url = up.data.path;
    }

    const description = [
      selected.join(", "),
      note.trim() ? `Not: ${note.trim()}` : "",
    ]
      .filter(Boolean)
      .join("\n\n");

    const { error } = await supabase
      .from("service_records")
      .update({
        service_date: date,
        km_at_service: km,
        description,
        photo_url,
      })
      .eq("id", record.id);

    setSaving(false);
    if (error) {
      toast.error("Güncellenemedi", { description: error.message });
      return;
    }
    toast.success("Bakım kaydı güncellendi");
    setOpen(false);
    onDone();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <Button
        type="button"
        size="icon"
        variant="ghost"
        className="h-8 w-8"
        onClick={() => setOpen(true)}
      >
        <Pencil className="h-4 w-4" />
      </Button>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Bakım Kaydını Düzenle</DialogTitle>
        </DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Tarih *</Label>
              <Input type="date" required value={date} onChange={(e) => setDate(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label>KM *</Label>
              <Input
                type="number"
                required
                inputMode="numeric"
                value={kmStr}
                onChange={(e) => setKmStr(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Bakım Türü</Label>
            <div className="rounded-md border divide-y">
              {SERVICE_TYPES.map((type) => {
                const checked = selected.includes(type);
                return (
                  <label
                    key={type}
                    className="flex items-center gap-3 px-3 py-2 cursor-pointer hover:bg-muted/50"
                  >
                    <Checkbox checked={checked} onCheckedChange={() => toggleType(type)} />
                    <span className="text-sm">{type}</span>
                  </label>
                );
              })}
            </div>
          </div>

          <div className="space-y-1.5">
            <Label>Not</Label>
            <Textarea
              rows={3}
              placeholder="Harici yapılan işlemleri lütfen buraya yazınız."
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>

          <div className="space-y-1.5">
            <Label>Fotoğraf</Label>
            {record.photo_url && !removePhoto && (
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>Mevcut fotoğraf yüklü.</span>
                <button
                  type="button"
                  className="underline"
                  onClick={() => setRemovePhoto(true)}
                >
                  Kaldır
                </button>
              </div>
            )}
            <Input type="file" accept="image/*" onChange={(e) => setPhoto(e.target.files?.[0] ?? null)} />
            <p className="text-xs text-muted-foreground">Yeni bir dosya seçerseniz mevcut fotoğrafın yerine geçer.</p>
          </div>

          <DialogFooter>
            <Button type="submit" disabled={saving}>
              {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function DeleteServiceButton({ record, onDone }: { record: ServiceRecord; onDone: () => void }) {
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button size="icon" variant="ghost" className="h-8 w-8 text-destructive hover:text-destructive">
          <Trash2 className="h-4 w-4" />
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Bakım kaydını sil?</AlertDialogTitle>
          <AlertDialogDescription>
            {format(parseISO(record.service_date), "dd.MM.yyyy")} tarihli bakım kaydı kalıcı olarak silinecek.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>İptal</AlertDialogCancel>
          <AlertDialogAction
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            onClick={async () => {
              const { error } = await supabase.from("service_records").delete().eq("id", record.id);
              if (error) {
                toast.error("Silinemedi", { description: error.message });
                return;
              }
              toast.success("Bakım kaydı silindi");
              onDone();
            }}
          >
            Sil
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
