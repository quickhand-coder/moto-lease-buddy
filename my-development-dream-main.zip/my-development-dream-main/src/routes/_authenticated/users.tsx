import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Plus, Loader2, KeyRound, Ban, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import {
  createAppUser,
  listAppUsers,
  resetUserPassword,
  setUserActive,
} from "@/lib/admin-users.functions";

export const Route = createFileRoute("/_authenticated/users")({
  head: () => ({ meta: [{ title: "Kullanıcılar — Kira Takip" }] }),
  component: UsersPage,
});

function UsersPage() {
  const qc = useQueryClient();
  const list = useServerFn(listAppUsers);
  const setActive = useServerFn(setUserActive);

  const { data, isLoading } = useQuery({
    queryKey: ["app-users"],
    queryFn: () => list(),
  });

  async function toggleActive(userId: string, active: boolean) {
    try {
      await setActive({ data: { userId, active } });
      toast.success(active ? "Aktifleştirildi" : "Pasifleştirildi");
      qc.invalidateQueries({ queryKey: ["app-users"] });
    } catch (e) { toast.error((e as Error).message); }
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Kullanıcılar</h1>
        <NewUserDialog onDone={() => qc.invalidateQueries({ queryKey: ["app-users"] })} />
      </div>
      <Card>
        <CardHeader><CardTitle>Sistem Kullanıcıları</CardTitle></CardHeader>
        <CardContent>
          {isLoading ? <Loader2 className="mx-auto my-6 animate-spin" /> : !data?.length ? (
            <p className="text-sm text-muted-foreground">Kullanıcı yok.</p>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader><TableRow>
                  <TableHead>Ad</TableHead><TableHead>E-posta</TableHead><TableHead>Roller</TableHead>
                  <TableHead>Durum</TableHead><TableHead />
                </TableRow></TableHeader>
                <TableBody>
                  {data.map((u) => {
                    const banned = u.banned_until && new Date(u.banned_until) > new Date();
                    const active = !banned && u.is_active;
                    return (
                      <TableRow key={u.id}>
                        <TableCell className="font-medium">{u.full_name ?? "—"}</TableCell>
                        <TableCell>{u.email}</TableCell>
                        <TableCell className="space-x-1">
                          {u.roles.map((r) => <Badge key={r} variant="outline">{r}</Badge>)}
                        </TableCell>
                        <TableCell>
                          {active ? <Badge>Aktif</Badge> : <Badge variant="destructive">Pasif</Badge>}
                        </TableCell>
                        <TableCell className="space-x-1">
                          <ResetPasswordDialog userId={u.id} email={u.email} />
                          <Button size="sm" variant="outline" onClick={() => toggleActive(u.id, !active)}>
                            {active ? <><Ban className="h-3 w-3 mr-1" />Pasifleştir</> : <><ShieldCheck className="h-3 w-3 mr-1" />Aktifleştir</>}
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function NewUserDialog({ onDone }: { onDone: () => void }) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    email: "", password: "", fullName: "", phone: "",
    role: "tenant" as "admin" | "staff" | "tenant",
    tenantId: "",
  });
  const [saving, setSaving] = useState(false);
  const create = useServerFn(createAppUser);

  const unlinkedTenants = useQuery({
    queryKey: ["unlinked-tenants"],
    enabled: open,
    queryFn: async () => {
      const { data } = await supabase.from("tenants").select("id, full_name").is("user_id", null).order("full_name");
      return data ?? [];
    },
  });

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await create({ data: {
        email: form.email, password: form.password, fullName: form.fullName,
        phone: form.phone || undefined, role: form.role,
        tenantId: form.role === "tenant" && form.tenantId ? form.tenantId : undefined,
      } });
      toast.success("Kullanıcı oluşturuldu. Giriş bilgilerini kullanıcıya iletebilirsiniz.");
      setOpen(false);
      setForm({ email: "", password: "", fullName: "", phone: "", role: "tenant", tenantId: "" });
      onDone();
    } catch (e) {
      toast.error("Oluşturulamadı", { description: (e as Error).message });
    } finally { setSaving(false); }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button size="sm"><Plus className="h-4 w-4 mr-1" />Yeni Kullanıcı</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Kullanıcı Oluştur</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5 col-span-2"><Label>Ad Soyad *</Label><Input required value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>E-posta *</Label><Input required type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Telefon</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Şifre (min 8) *</Label><Input required minLength={8} type="text" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Rol *</Label>
              <select className="w-full border rounded h-9 px-2 text-sm bg-background" value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as "admin" | "staff" | "tenant" })}>
                <option value="tenant">Kiracı</option>
                <option value="staff">Personel</option>
                <option value="admin">Yönetici</option>
              </select>
            </div>
            {form.role === "tenant" && (
              <div className="space-y-1.5 col-span-2"><Label>Kiracı Kaydına Bağla (opsiyonel)</Label>
                <select className="w-full border rounded h-9 px-2 text-sm bg-background" value={form.tenantId} onChange={(e) => setForm({ ...form, tenantId: e.target.value })}>
                  <option value="">— Bağlama —</option>
                  {unlinkedTenants.data?.map((t) => (<option key={t.id} value={t.id}>{t.full_name}</option>))}
                </select>
                <p className="text-xs text-muted-foreground">Kiracı önceden Kiracılar sayfasından eklenmiş olmalı ve hesabı bağlı olmamalı.</p>
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground">Bu bilgileri kaydettikten sonra kullanıcıya kendiniz iletmeniz gerekir. Sistem üzerinden e-posta gönderilmez.</p>
          <DialogFooter><Button type="submit" disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Oluştur</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ResetPasswordDialog({ userId, email }: { userId: string; email: string }) {
  const [open, setOpen] = useState(false);
  const [password, setPassword] = useState("");
  const [saving, setSaving] = useState(false);
  const reset = useServerFn(resetUserPassword);
  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    try {
      await reset({ data: { userId, newPassword: password } });
      toast.success("Şifre güncellendi. Yeni şifreyi kullanıcıya iletin.");
      setOpen(false); setPassword("");
    } catch (e) { toast.error((e as Error).message); }
    setSaving(false);
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild><Button size="sm" variant="outline"><KeyRound className="h-3 w-3 mr-1" />Şifre</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Şifre Sıfırla</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <p className="text-sm text-muted-foreground">{email}</p>
          <div className="space-y-1.5"><Label>Yeni Şifre (min 8)</Label><Input required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} /></div>
          <DialogFooter><Button type="submit" disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Değiştir</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}