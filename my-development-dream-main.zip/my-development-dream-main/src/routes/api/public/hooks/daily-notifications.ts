import { createFileRoute } from "@tanstack/react-router";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

const SAFE_DRIVING_TIPS: { title: string; message: string }[] = [
  {
    title: "Güvenli Sürüş Hatırlatması",
    message:
      "Kaskınızı ve koruyucu ekipmanlarınızı her sürüşten önce mutlaka takın. Kısa mesafelerde bile güvenliğiniz her şeyden önemli.",
  },
  {
    title: "Takip Mesafesine Dikkat",
    message:
      "Öndeki araçla aranızda en az 3 saniyelik takip mesafesi bırakın. Islak zeminde bu süreyi iki katına çıkarın.",
  },
  {
    title: "Hız Limitlerine Uyalım",
    message:
      "Hız limitleri sizin ve çevrenizdekilerin güvenliği için var. Özellikle virajlarda hızınızı önceden azaltın.",
  },
  {
    title: "Görünür Olun",
    message:
      "Gündüz de olsa farlarınızı açık tutun, reflektif kıyafetler tercih edin. Diğer sürücülerin sizi görmesi hayat kurtarır.",
  },
  {
    title: "Kör Nokta Kontrolü",
    message:
      "Şerit değiştirmeden önce mutlaka omuz üstü kontrol yapın. Motosikletler diğer araçların kör noktasında kolayca kaybolur.",
  },
  {
    title: "Hava Koşullarına Dikkat",
    message:
      "Yağmurlu ve rüzgarlı havalarda ani manevralardan kaçının, fren mesafenizi uzun tutun. Gerekmedikçe yola çıkmayın.",
  },
  {
    title: "Yorgun Sürmeyin",
    message:
      "Uzun yolculuklarda her 1-2 saatte bir mola verin. Yorgunluk refleksleri en az alkol kadar yavaşlatır.",
  },
  {
    title: "Lastik ve Fren Kontrolü",
    message:
      "Sürüş öncesi lastik basıncını ve fren tepkinizi kontrol edin. Küçük bir kontrol büyük kazaları önler.",
  },
];

export const Route = createFileRoute("/api/public/hooks/daily-notifications")({
  server: {
    handlers: {
      POST: async () => {
        const supabase = createClient<Database>(
          process.env.SUPABASE_URL!,
          process.env.SUPABASE_SERVICE_ROLE_KEY!,
          { auth: { autoRefreshToken: false, persistSession: false } },
        );

        const now = new Date();
        const todayISO = now.toISOString().slice(0, 10);

        // 1) Load active rentals with tenant user link
        const { data: rentals, error: rentalsErr } = await supabase
          .from("rentals")
          .select("id, motorcycle_id, tenant_id, tenants(user_id, full_name), motorcycles(plate)")
          .eq("status", "active");
        if (rentalsErr) {
          return Response.json({ error: rentalsErr.message }, { status: 500 });
        }

        let maintenanceInserted = 0;
        let safeDrivingInserted = 0;

        // Track unique tenant users for the safe-driving pass
        const tenantUserIds = new Set<string>();

        for (const rental of rentals ?? []) {
          const userId = rental.tenants?.user_id;
          if (!userId) continue;
          tenantUserIds.add(userId);

          // Latest service record for this motorcycle
          const { data: lastService } = await supabase
            .from("service_records")
            .select("service_date")
            .eq("motorcycle_id", rental.motorcycle_id)
            .order("service_date", { ascending: false })
            .limit(1)
            .maybeSingle();

          const referenceDate = lastService?.service_date
            ? new Date(lastService.service_date)
            : null;
          const daysSince = referenceDate
            ? Math.floor((now.getTime() - referenceDate.getTime()) / 86_400_000)
            : Number.POSITIVE_INFINITY;

          if (daysSince < 10) continue;

          // Already notified today for this rental?
          const { data: existing } = await supabase
            .from("notifications")
            .select("id")
            .eq("user_id", userId)
            .eq("type", "maintenance_reminder")
            .eq("related_id", rental.id)
            .gte("created_at", `${todayISO}T00:00:00.000Z`)
            .limit(1);

          if (existing && existing.length > 0) continue;

          const plate = rental.motorcycles?.plate ?? "";
          const message = referenceDate
            ? `${plate} plakalı motosikletiniz için son ${daysSince} gündür bakım kaydı eklenmemiş. Aracınızın güvenliği ve performansı için bakımlarınızı aksatmayalım — kısa bir kontrol büyük sorunları önler.`
            : `${plate} plakalı motosikletiniz için henüz hiç bakım kaydı eklenmemiş. Aracınızın güvenliği için bakımlarınızı düzenli tutalım ve ilk bakım kaydınızı ekleyelim.`;

          const { error: insErr } = await supabase.from("notifications").insert({
            user_id: userId,
            type: "maintenance_reminder",
            title: "Bakım Hatırlatması",
            message,
            related_id: rental.id,
          });
          if (!insErr) maintenanceInserted++;
        }

        // 2) Safe driving tips — one per tenant user, at most every 3 days
        const threeDaysAgoISO = new Date(now.getTime() - 3 * 86_400_000).toISOString();

        for (const userId of tenantUserIds) {
          const { data: lastTip } = await supabase
            .from("notifications")
            .select("id, created_at")
            .eq("user_id", userId)
            .eq("type", "safe_driving")
            .order("created_at", { ascending: false })
            .limit(1)
            .maybeSingle();

          if (lastTip && lastTip.created_at > threeDaysAgoISO) continue;

          const tip =
            SAFE_DRIVING_TIPS[Math.floor(Math.random() * SAFE_DRIVING_TIPS.length)];

          const { error: insErr } = await supabase.from("notifications").insert({
            user_id: userId,
            type: "safe_driving",
            title: tip.title,
            message: tip.message,
          });
          if (!insErr) safeDrivingInserted++;
        }

        return Response.json({
          success: true,
          maintenanceInserted,
          safeDrivingInserted,
          tenantsChecked: tenantUserIds.size,
          rentalsChecked: rentals?.length ?? 0,
        });
      },
    },
  },
});