import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import {
  founderLogin,
  founderLogout,
  founderMe,
  founderChangePassword,
  founderListFleets,
  founderCreateFleet,
  founderUpdateFleet,
  founderDeleteFleet,
} from "@/lib/founder.functions";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Loader2, LogOut, Plus, Pencil, Trash2, KeyRound } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/kurucu")({
  ssr: false,
  head: () => ({ meta: [{ title: "Kurucu Paneli" }] }),
  component: FounderPage,
});

const TOKEN_KEY = "founder_token";

type Fleet = {
  id: string;
  name: string;
  notes: string | null;
  is_active: boolean;
  expires_at: string | null;
  created_at: string;
};

function FounderPage() {
  const [token, setToken] = useState<string | null>(null);
  const [checking, setChecking] = useState(true);
  const meFn = useServerFn(founderMe);

  useEffect(() => {
    const t = localStorage.getItem(TOKEN_KEY);
    if (!t) {
      setChecking(false);
      return;
    }
    meFn({ data: { token: t } })
      .then((acc) => {
        if (acc) setToken(t);
        else localStorage.removeItem(TOKEN_KEY);
      })
      .catch(() => localStorage.removeItem(TOKEN_KEY))
      .finally(() => setChecking(false));
  }, [meFn]);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center">
        <Loader2 className="animate-spin" />
      </div>
    );
  }

  return token ? (
    <FounderDashboard token={token} onLogout={() => setToken(null)} />
  ) : (
    <LoginForm onLogin={(t) => setToken(t)} />
  );
}

function LoginForm({ onLogin }: { onLogin: (token: string) => void }) {
  const loginFn = useServerFn(founderLogin);
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    try {
      const r = await loginFn({ data: { username, password } });
      localStorage.setItem(TOKEN_KEY, r.token);
      onLogin(r.token);
    } catch (err) {
      toast.error((err as Error).message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4 bg-neutral-950">
      <Card className="w-full max-w-sm">
        <CardHeader>
          <CardTitle>Kurucu Girişi</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={submit} className="space-y-3">
            <div className="space-y-1.5">
              <Label>Kullanıcı Adı</Label>
              <Input value={username} onChange={(e) => setUsername(e.target.value)} autoFocus />
            </div>
            <div className="space-y-1.5">
              <Label>Şifre</Label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
            </div>
            <Button type="submit" disabled={loading} className="w-full">
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : "Giriş"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}

function FounderDashboard({ token, onLogout }: { token: string; onLogout: () => void }) {
  const logoutFn = useServerFn(founderLogout);
  const listFn = useServerFn(founderListFleets);
  const deleteFn = useServerFn(founderDeleteFleet);
  const updateFn = useServerFn(founderUpdateFleet);

  const [fleets, setFleets] = useState<Fleet[]>([]);
  const [loading, setLoading] = useState(true);

  async function reload() {
    setLoading(true);
    try {
      const r = await listFn({ data: { token } });
      setFleets(r as Fleet[]);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleLogout() {
    await logoutFn({ data: { token } }).catch(() => {});
    localStorage.removeItem(TOKEN_KEY);
    onLogout();
  }

  async function toggleActive(f: Fleet) {
    try {
      await updateFn({ data: { token, id: f.id, is_active: !f.is_active } });
      toast.success(!f.is_active ? "Filo aktifleştirildi" : "Filo devre dışı");
      reload();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  async function handleDelete(id: string) {
    try {
      await deleteFn({ data: { token, id } });
      toast.success("Filo silindi");
      reload();
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 p-4">
      <div className="max-w-5xl mx-auto space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold">Kurucu Paneli</h1>
            <p className="text-sm text-neutral-400">Sistem filoları yönetimi</p>
          </div>
          <div className="flex gap-2">
            <ChangePasswordDialog token={token} />
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-1" /> Çıkış
            </Button>
          </div>
        </div>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle>Filolar</CardTitle>
            <FleetDialog token={token} onSaved={reload} trigger={<Button size="sm"><Plus className="h-4 w-4 mr-1" /> Yeni Filo</Button>} />
          </CardHeader>
          <CardContent>
            {loading ? (
              <Loader2 className="mx-auto animate-spin" />
            ) : fleets.length === 0 ? (
              <p className="py-4 text-center text-sm text-neutral-400">Kayıtlı filo yok.</p>
            ) : (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Ad</TableHead>
                      <TableHead>Durum</TableHead>
                      <TableHead>Bitiş</TableHead>
                      <TableHead>Notlar</TableHead>
                      <TableHead className="text-right">İşlemler</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {fleets.map((f) => {
                      const expired = f.expires_at && new Date(f.expires_at).getTime() < Date.now();
                      return (
                        <TableRow key={f.id}>
                          <TableCell className="font-medium">{f.name}</TableCell>
                          <TableCell>
                            {expired ? (
                              <Badge variant="destructive">Süresi Doldu</Badge>
                            ) : f.is_active ? (
                              <Badge>Aktif</Badge>
                            ) : (
                              <Badge variant="secondary">Kapalı</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-sm">
                            {f.expires_at ? new Date(f.expires_at).toLocaleDateString("tr-TR") : "—"}
                          </TableCell>
                          <TableCell className="text-sm text-neutral-400 max-w-[200px] truncate">{f.notes ?? "—"}</TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end items-center gap-1">
                              <div className="flex items-center gap-1 mr-2">
                                <Switch checked={f.is_active} onCheckedChange={() => toggleActive(f)} />
                              </div>
                              <FleetDialog
                                token={token}
                                fleet={f}
                                onSaved={reload}
                                trigger={
                                  <Button size="sm" variant="ghost">
                                    <Pencil className="h-3.5 w-3.5" />
                                  </Button>
                                }
                              />
                              <AlertDialog>
                                <AlertDialogTrigger asChild>
                                  <Button size="sm" variant="ghost" className="text-destructive">
                                    <Trash2 className="h-3.5 w-3.5" />
                                  </Button>
                                </AlertDialogTrigger>
                                <AlertDialogContent>
                                  <AlertDialogHeader>
                                    <AlertDialogTitle>Filoyu sil?</AlertDialogTitle>
                                    <AlertDialogDescription>
                                      Bu filo silinecek. Bu filoya bağlı kullanıcıların filo bağlantısı kaldırılır.
                                    </AlertDialogDescription>
                                  </AlertDialogHeader>
                                  <AlertDialogFooter>
                                    <AlertDialogCancel>İptal</AlertDialogCancel>
                                    <AlertDialogAction onClick={() => handleDelete(f.id)}>Sil</AlertDialogAction>
                                  </AlertDialogFooter>
                                </AlertDialogContent>
                              </AlertDialog>
                            </div>
                          </TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function FleetDialog({
  token,
  fleet,
  onSaved,
  trigger,
}: {
  token: string;
  fleet?: Fleet;
  onSaved: () => void;
  trigger: React.ReactNode;
}) {
  const createFn = useServerFn(founderCreateFleet);
  const updateFn = useServerFn(founderUpdateFleet);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState("");
  const [notes, setNotes] = useState("");
  const [expiresAt, setExpiresAt] = useState("");
  const [isActive, setIsActive] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setName(fleet?.name ?? "");
      setNotes(fleet?.notes ?? "");
      setExpiresAt(fleet?.expires_at ? fleet.expires_at.slice(0, 10) : "");
      setIsActive(fleet?.is_active ?? true);
    }
  }, [open, fleet]);

  async function save() {
    setSaving(true);
    try {
      const expires = expiresAt ? new Date(expiresAt + "T23:59:59").toISOString() : null;
      if (fleet) {
        await updateFn({
          data: { token, id: fleet.id, name, notes: notes || null, expires_at: expires, is_active: isActive },
        });
        toast.success("Filo güncellendi");
      } else {
        await createFn({
          data: { token, name, notes: notes || undefined, expires_at: expires, is_active: isActive },
        });
        toast.success("Filo oluşturuldu");
      }
      setOpen(false);
      onSaved();
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{fleet ? "Filoyu Düzenle" : "Yeni Filo"}</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Filo Adı</Label>
            <Input value={name} onChange={(e) => setName(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Bitiş Tarihi (opsiyonel)</Label>
            <Input type="date" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Notlar</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} rows={3} />
          </div>
          <div className="flex items-center gap-2">
            <Switch checked={isActive} onCheckedChange={setIsActive} />
            <Label>Aktif</Label>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>İptal</Button>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ChangePasswordDialog({ token }: { token: string }) {
  const changeFn = useServerFn(founderChangePassword);
  const [open, setOpen] = useState(false);
  const [cur, setCur] = useState("");
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [saving, setSaving] = useState(false);

  async function save() {
    if (pw !== pw2) {
      toast.error("Yeni şifreler eşleşmiyor");
      return;
    }
    setSaving(true);
    try {
      await changeFn({ data: { token, currentPassword: cur, newPassword: pw } });
      toast.success("Şifre güncellendi");
      setOpen(false);
      setCur("");
      setPw("");
      setPw2("");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <KeyRound className="h-4 w-4 mr-1" /> Şifre Değiştir
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Şifre Değiştir</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Mevcut Şifre</Label>
            <Input type="password" value={cur} onChange={(e) => setCur(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Yeni Şifre</Label>
            <Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} />
          </div>
          <div className="space-y-1.5">
            <Label>Yeni Şifre (tekrar)</Label>
            <Input type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)}>İptal</Button>
          <Button onClick={save} disabled={saving}>
            {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Kaydet"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
