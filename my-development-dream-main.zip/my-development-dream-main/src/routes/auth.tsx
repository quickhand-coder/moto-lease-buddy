import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { toast } from "sonner";
import { Loader2 } from "lucide-react";
import logoAsset from "@/assets/mty-filo-logo.png.asset.json";
import { useQuery } from "@tanstack/react-query";
import { bootstrapAdmin, isBootstrapAvailable } from "@/lib/admin-users.functions";

export const Route = createFileRoute("/auth")({
  head: () => ({ meta: [{ title: "Giriş — MTY Filo Takip Sistemi" }] }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [mode, setMode] = useState<"login" | "bootstrap">("login");
  const [fullName, setFullName] = useState("");

  const checkBootstrap = useServerFn(isBootstrapAvailable);
  const bootstrap = useServerFn(bootstrapAdmin);

  const { data: bootstrapInfo } = useQuery({
    queryKey: ["bootstrap-available"],
    queryFn: () => checkBootstrap(),
  });

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) navigate({ to: "/", replace: true });
    });
  }, [navigate]);

  async function onLogin(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    const { error, data } = await supabase.auth.signInWithPassword({ email, password });
    setSubmitting(false);
    if (error) {
      toast.error("Giriş başarısız", { description: error.message });
      return;
    }
    toast.success("Hoş geldiniz");

    const userId = data.user?.id;
    if (!userId) {
      navigate({ to: "/", replace: true });
      return;
    }

    const { data: roleData } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);

    const rs = (roleData ?? []).map((r) => r.role);
    if (rs.includes("tenant") && !rs.some((r) => r === "admin" || r === "staff")) {
      navigate({ to: "/my-rentals", replace: true });
    } else {
      navigate({ to: "/dashboard", replace: true });
    }
  }

  async function onBootstrap(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    try {
      await bootstrap({ data: { email, password, fullName } });
      toast.success("Yönetici hesabı oluşturuldu, giriş yapılıyor...");
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      navigate({ to: "/", replace: true });
    } catch (err) {
      toast.error("Kurulum başarısız", { description: (err as Error).message });
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-neutral-950 px-4">
      <Card className="w-full max-w-md border-neutral-800 bg-neutral-900 text-neutral-100">
        <CardHeader className="space-y-2 text-center">
          <img
            src={logoAsset.url}
            alt="MTY Filo"
            className="mx-auto h-28 w-auto object-contain"
          />
          <CardTitle className="text-2xl">
            {mode === "bootstrap" ? "İlk Yönetici Hesabı" : "MTY Filo Takip Sistemi"}
          </CardTitle>
          <CardDescription className="text-neutral-400">
            {mode === "bootstrap"
              ? "Sistemde henüz yönetici yok. İlk yönetici hesabını oluşturun."
              : "Yalnızca yönetici tarafından oluşturulan hesaplar giriş yapabilir."}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {mode === "login" ? (
            <form onSubmit={onLogin} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="email">E-posta</Label>
                <Input
                  id="email"
                  type="email"
                  autoComplete="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password">Şifre</Label>
                <Input
                  id="password"
                  type="password"
                  autoComplete="current-password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Giriş Yap
              </Button>
              {bootstrapInfo?.available && (
                <p className="text-center text-xs text-muted-foreground">
                  Yönetici hesabı bulunamadı.{" "}
                  <button
                    type="button"
                    className="underline"
                    onClick={() => setMode("bootstrap")}
                  >
                    İlk yöneticiyi kur
                  </button>
                </p>
              )}
            </form>
          ) : (
            <form onSubmit={onBootstrap} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name">Ad Soyad</Label>
                <Input id="name" required value={fullName} onChange={(e) => setFullName(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="email2">E-posta</Label>
                <Input id="email2" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password2">Şifre (en az 8 karakter)</Label>
                <Input
                  id="password2"
                  type="password"
                  required
                  minLength={8}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <Button type="submit" className="w-full" disabled={submitting}>
                {submitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                Yöneticiyi Oluştur
              </Button>
              <button
                type="button"
                className="text-center text-xs text-muted-foreground underline w-full"
                onClick={() => setMode("login")}
              >
                Girişe dön
              </button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}