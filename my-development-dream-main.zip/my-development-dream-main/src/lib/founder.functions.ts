import { createServerFn } from "@tanstack/react-start";

async function sha256Hex(input: string): Promise<string> {
  const buf = new TextEncoder().encode(input);
  const digest = await crypto.subtle.digest("SHA-256", buf);
  return Array.from(new Uint8Array(digest))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

function randomToken(): string {
  const bytes = new Uint8Array(32);
  crypto.getRandomValues(bytes);
  return Array.from(bytes)
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

async function requireFounder(token: string) {
  if (!token) throw new Error("Yetkisiz");
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("founder_sessions")
    .select("founder_id, expires_at")
    .eq("token", token)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Oturum yok");
  if (new Date(data.expires_at).getTime() < Date.now()) {
    await supabaseAdmin.from("founder_sessions").delete().eq("token", token);
    throw new Error("Oturum süresi doldu");
  }
  return { founderId: data.founder_id as string, supabaseAdmin };
}

export const founderLogin = createServerFn({ method: "POST" })
  .inputValidator((d: { username: string; password: string }) => d)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: acc, error } = await supabaseAdmin
      .from("founder_accounts")
      .select("id, password_hash")
      .eq("username", data.username.trim())
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!acc) throw new Error("Kullanıcı adı veya şifre hatalı");
    const hash = await sha256Hex(data.password);
    if (hash !== acc.password_hash) throw new Error("Kullanıcı adı veya şifre hatalı");

    const token = randomToken();
    const expires = new Date(Date.now() + 1000 * 60 * 60 * 24 * 7).toISOString();
    const { error: sErr } = await supabaseAdmin
      .from("founder_sessions")
      .insert({ token, founder_id: acc.id, expires_at: expires });
    if (sErr) throw new Error(sErr.message);
    return { ok: true as const, token, expires_at: expires };
  });

export const founderLogout = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("founder_sessions").delete().eq("token", data.token);
    return { ok: true as const };
  });

export const founderMe = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    const { founderId, supabaseAdmin } = await requireFounder(data.token);
    const { data: acc } = await supabaseAdmin
      .from("founder_accounts")
      .select("id, username")
      .eq("id", founderId)
      .maybeSingle();
    return acc;
  });

export const founderChangePassword = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; currentPassword: string; newPassword: string }) => d)
  .handler(async ({ data }) => {
    const { founderId, supabaseAdmin } = await requireFounder(data.token);
    const { data: acc } = await supabaseAdmin
      .from("founder_accounts")
      .select("password_hash")
      .eq("id", founderId)
      .maybeSingle();
    if (!acc) throw new Error("Hesap bulunamadı");
    const currentHash = await sha256Hex(data.currentPassword);
    if (currentHash !== acc.password_hash) throw new Error("Mevcut şifre hatalı");
    if (data.newPassword.length < 4) throw new Error("Yeni şifre en az 4 karakter olmalı");
    const newHash = await sha256Hex(data.newPassword);
    const { error } = await supabaseAdmin
      .from("founder_accounts")
      .update({ password_hash: newHash })
      .eq("id", founderId);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const founderListFleets = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string }) => d)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await requireFounder(data.token);
    const { data: fleets, error } = await supabaseAdmin
      .from("fleets")
      .select("id, name, notes, is_active, expires_at, created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return fleets ?? [];
  });

export const founderCreateFleet = createServerFn({ method: "POST" })
  .inputValidator(
    (d: { token: string; name: string; notes?: string; expires_at?: string | null; is_active?: boolean }) => d,
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await requireFounder(data.token);
    if (!data.name.trim()) throw new Error("Filo adı zorunlu");
    const { error } = await supabaseAdmin.from("fleets").insert({
      name: data.name.trim(),
      notes: data.notes ?? null,
      expires_at: data.expires_at || null,
      is_active: data.is_active ?? true,
    });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const founderUpdateFleet = createServerFn({ method: "POST" })
  .inputValidator(
    (d: {
      token: string;
      id: string;
      name?: string;
      notes?: string | null;
      expires_at?: string | null;
      is_active?: boolean;
    }) => d,
  )
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await requireFounder(data.token);
    const patch: Record<string, unknown> = {};
    if (data.name !== undefined) patch.name = data.name.trim();
    if (data.notes !== undefined) patch.notes = data.notes;
    if (data.expires_at !== undefined) patch.expires_at = data.expires_at || null;
    if (data.is_active !== undefined) patch.is_active = data.is_active;
    const { error } = await (supabaseAdmin.from("fleets") as any).update(patch).eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const founderDeleteFleet = createServerFn({ method: "POST" })
  .inputValidator((d: { token: string; id: string }) => d)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await requireFounder(data.token);
    // Detach profiles from this fleet before deleting
    await supabaseAdmin.from("profiles").update({ fleet_id: null }).eq("fleet_id", data.id);
    const { error } = await supabaseAdmin.from("fleets").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });
