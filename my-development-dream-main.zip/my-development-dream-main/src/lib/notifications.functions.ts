import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** Admin/staff: send a notification (title+message) to selected users, list of users, or all users. */
export const sendBroadcastNotification = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (d: {
      title: string;
      message: string;
      target: "single" | "multi" | "all";
      userIds?: string[];
    }) => d,
  )
  .handler(async ({ data, context }) => {
    const { data: isStaff, error: roleErr } = await context.supabase.rpc("is_staff_or_admin", {
      _user_id: context.userId,
    });
    if (roleErr) throw new Error(roleErr.message);
    if (!isStaff) throw new Error("Yetkisiz");

    const title = data.title.trim();
    const message = data.message.trim();
    if (!title || !message) throw new Error("Başlık ve mesaj zorunludur");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    let targetIds: string[] = [];
    if (data.target === "all") {
      const { data: users, error } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
      if (error) throw new Error(error.message);
      targetIds = users.users.map((u) => u.id);
    } else {
      targetIds = Array.from(new Set(data.userIds ?? [])).filter(Boolean);
    }

    if (targetIds.length === 0) throw new Error("En az bir kullanıcı seçin");

    const rows = targetIds.map((user_id) => ({
      user_id,
      type: "admin_broadcast",
      title,
      message,
    }));

    const { error } = await supabaseAdmin.from("notifications").insert(rows);
    if (error) throw new Error(error.message);

    return { ok: true as const, count: targetIds.length };
  });
