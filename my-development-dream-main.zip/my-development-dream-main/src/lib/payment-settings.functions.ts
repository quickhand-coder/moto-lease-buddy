import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

export const getPaymentSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("payment_settings")
      .select("bank_name, account_holder, iban")
      .limit(1)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return data ?? { bank_name: "", account_holder: "", iban: "" };
  });

export const updatePaymentSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { bank_name: string; account_holder: string; iban: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Yetkisiz");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing } = await supabaseAdmin.from("payment_settings").select("id").limit(1).maybeSingle();
    if (existing) {
      const { error } = await supabaseAdmin.from("payment_settings").update(data).eq("id", existing.id);
      if (error) throw new Error(error.message);
    } else {
      const { error } = await supabaseAdmin.from("payment_settings").insert(data);
      if (error) throw new Error(error.message);
    }
    return { ok: true as const };
  });
