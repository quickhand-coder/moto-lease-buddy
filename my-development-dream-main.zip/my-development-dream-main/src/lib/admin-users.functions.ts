import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/**
 * Bootstrap the first admin. Only succeeds while zero admins exist.
 * After bootstrap, all further user creation goes through createAppUser.
 */
export const bootstrapAdmin = createServerFn({ method: "POST" })
  .inputValidator((d: { email: string; password: string; fullName: string }) => d)
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { count, error: countErr } = await supabaseAdmin
      .from("user_roles")
      .select("*", { count: "exact", head: true })
      .eq("role", "admin");
    if (countErr) throw new Error(countErr.message);
    if ((count ?? 0) > 0) {
      throw new Error("Yönetici zaten mevcut. Bu bağlantı devre dışı.");
    }

    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.fullName },
    });
    if (createErr || !created.user) throw new Error(createErr?.message ?? "Kullanıcı oluşturulamadı");

    const { error: roleErr } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: created.user.id, role: "admin" });
    if (roleErr) throw new Error(roleErr.message);

    return { ok: true as const };
  });

/**
 * Check whether bootstrap is still available (no admin exists).
 */
export const isBootstrapAvailable = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { count, error } = await supabaseAdmin
    .from("user_roles")
    .select("*", { count: "exact", head: true })
    .eq("role", "admin");
  if (error) throw new Error(error.message);
  return { available: (count ?? 0) === 0 };
});

/** Admin-only: create a staff or tenant account and (optionally) link tenant record. */
export const createAppUser = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator(
    (d: {
      email: string;
      password: string;
      fullName: string;
      phone?: string;
      role: "admin" | "staff" | "tenant";
      tenantId?: string; // if provided and role=tenant, link to existing tenant record
    }) => d,
  )
  .handler(async ({ data, context }) => {
    // authorize: only admins can create users
    const { data: isAdmin, error: roleCheckErr } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (roleCheckErr) throw new Error(roleCheckErr.message);
    if (!isAdmin) throw new Error("Yetkisiz: yalnızca yöneticiler kullanıcı oluşturabilir.");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: created, error: createErr } = await supabaseAdmin.auth.admin.createUser({
      email: data.email,
      password: data.password,
      email_confirm: true,
      user_metadata: { full_name: data.fullName, phone: data.phone },
    });
    if (createErr || !created.user) throw new Error(createErr?.message ?? "Kullanıcı oluşturulamadı");

    const userId = created.user.id;

    const { error: roleErr } = await supabaseAdmin
      .from("user_roles")
      .insert({ user_id: userId, role: data.role });
    if (roleErr) throw new Error(roleErr.message);

    if (data.role === "tenant" && data.tenantId) {
      const { error: linkErr } = await supabaseAdmin
        .from("tenants")
        .update({ user_id: userId })
        .eq("id", data.tenantId);
      if (linkErr) throw new Error(linkErr.message);
    }

    return { ok: true as const, userId };
  });

/** Admin-only: reset a user's password. */
export const resetUserPassword = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; newPassword: string }) => d)
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Yetkisiz");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, {
      password: data.newPassword,
    });
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

/** Admin-only: deactivate (ban) or reactivate a user. */
export const setUserActive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d: { userId: string; active: boolean }) => d)
  .handler(async ({ data, context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Yetkisiz");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.updateUserById(data.userId, {
      ban_duration: data.active ? "none" : "876000h",
    });
    if (error) throw new Error(error.message);
    await supabaseAdmin.from("profiles").update({ is_active: data.active }).eq("id", data.userId);
    return { ok: true as const };
  });

/** List all app users with roles and profile info. */
export const listAppUsers = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isAdmin } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "admin",
    });
    if (!isAdmin) throw new Error("Yetkisiz");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: authRes, error: listErr } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 200,
    });
    if (listErr) throw new Error(listErr.message);
    const users = authRes.users;
    const ids = users.map((u) => u.id);
    const { data: roleRows } = await supabaseAdmin
      .from("user_roles")
      .select("user_id, role")
      .in("user_id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
    const { data: profileRows } = await supabaseAdmin
      .from("profiles")
      .select("id, full_name, phone, is_active")
      .in("id", ids.length ? ids : ["00000000-0000-0000-0000-000000000000"]);
    const rolesByUser = new Map<string, string[]>();
    (roleRows ?? []).forEach((r) => {
      const arr = rolesByUser.get(r.user_id) ?? [];
      arr.push(r.role);
      rolesByUser.set(r.user_id, arr);
    });
    const profByUser = new Map(profileRows?.map((p) => [p.id, p]) ?? []);
    return users.map((u) => ({
      id: u.id,
      email: u.email ?? "",
      created_at: u.created_at,
      banned_until: (u as { banned_until?: string | null }).banned_until ?? null,
      roles: rolesByUser.get(u.id) ?? [],
      full_name: profByUser.get(u.id)?.full_name ?? null,
      phone: profByUser.get(u.id)?.phone ?? null,
      is_active: profByUser.get(u.id)?.is_active ?? true,
    }));
  });