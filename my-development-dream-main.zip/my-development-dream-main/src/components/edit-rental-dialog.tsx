import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Loader2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { format, parseISO, addMonths } from "date-fns";

export type EditRental = {
  id: string;
  motorcycle_id: string;
  tenant_id: string;
  start_date: string;
  end_date: string;
  contract_end_date: string | null;
  monthly_rate: number;
  deposit_amount: number;
  notes: string | null;
};

export function EditRentalDialog({
  rental,
  onDone,
  iconOnly = false,
}: {
  rental: EditRental;
  onDone: () => void;
  iconOnly?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const motos = useQuery({
    queryKey: ["motos-for-edit", rental.motorcycle_id],
    queryFn: async () => {
      const { data } = await supabase
        .from("motorcycles")
        .select("id, plate, brand, model, status")
        .or(`status.eq.available,id.eq.${rental.motorcycle_id}`);
      return data ?? [];
    },
    enabled: open,
  });
  const tenants = useQuery({
    queryKey: ["tenants-for-edit"],
    queryFn: async () => {
      const { data } = await supabase.from("tenants").select("id, full_name").order("full_name");
      return data ?? [];
    },
    enabled: open,
  });

  const initialMonths = Math.max(
    1,
    Math.round(
      (parseISO(rental.end_date).getTime() - parseISO(rental.start_date).getTime()) /
        (1000 * 60 * 60 * 24 * 30),
    ),
  );

  const [form, setForm] = useState({
    motorcycle_id: rental.motorcycle_id,
    tenant_id: rental.tenant_id,
    start_date: rental.start_date,
    months: String(initialMonths),
    contract_end_date: rental.contract_end_date ?? "",
    monthly_rate: String(rental.monthly_rate ?? 8500),
    deposit_amount: String(rental.deposit_amount ?? 0),
    notes: rental.notes ?? "",
  });
  const [saving, setSaving] = useState(false);

  const months = Math.max(1, parseInt(form.months) || 1);
  const monthlyRate = parseFloat(form.monthly_rate) || 0;
  const endDate = format(addMonths(parseISO(form.start_date), months), "yyyy-MM-dd");
  const total = monthlyRate * months;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase.from("rentals").update({
      motorcycle_id: form.motorcycle_id,
      tenant_id: form.tenant_id,
      start_date: form.start_date,
      end_date: endDate,
      contract_end_date: form.contract_end_date || endDate,
      monthly_rate: monthlyRate,
      total_amount: total,
      deposit_amount: parseFloat(form.deposit_amount) || 0,
      notes: form.notes || null,
    }).eq("id", rental.id);

    if (!error && form.motorcycle_id !== rental.motorcycle_id) {
      await supabase.from("motorcycles").update({ status: "available" }).eq("id", rental.motorcycle_id);
      await supabase.from("motorcycles").update({ status: "rented" }).eq("id", form.motorcycle_id);
    }

    setSaving(false);
    if (error) { toast.error("Kaydedilemedi", { description: error.message }); return; }
    toast.success("Güncellendi");
    setOpen(false);
    onDone();
  }
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {iconOnly ? (
          <Button size="icon" variant="ghost" className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>
        ) : (
          <Button size="sm" variant="outline"><Pencil className="h-4 w-4 mr-1" />Düzenle</Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Kirayı Düzenle</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5 col-span-2">
              <Label>Motosiklet *</Label>
              <select required className="w-full border rounded h-9 px-2 text-sm bg-background" value={form.motorcycle_id} onChange={(e) => setForm({ ...form, motorcycle_id: e.target.value })}>
                <option value="">Seçiniz</option>
                {motos.data?.map((m) => (
                  <option key={m.id} value={m.id}>{m.plate} — {m.brand} {m.model}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5 col-span-2">
              <Label>Kiracı *</Label>
              <select required className="w-full border rounded h-9 px-2 text-sm bg-background" value={form.tenant_id} onChange={(e) => setForm({ ...form, tenant_id: e.target.value })}>
                <option value="">Seçiniz</option>
                {tenants.data?.map((t) => (
                  <option key={t.id} value={t.id}>{t.full_name}</option>
                ))}
              </select>
            </div>
            <div className="space-y-1.5"><Label>Başlangıç *</Label><Input type="date" required value={form.start_date} onChange={(e) => setForm({ ...form, start_date: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Kira Süresi (Ay) *</Label><Input type="number" min="1" required value={form.months} onChange={(e) => setForm({ ...form, months: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Aylık Ücret (₺) *</Label><Input type="number" step="0.01" required value={form.monthly_rate} onChange={(e) => setForm({ ...form, monthly_rate: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Depozito (₺)</Label><Input type="number" step="0.01" value={form.deposit_amount} onChange={(e) => setForm({ ...form, deposit_amount: e.target.value })} /></div>
            <div className="space-y-1.5 col-span-2"><Label>Sözleşme Bitiş (opsiyonel)</Label><Input type="date" value={form.contract_end_date} onChange={(e) => setForm({ ...form, contract_end_date: e.target.value })} /></div>
            <div className="space-y-1.5 col-span-2"><Label>Notlar</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          </div>
          <div className="text-sm text-muted-foreground border rounded p-2 bg-muted/40 space-y-0.5">
            <div>Kira bitişi: <strong>{format(parseISO(endDate), "dd.MM.yyyy")}</strong> ({months} ay)</div>
            <div>Ödemeler her ayın <strong>{parseISO(form.start_date).getDate()}.</strong> günü</div>
            <div className="text-xs">Not: Aylık ücreti değiştirmek mevcut ödeme planı satırlarını otomatik güncellemez.</div>
          </div>
          <DialogFooter><Button type="submit" disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
