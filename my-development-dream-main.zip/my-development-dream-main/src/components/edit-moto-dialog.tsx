import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Loader2, Pencil } from "lucide-react";
import { toast } from "sonner";

export type EditMoto = {
  id: string;
  plate: string;
  brand: string;
  model: string;
  year: number | null;
  color: string | null;
  current_km: number;
  service_interval_km: number;
  status: string;
  insurance_start: string | null;
  insurance_end: string | null;
  inspection_start: string | null;
  inspection_end: string | null;
  notes: string | null;
};

export function EditMotoDialog({
  moto,
  onDone,
  triggerLabel = "Düzenle",
  triggerVariant = "outline",
  iconOnly = false,
}: {
  moto: EditMoto;
  onDone: () => void;
  triggerLabel?: string;
  triggerVariant?: "outline" | "ghost";
  iconOnly?: boolean;
}) {
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({
    plate: moto.plate,
    brand: moto.brand,
    model: moto.model,
    year: moto.year?.toString() ?? "",
    color: moto.color ?? "",
    current_km: moto.current_km.toString(),
    service_interval_km: (moto.service_interval_km ?? 2000).toString(),
    status: moto.status,
    insurance_start: moto.insurance_start ?? "",
    insurance_end: moto.insurance_end ?? "",
    inspection_start: moto.inspection_start ?? "",
    inspection_end: moto.inspection_end ?? "",
    notes: moto.notes ?? "",
  });
  const [saving, setSaving] = useState(false);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setSaving(true);
    const { error } = await supabase.from("motorcycles").update({
      plate: form.plate.trim().toUpperCase(),
      brand: form.brand.trim(),
      model: form.model.trim(),
      year: form.year ? parseInt(form.year) : null,
      color: form.color || null,
      current_km: parseInt(form.current_km) || 0,
      service_interval_km: parseInt(form.service_interval_km) || 2000,
      status: form.status as "available" | "rented" | "service" | "inactive",
      insurance_start: form.insurance_start || null,
      insurance_end: form.insurance_end || null,
      inspection_start: form.inspection_start || null,
      inspection_end: form.inspection_end || null,
      notes: form.notes || null,
    }).eq("id", moto.id);
    setSaving(false);
    if (error) { toast.error("Kaydedilemedi", { description: error.message }); return; }
    toast.success("Güncellendi");
    setOpen(false);
    onDone();
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        {iconOnly ? (
          <Button size="icon" variant={triggerVariant} className="h-8 w-8"><Pencil className="h-4 w-4" /></Button>
        ) : (
          <Button size="sm" variant={triggerVariant}><Pencil className="h-4 w-4 mr-1" />{triggerLabel}</Button>
        )}
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Motosikleti Düzenle</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-3">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5"><Label>Plaka</Label><Input value={form.plate} onChange={(e) => setForm({ ...form, plate: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Durum</Label>
              <select className="border rounded h-9 px-2 w-full text-sm bg-background" value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                <option value="available">Müsait</option>
                <option value="rented">Kirada</option>
                <option value="service">Serviste</option>
                <option value="inactive">Pasif</option>
              </select>
            </div>
            <div className="space-y-1.5"><Label>Marka</Label><Input value={form.brand} onChange={(e) => setForm({ ...form, brand: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Model</Label><Input value={form.model} onChange={(e) => setForm({ ...form, model: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Yıl</Label><Input type="number" value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Renk</Label><Input value={form.color} onChange={(e) => setForm({ ...form, color: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Güncel KM</Label><Input type="number" value={form.current_km} onChange={(e) => setForm({ ...form, current_km: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Bakım Aralığı (km)</Label><Input type="number" value={form.service_interval_km} onChange={(e) => setForm({ ...form, service_interval_km: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Sigorta Başlangıç</Label><Input type="date" value={form.insurance_start} onChange={(e) => setForm({ ...form, insurance_start: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Sigorta Bitiş</Label><Input type="date" value={form.insurance_end} onChange={(e) => setForm({ ...form, insurance_end: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Muayene Başlangıç</Label><Input type="date" value={form.inspection_start} onChange={(e) => setForm({ ...form, inspection_start: e.target.value })} /></div>
            <div className="space-y-1.5"><Label>Muayene Bitiş</Label><Input type="date" value={form.inspection_end} onChange={(e) => setForm({ ...form, inspection_end: e.target.value })} /></div>
          </div>
          <div className="space-y-1.5"><Label>Notlar</Label><Input value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} /></div>
          <DialogFooter><Button type="submit" disabled={saving}>{saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}Kaydet</Button></DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
