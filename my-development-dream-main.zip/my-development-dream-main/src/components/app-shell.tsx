import { useNavigate } from "@tanstack/react-router";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { Button } from "@/components/ui/button";
import { LogOut, Bell } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import type { AppRole } from "@/lib/auth-hooks";
import { useEffect, type ReactNode } from "react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";

export function AppShell({ roles, children }: { roles: AppRole[]; children: ReactNode }) {
  const navigate = useNavigate();
  const qc = useQueryClient();

  // Kullanıcı konumunu bir kez alıp kaydet (admin paneli haritada gösterecek)
  useEffect(() => {
    if (typeof window === "undefined" || !navigator.geolocation) return;
    let cancelled = false;
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        if (cancelled) return;
        const { data: userData } = await supabase.auth.getUser();
        const uid = userData.user?.id;
        if (!uid) return;
        await supabase.from("user_locations").upsert({
          user_id: uid,
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
          updated_at: new Date().toISOString(),
        });
      },
      () => {
        /* konum reddedildi/başarısız — sessizce geç */
      },
      { maximumAge: 60_000, timeout: 10_000 },
    );
    return () => {
      cancelled = true;
    };
  }, []);

  const { data: unread } = useQuery({
    queryKey: ["notifications", "unread-count"],
    queryFn: async () => {
      const { count } = await supabase
        .from("notifications")
        .select("*", { count: "exact", head: true })
        .eq("read", false);
      return count ?? 0;
    },
    refetchInterval: 60_000,
  });

  async function signOut() {
    await qc.cancelQueries();
    qc.clear();
    await supabase.auth.signOut();
    toast.success("Çıkış yapıldı");
    navigate({ to: "/auth", replace: true });
  }

  return (
    <SidebarProvider>
      <div className="min-h-screen flex w-full">
        <AppSidebar roles={roles} />
        <div className="flex-1 flex flex-col">
          <header className="h-14 flex items-center justify-between border-b px-3 gap-2 bg-background sticky top-0 z-10">
            <div className="flex items-center gap-2">
              <SidebarTrigger />
              <span className="text-sm text-muted-foreground hidden sm:inline">
                {roles.includes("admin")
                  ? "Yönetici"
                  : roles.includes("staff")
                    ? "Personel"
                    : roles.includes("tenant")
                      ? "Kiracı"
                      : ""}
              </span>
            </div>
            <div className="flex items-center gap-1">
              <Button asChild variant="ghost" size="icon" className="relative">
                <Link to="/notifications" aria-label="Bildirimler">
                  <Bell className="h-4 w-4" />
                  {unread ? (
                    <Badge
                      className="absolute -right-1 -top-1 h-4 min-w-4 px-1 text-[10px]"
                      variant="destructive"
                    >
                      {unread}
                    </Badge>
                  ) : null}
                </Link>
              </Button>
              <Button variant="ghost" size="sm" onClick={signOut}>
                <LogOut className="h-4 w-4" />
                <span className="hidden sm:inline ml-1">Çıkış</span>
              </Button>
            </div>
          </header>
          <main className="flex-1 p-4 sm:p-6 bg-muted/20">{children}</main>
        </div>
      </div>
    </SidebarProvider>
  );
}