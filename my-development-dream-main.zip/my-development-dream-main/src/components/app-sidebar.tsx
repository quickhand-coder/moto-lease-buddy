import { Link, useRouterState } from "@tanstack/react-router";
import {
  Bike,
  LayoutDashboard,
  Users,
  FileText,
  Bell,
  BellPlus,
  UserCog,
  ClipboardList,
  Database,
  MapPin,
  ScrollText,
  Wallet,
  Wrench,
  CreditCard,
  Landmark,
  ShieldCheck,
} from "lucide-react";
import logoAsset from "@/assets/mty-filo-logo.png.asset.json";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  useSidebar,
} from "@/components/ui/sidebar";
import type { AppRole } from "@/lib/auth-hooks";

type Item = { title: string; url: string; icon: typeof Bike; roles: AppRole[] };

const items: Item[] = [
  { title: "Panel", url: "/dashboard", icon: LayoutDashboard, roles: ["admin", "staff"] },
  { title: "Motosikletler", url: "/motorcycles", icon: Bike, roles: ["admin", "staff"] },
  { title: "Kiracılar", url: "/tenants", icon: Users, roles: ["admin", "staff"] },
  { title: "Kiralar", url: "/rentals", icon: FileText, roles: ["admin", "staff"] },
  { title: "Bakımlar", url: "/service-records", icon: Wrench, roles: ["admin", "staff"] },
  { title: "Sigorta & Muayene", url: "/expirations", icon: ShieldCheck, roles: ["admin", "staff"] },
  { title: "Kiralamalarım", url: "/my-rentals", icon: ClipboardList, roles: ["tenant"] },
  { title: "Kazanç Takibi", url: "/earnings", icon: Wallet, roles: ["tenant"] },
  { title: "Ödeme Yap", url: "/payment", icon: CreditCard, roles: ["tenant"] },
  { title: "Kira Sözleşmesi", url: "/contract", icon: ScrollText, roles: ["tenant", "admin", "staff"] },
  { title: "Bildirimler", url: "/notifications", icon: Bell, roles: ["admin", "staff", "tenant"] },
  { title: "Bildirim Gönder", url: "/send-notification", icon: BellPlus, roles: ["admin", "staff"] },
  { title: "Kullanıcılar", url: "/users", icon: UserCog, roles: ["admin"] },
  { title: "Konumlar", url: "/locations", icon: MapPin, roles: ["admin"] },
  { title: "Finans", url: "/finance", icon: Wallet, roles: ["admin"] },
  { title: "Ödeme Ayarları", url: "/payment-settings", icon: Landmark, roles: ["admin"] },
  { title: "Yönetim", url: "/admin", icon: Database, roles: ["admin"] },
];

export function AppSidebar({ roles }: { roles: AppRole[] }) {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const visible = items.filter((i) => i.roles.some((r) => roles.includes(r)));

  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="border-b p-3">
        <div className="flex items-center gap-2">
          <img
            src={logoAsset.url}
            alt="MTY Filo"
            className="h-9 w-9 shrink-0 rounded-md object-contain bg-neutral-950 p-0.5"
          />
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="text-sm font-semibold">MTY Filo</span>
              <span className="text-xs text-muted-foreground">Takip Sistemi</span>
            </div>
          )}
        </div>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Menü</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {visible.map((item) => {
                const active = pathname === item.url || pathname.startsWith(item.url + "/");
                return (
                  <SidebarMenuItem key={item.url}>
                    <SidebarMenuButton asChild isActive={active}>
                      <Link to={item.url} className="flex items-center gap-2">
                        <item.icon className="h-4 w-4" />
                        {!collapsed && <span>{item.title}</span>}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}