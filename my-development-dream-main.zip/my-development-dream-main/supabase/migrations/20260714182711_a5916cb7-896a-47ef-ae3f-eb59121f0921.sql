
-- Add 'partial' to payment_status enum
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum e JOIN pg_type t ON t.oid=e.enumtypid WHERE t.typname='payment_status' AND e.enumlabel='partial') THEN
    ALTER TYPE public.payment_status ADD VALUE 'partial';
  END IF;
END $$;

-- Rentals extra columns
ALTER TABLE public.rentals ADD COLUMN IF NOT EXISTS deposit_status TEXT NOT NULL DEFAULT 'pending';
ALTER TABLE public.rentals ADD COLUMN IF NOT EXISTS deposit_paid_amount NUMERIC NOT NULL DEFAULT 0;
ALTER TABLE public.rentals ADD COLUMN IF NOT EXISTS deposit_paid_at TIMESTAMPTZ;
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_constraint WHERE conname='rentals_deposit_status_check') THEN
    ALTER TABLE public.rentals ADD CONSTRAINT rentals_deposit_status_check CHECK (deposit_status IN ('pending','paid','partial'));
  END IF;
END $$;

ALTER TABLE public.payment_schedule ADD COLUMN IF NOT EXISTS paid_amount NUMERIC NOT NULL DEFAULT 0;

-- user_locations
CREATE TABLE IF NOT EXISTS public.user_locations (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  accuracy DOUBLE PRECISION,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_locations TO authenticated;
GRANT ALL ON public.user_locations TO service_role;
ALTER TABLE public.user_locations ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "user_locations_select_own_or_staff" ON public.user_locations;
CREATE POLICY "user_locations_select_own_or_staff" ON public.user_locations FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_staff_or_admin(auth.uid()));
DROP POLICY IF EXISTS "user_locations_upsert_own" ON public.user_locations;
CREATE POLICY "user_locations_upsert_own" ON public.user_locations FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS "user_locations_update_own" ON public.user_locations;
CREATE POLICY "user_locations_update_own" ON public.user_locations FOR UPDATE TO authenticated USING (user_id = auth.uid());

-- monthly_expenses
CREATE TABLE IF NOT EXISTS public.monthly_expenses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  month DATE NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('deposit_refund','maintenance')),
  amount NUMERIC NOT NULL CHECK (amount >= 0),
  note TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monthly_expenses TO authenticated;
GRANT ALL ON public.monthly_expenses TO service_role;
ALTER TABLE public.monthly_expenses ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "expenses_select_staff" ON public.monthly_expenses;
CREATE POLICY "expenses_select_staff" ON public.monthly_expenses FOR SELECT TO authenticated USING (public.is_staff_or_admin(auth.uid()));
DROP POLICY IF EXISTS "expenses_insert_staff" ON public.monthly_expenses;
CREATE POLICY "expenses_insert_staff" ON public.monthly_expenses FOR INSERT TO authenticated WITH CHECK (public.is_staff_or_admin(auth.uid()));
DROP POLICY IF EXISTS "expenses_update_staff" ON public.monthly_expenses;
CREATE POLICY "expenses_update_staff" ON public.monthly_expenses FOR UPDATE TO authenticated USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
DROP POLICY IF EXISTS "expenses_delete_staff" ON public.monthly_expenses;
CREATE POLICY "expenses_delete_staff" ON public.monthly_expenses FOR DELETE TO authenticated USING (public.is_staff_or_admin(auth.uid()));

-- earnings_records
CREATE TABLE IF NOT EXISTS public.earnings_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  entry_date DATE NOT NULL,
  gross_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  hours_worked NUMERIC(6,2) NOT NULL DEFAULT 0,
  deliveries_count INTEGER NOT NULL DEFAULT 0,
  fuel_expense NUMERIC(12,2) NOT NULL DEFAULT 0,
  other_expense NUMERIC(12,2) NOT NULL DEFAULT 0,
  note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, entry_date)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.earnings_records TO authenticated;
GRANT ALL ON public.earnings_records TO service_role;
ALTER TABLE public.earnings_records ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "earnings_records_select_own" ON public.earnings_records;
CREATE POLICY "earnings_records_select_own" ON public.earnings_records FOR SELECT TO authenticated USING (user_id = auth.uid());
DROP POLICY IF EXISTS "earnings_records_insert_own" ON public.earnings_records;
CREATE POLICY "earnings_records_insert_own" ON public.earnings_records FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS "earnings_records_update_own" ON public.earnings_records;
CREATE POLICY "earnings_records_update_own" ON public.earnings_records FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS "earnings_records_delete_own" ON public.earnings_records;
CREATE POLICY "earnings_records_delete_own" ON public.earnings_records FOR DELETE TO authenticated USING (user_id = auth.uid());

-- earnings_goals
CREATE TABLE IF NOT EXISTS public.earnings_goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  month DATE NOT NULL,
  target_amount NUMERIC(12,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (user_id, month)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.earnings_goals TO authenticated;
GRANT ALL ON public.earnings_goals TO service_role;
ALTER TABLE public.earnings_goals ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "earnings_goals_select_own" ON public.earnings_goals;
CREATE POLICY "earnings_goals_select_own" ON public.earnings_goals FOR SELECT TO authenticated USING (user_id = auth.uid());
DROP POLICY IF EXISTS "earnings_goals_insert_own" ON public.earnings_goals;
CREATE POLICY "earnings_goals_insert_own" ON public.earnings_goals FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS "earnings_goals_update_own" ON public.earnings_goals;
CREATE POLICY "earnings_goals_update_own" ON public.earnings_goals FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
DROP POLICY IF EXISTS "earnings_goals_delete_own" ON public.earnings_goals;
CREATE POLICY "earnings_goals_delete_own" ON public.earnings_goals FOR DELETE TO authenticated USING (user_id = auth.uid());

-- payment_settings
CREATE TABLE IF NOT EXISTS public.payment_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_name TEXT NOT NULL DEFAULT '',
  account_holder TEXT NOT NULL DEFAULT '',
  iban TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.payment_settings TO authenticated;
GRANT ALL ON public.payment_settings TO service_role;
ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "payment_settings_read" ON public.payment_settings;
CREATE POLICY "payment_settings_read" ON public.payment_settings FOR SELECT TO authenticated USING (true);
DROP POLICY IF EXISTS "payment_settings_admin_manage" ON public.payment_settings;
CREATE POLICY "payment_settings_admin_manage" ON public.payment_settings FOR ALL TO authenticated USING (public.has_role(auth.uid(),'admin')) WITH CHECK (public.has_role(auth.uid(),'admin'));

INSERT INTO public.payment_settings (bank_name, account_holder, iban)
SELECT '', '', '' WHERE NOT EXISTS (SELECT 1 FROM public.payment_settings);

-- fleets
CREATE TABLE IF NOT EXISTS public.fleets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  notes TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.fleets TO service_role;
ALTER TABLE public.fleets ENABLE ROW LEVEL SECURITY;

INSERT INTO public.fleets (id, name, is_active)
VALUES ('00000000-0000-0000-0000-000000000001', 'Varsayılan Filo', true)
ON CONFLICT (id) DO NOTHING;

ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS fleet_id UUID REFERENCES public.fleets(id);
UPDATE public.profiles SET fleet_id = '00000000-0000-0000-0000-000000000001' WHERE fleet_id IS NULL;

-- founder_accounts
CREATE TABLE IF NOT EXISTS public.founder_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.founder_accounts TO service_role;
ALTER TABLE public.founder_accounts ENABLE ROW LEVEL SECURITY;

INSERT INTO public.founder_accounts (username, password_hash)
VALUES ('emirhan', 'a4d70a86ce23ce7ce6a2fdc4bcdb4c3e2b0e6f8f4bc3ef17c69e6ecd93a3b8ad')
ON CONFLICT (username) DO NOTHING;

-- founder_sessions
CREATE TABLE IF NOT EXISTS public.founder_sessions (
  token TEXT PRIMARY KEY,
  founder_id UUID NOT NULL REFERENCES public.founder_accounts(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.founder_sessions TO service_role;
ALTER TABLE public.founder_sessions ENABLE ROW LEVEL SECURITY;

-- Triggers
DROP TRIGGER IF EXISTS trg_payment_settings_updated ON public.payment_settings;
CREATE TRIGGER trg_payment_settings_updated BEFORE UPDATE ON public.payment_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
DROP TRIGGER IF EXISTS trg_fleets_updated ON public.fleets;
CREATE TRIGGER trg_fleets_updated BEFORE UPDATE ON public.fleets FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
DROP TRIGGER IF EXISTS trg_founder_accounts_updated ON public.founder_accounts;
CREATE TRIGGER trg_founder_accounts_updated BEFORE UPDATE ON public.founder_accounts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
DROP TRIGGER IF EXISTS monthly_expenses_set_updated_at ON public.monthly_expenses;
CREATE TRIGGER monthly_expenses_set_updated_at BEFORE UPDATE ON public.monthly_expenses FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
DROP TRIGGER IF EXISTS earnings_records_set_updated_at ON public.earnings_records;
CREATE TRIGGER earnings_records_set_updated_at BEFORE UPDATE ON public.earnings_records FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
DROP TRIGGER IF EXISTS earnings_goals_set_updated_at ON public.earnings_goals;
CREATE TRIGGER earnings_goals_set_updated_at BEFORE UPDATE ON public.earnings_goals FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- fleet_access_active
CREATE OR REPLACE FUNCTION public.fleet_access_active(_user_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(
    (SELECT f.is_active AND (f.expires_at IS NULL OR f.expires_at > now())
     FROM public.profiles p JOIN public.fleets f ON f.id = p.fleet_id
     WHERE p.id = _user_id),
    true
  );
$$;
GRANT EXECUTE ON FUNCTION public.fleet_access_active(UUID) TO authenticated;
