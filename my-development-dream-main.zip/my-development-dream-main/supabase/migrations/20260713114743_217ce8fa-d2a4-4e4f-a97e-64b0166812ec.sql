
-- Storage policies for motorcycle-photos
DROP POLICY IF EXISTS "moto_photos_read_authenticated" ON storage.objects;
DROP POLICY IF EXISTS "moto_photos_insert_authenticated" ON storage.objects;
DROP POLICY IF EXISTS "moto_photos_insert_staff" ON storage.objects;
DROP POLICY IF EXISTS "moto_photos_update_owner" ON storage.objects;
DROP POLICY IF EXISTS "moto_photos_update_staff" ON storage.objects;
DROP POLICY IF EXISTS "moto_photos_delete_staff_or_owner" ON storage.objects;
DROP POLICY IF EXISTS "moto_photos_delete_staff" ON storage.objects;

CREATE POLICY "moto_photos_read_authenticated" ON storage.objects
  FOR SELECT TO authenticated USING (bucket_id = 'motorcycle-photos');
CREATE POLICY "moto_photos_insert_authenticated" ON storage.objects
  FOR INSERT TO authenticated WITH CHECK (bucket_id = 'motorcycle-photos');
CREATE POLICY "moto_photos_update_owner" ON storage.objects
  FOR UPDATE TO authenticated USING (bucket_id = 'motorcycle-photos' AND owner = auth.uid());
CREATE POLICY "moto_photos_delete_staff_or_owner" ON storage.objects
  FOR DELETE TO authenticated USING (
    bucket_id = 'motorcycle-photos'
    AND (public.is_staff_or_admin(auth.uid()) OR owner = auth.uid())
  );

-- Restrict tenants to inserting service records with today's date only
DROP POLICY IF EXISTS "service_records_insert_auth" ON public.service_records;
CREATE POLICY "service_records_insert_auth" ON public.service_records FOR INSERT TO authenticated
  WITH CHECK (
    public.is_staff_or_admin(auth.uid())
    OR (
      service_date = CURRENT_DATE
      AND EXISTS (
        SELECT 1 FROM public.rentals r
        JOIN public.tenants t ON t.id = r.tenant_id
        WHERE r.motorcycle_id = service_records.motorcycle_id
          AND r.status = 'active'
          AND t.user_id = auth.uid()
      )
    )
  );
