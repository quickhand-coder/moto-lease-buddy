
ALTER TABLE public.service_records
  ADD COLUMN IF NOT EXISTS photo_url text,
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id);

DROP POLICY IF EXISTS service_records_all_staff ON public.service_records;

CREATE POLICY service_records_select_all ON public.service_records
  FOR SELECT TO authenticated USING (true);

CREATE POLICY service_records_insert_auth ON public.service_records
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by OR created_by IS NULL);

CREATE POLICY service_records_update_staff ON public.service_records
  FOR UPDATE TO authenticated USING (public.is_staff_or_admin(auth.uid()));

CREATE POLICY service_records_delete_staff ON public.service_records
  FOR DELETE TO authenticated USING (public.is_staff_or_admin(auth.uid()));

-- Storage policies for motorcycle-photos bucket (service-photos folder)
DROP POLICY IF EXISTS "service_photos_select" ON storage.objects;
DROP POLICY IF EXISTS "service_photos_insert" ON storage.objects;

CREATE POLICY "service_photos_select" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'motorcycle-photos');

CREATE POLICY "service_photos_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'motorcycle-photos');
