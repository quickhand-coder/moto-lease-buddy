
ALTER TABLE public.rentals
  ADD COLUMN IF NOT EXISTS deposit_status text NOT NULL DEFAULT 'pending',
  ADD COLUMN IF NOT EXISTS deposit_paid_amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS deposit_paid_at timestamptz;

ALTER TABLE public.rentals
  DROP CONSTRAINT IF EXISTS rentals_deposit_status_check;
ALTER TABLE public.rentals
  ADD CONSTRAINT rentals_deposit_status_check
  CHECK (deposit_status IN ('pending','paid','partial'));
