
ALTER TYPE public.payment_status ADD VALUE IF NOT EXISTS 'partial';

ALTER TABLE public.payment_schedule
  ADD COLUMN IF NOT EXISTS paid_amount NUMERIC NOT NULL DEFAULT 0;

UPDATE public.payment_schedule
SET paid_amount = amount
WHERE status = 'paid' AND paid_amount = 0;
