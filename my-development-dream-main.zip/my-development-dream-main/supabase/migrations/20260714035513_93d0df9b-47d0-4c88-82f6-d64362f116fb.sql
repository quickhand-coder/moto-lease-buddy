
-- Payment settings
CREATE TABLE public.payment_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  bank_name TEXT NOT NULL DEFAULT '',
  account_holder TEXT NOT NULL DEFAULT '',
  iban TEXT NOT NULL DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT ON public.payment_settings TO authenticated;
GRANT ALL ON public.payment_settings TO service_role;
ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "auth users read payment settings" ON public.payment_settings FOR SELECT TO authenticated USING (true);
CREATE POLICY "admins manage payment settings" ON public.payment_settings FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'admin')) WITH CHECK (public.has_role(auth.uid(), 'admin'));

INSERT INTO public.payment_settings (bank_name, account_holder, iban) VALUES ('', '', '');

CREATE TRIGGER trg_payment_settings_updated BEFORE UPDATE ON public.payment_settings FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Fleets
CREATE TABLE public.fleets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  notes TEXT,
  is_active BOOLEAN NOT NULL DEFAULT true,
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.fleets TO service_role;
ALTER TABLE public.fleets ENABLE ROW LEVEL SECURITY;
-- No policies: founder access only via server functions using service_role.

CREATE TRIGGER trg_fleets_updated BEFORE UPDATE ON public.fleets FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.fleets (id, name, is_active) VALUES ('00000000-0000-0000-0000-000000000001', 'Varsayılan Filo', true);

-- Add fleet_id to profiles
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS fleet_id UUID REFERENCES public.fleets(id);
UPDATE public.profiles SET fleet_id = '00000000-0000-0000-0000-000000000001' WHERE fleet_id IS NULL;

-- Founder accounts (sha256 hex hash)
CREATE TABLE public.founder_accounts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.founder_accounts TO service_role;
ALTER TABLE public.founder_accounts ENABLE ROW LEVEL SECURITY;
CREATE TRIGGER trg_founder_accounts_updated BEFORE UPDATE ON public.founder_accounts FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Initial founder: emirhan / emirhan  (sha256 of "emirhan")
INSERT INTO public.founder_accounts (username, password_hash) VALUES ('emirhan', 'a4d70a86ce23ce7ce6a2fdc4bcdb4c3e2b0e6f8f4bc3ef17c69e6ecd93a3b8ad');

-- Founder sessions
CREATE TABLE public.founder_sessions (
  token TEXT PRIMARY KEY,
  founder_id UUID NOT NULL REFERENCES public.founder_accounts(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT ALL ON public.founder_sessions TO service_role;
ALTER TABLE public.founder_sessions ENABLE ROW LEVEL SECURITY;

-- Fleet access check function
CREATE OR REPLACE FUNCTION public.fleet_access_active(_user_id UUID)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT COALESCE(
    (SELECT f.is_active AND (f.expires_at IS NULL OR f.expires_at > now())
     FROM public.profiles p
     JOIN public.fleets f ON f.id = p.fleet_id
     WHERE p.id = _user_id),
    true
  );
$$;
