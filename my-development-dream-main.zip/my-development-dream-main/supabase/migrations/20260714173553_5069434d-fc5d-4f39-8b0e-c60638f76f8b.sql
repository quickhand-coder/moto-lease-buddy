REVOKE EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.is_staff_or_admin(UUID) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
GRANT EXECUTE ON FUNCTION public.has_role(UUID, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_staff_or_admin(UUID) TO authenticated;

DROP POLICY IF EXISTS "moto_photos_read_authenticated" ON storage.objects;
CREATE POLICY "moto_photos_read_authenticated" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'motorcycle-photos');

DROP POLICY IF EXISTS "moto_photos_insert_staff" ON storage.objects;
CREATE POLICY "moto_photos_insert_staff" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'motorcycle-photos' AND public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "moto_photos_update_staff" ON storage.objects;
CREATE POLICY "moto_photos_update_staff" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'motorcycle-photos' AND public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "moto_photos_delete_staff" ON storage.objects;
CREATE POLICY "moto_photos_delete_staff" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'motorcycle-photos' AND public.is_staff_or_admin(auth.uid()));

ALTER TABLE public.service_records
  ADD COLUMN IF NOT EXISTS photo_url text,
  ADD COLUMN IF NOT EXISTS created_by uuid REFERENCES auth.users(id);

DROP POLICY IF EXISTS service_records_all_staff ON public.service_records;

CREATE POLICY service_records_select_all ON public.service_records
  FOR SELECT TO authenticated USING (true);

CREATE POLICY service_records_insert_auth ON public.service_records
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by OR created_by IS NULL);

CREATE POLICY service_records_update_staff ON public.service_records
  FOR UPDATE TO authenticated USING (public.is_staff_or_admin(auth.uid()));

CREATE POLICY service_records_delete_staff ON public.service_records
  FOR DELETE TO authenticated USING (public.is_staff_or_admin(auth.uid()));

DROP POLICY IF EXISTS "service_photos_select" ON storage.objects;
DROP POLICY IF EXISTS "service_photos_insert" ON storage.objects;

DROP POLICY IF EXISTS "service_photos_select" ON storage.objects;
CREATE POLICY "service_photos_select" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'motorcycle-photos');

DROP POLICY IF EXISTS "service_photos_insert" ON storage.objects;
CREATE POLICY "service_photos_insert" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'motorcycle-photos');