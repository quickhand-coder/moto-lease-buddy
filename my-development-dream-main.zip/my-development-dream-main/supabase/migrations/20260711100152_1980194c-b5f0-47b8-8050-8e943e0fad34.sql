
CREATE POLICY "moto_photos_read_authenticated" ON storage.objects
  FOR SELECT TO authenticated
  USING (bucket_id = 'motorcycle-photos');

CREATE POLICY "moto_photos_insert_staff" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'motorcycle-photos' AND public.is_staff_or_admin(auth.uid()));

CREATE POLICY "moto_photos_update_staff" ON storage.objects
  FOR UPDATE TO authenticated
  USING (bucket_id = 'motorcycle-photos' AND public.is_staff_or_admin(auth.uid()));

CREATE POLICY "moto_photos_delete_staff" ON storage.objects
  FOR DELETE TO authenticated
  USING (bucket_id = 'motorcycle-photos' AND public.is_staff_or_admin(auth.uid()));
