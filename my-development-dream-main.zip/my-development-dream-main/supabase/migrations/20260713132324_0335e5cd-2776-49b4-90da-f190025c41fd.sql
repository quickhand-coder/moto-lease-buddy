
-- Add monthly_rate to rentals
ALTER TABLE public.rentals ADD COLUMN monthly_rate NUMERIC(12,2) NOT NULL DEFAULT 8500;

-- Deposit + partial payment extensions
ALTER TYPE public.payment_status ADD VALUE IF NOT EXISTS 'partial';
ALTER TABLE public.payment_schedule ADD COLUMN paid_amount NUMERIC NOT NULL DEFAULT 0;
ALTER TABLE public.rentals
  ADD COLUMN deposit_status text NOT NULL DEFAULT 'pending',
  ADD COLUMN deposit_paid_amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN deposit_paid_at timestamptz;
ALTER TABLE public.rentals ADD CONSTRAINT rentals_deposit_status_check CHECK (deposit_status IN ('pending','paid','partial'));

-- user_locations
CREATE TABLE public.user_locations (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  accuracy DOUBLE PRECISION,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_locations TO authenticated;
GRANT ALL ON public.user_locations TO service_role;
ALTER TABLE public.user_locations ENABLE ROW LEVEL SECURITY;
CREATE POLICY "user_locations_select_own_or_staff" ON public.user_locations FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.is_staff_or_admin(auth.uid()));
CREATE POLICY "user_locations_upsert_own" ON public.user_locations FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "user_locations_update_own" ON public.user_locations FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

-- monthly_expenses
CREATE TABLE public.monthly_expenses (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  month DATE NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('deposit_refund','maintenance')),
  amount NUMERIC NOT NULL CHECK (amount >= 0),
  note TEXT,
  created_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.monthly_expenses TO authenticated;
GRANT ALL ON public.monthly_expenses TO service_role;
ALTER TABLE public.monthly_expenses ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Staff can view expenses" ON public.monthly_expenses FOR SELECT TO authenticated USING (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "Staff can insert expenses" ON public.monthly_expenses FOR INSERT TO authenticated WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "Staff can update expenses" ON public.monthly_expenses FOR UPDATE TO authenticated USING (public.is_staff_or_admin(auth.uid())) WITH CHECK (public.is_staff_or_admin(auth.uid()));
CREATE POLICY "Staff can delete expenses" ON public.monthly_expenses FOR DELETE TO authenticated USING (public.is_staff_or_admin(auth.uid()));
CREATE TRIGGER monthly_expenses_set_updated_at BEFORE UPDATE ON public.monthly_expenses FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX idx_monthly_expenses_month ON public.monthly_expenses(month);

-- Storage: motorcycle-photos policies
CREATE POLICY "moto_photos_read_authenticated" ON storage.objects FOR SELECT TO authenticated USING (bucket_id = 'motorcycle-photos');
CREATE POLICY "moto_photos_insert_authenticated" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'motorcycle-photos');
CREATE POLICY "moto_photos_update_owner" ON storage.objects FOR UPDATE TO authenticated USING (bucket_id = 'motorcycle-photos' AND owner = auth.uid());
CREATE POLICY "moto_photos_delete_staff_or_owner" ON storage.objects FOR DELETE TO authenticated USING (bucket_id = 'motorcycle-photos' AND (public.is_staff_or_admin(auth.uid()) OR owner = auth.uid()));

-- Tighten service_records insert to tenant-with-active-rental
DROP POLICY IF EXISTS "service_records_insert_auth" ON public.service_records;
CREATE POLICY "service_records_insert_auth" ON public.service_records FOR INSERT TO authenticated
  WITH CHECK (
    public.is_staff_or_admin(auth.uid())
    OR (service_date = CURRENT_DATE AND EXISTS (
      SELECT 1 FROM public.rentals r JOIN public.tenants t ON t.id = r.tenant_id
      WHERE r.motorcycle_id = service_records.motorcycle_id AND r.status = 'active' AND t.user_id = auth.uid()
    ))
  );

-- Earnings tracking (tenant-only)
CREATE TABLE public.earnings_records (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  entry_date date NOT NULL,
  gross_amount numeric(12,2) NOT NULL DEFAULT 0,
  hours_worked numeric(6,2) NOT NULL DEFAULT 0,
  deliveries_count integer NOT NULL DEFAULT 0,
  fuel_expense numeric(12,2) NOT NULL DEFAULT 0,
  other_expense numeric(12,2) NOT NULL DEFAULT 0,
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, entry_date)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.earnings_records TO authenticated;
GRANT ALL ON public.earnings_records TO service_role;
ALTER TABLE public.earnings_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "earnings_records_select_own" ON public.earnings_records FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "earnings_records_insert_own" ON public.earnings_records FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "earnings_records_update_own" ON public.earnings_records FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "earnings_records_delete_own" ON public.earnings_records FOR DELETE TO authenticated USING (user_id = auth.uid());
CREATE INDEX earnings_records_user_date_idx ON public.earnings_records (user_id, entry_date DESC);

CREATE TABLE public.earnings_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  month date NOT NULL,
  target_amount numeric(12,2) NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, month)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.earnings_goals TO authenticated;
GRANT ALL ON public.earnings_goals TO service_role;
ALTER TABLE public.earnings_goals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "earnings_goals_select_own" ON public.earnings_goals FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "earnings_goals_insert_own" ON public.earnings_goals FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "earnings_goals_update_own" ON public.earnings_goals FOR UPDATE TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
CREATE POLICY "earnings_goals_delete_own" ON public.earnings_goals FOR DELETE TO authenticated USING (user_id = auth.uid());
