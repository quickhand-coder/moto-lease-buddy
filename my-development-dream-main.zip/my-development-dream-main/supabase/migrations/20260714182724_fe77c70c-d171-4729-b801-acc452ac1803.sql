
ALTER TABLE public.motorcycles ADD COLUMN IF NOT EXISTS service_interval_km INTEGER NOT NULL DEFAULT 2000;
ALTER TABLE public.rentals ADD COLUMN IF NOT EXISTS monthly_rate NUMERIC(12,2) NOT NULL DEFAULT 8500;

-- Restrict SECURITY DEFINER exec to only authenticated (revoke from PUBLIC/anon)
REVOKE EXECUTE ON FUNCTION public.fleet_access_active(UUID) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.fleet_access_active(UUID) TO authenticated;
