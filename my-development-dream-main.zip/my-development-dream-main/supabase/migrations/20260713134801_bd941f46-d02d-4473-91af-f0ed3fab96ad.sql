
CREATE POLICY "Authenticated can read motorcycle photos"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'motorcycle-photos');

CREATE POLICY "Authenticated can upload motorcycle photos"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'motorcycle-photos');

CREATE POLICY "Authenticated can update motorcycle photos"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'motorcycle-photos');

CREATE POLICY "Authenticated can delete motorcycle photos"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'motorcycle-photos');
