## Hedef
Yüklenen `app-development-helper-main.zip` içindeki **MTY Filo Takip Sistemi** uygulamasını mevcut boş TanStack Start projesine tam olarak taşımak ve `plan.md`’de belirtilen rol bazlı yönlendirme düzenlemelerini uygulamak.

## Mevcut Durum
- Mevcut proje: boş Lovable TanStack Start şablonu, yalnızca placeholder ana sayfa içeriyor.
- Zip içindeki proje: tam teşekküllü motosiklet kiralama/filo takip uygulaması.
  - TanStack Start + React 19 + Tailwind v4 + shadcn/ui
  - Lovable Cloud (Supabase) auth, veritabanı, storage entegrasyonu
  - Admin / staff / tenant rolleri
  - Dashboard, kiralamalar, ödemeler, bakım, konum, finans, bildirim, yönetim ekranları
  - `supabase/migrations/` altında 20+ migration dosyası
  - `plan.md`’de 3 açık yapılacak: dashboard erişim kısıtlaması, kiracı giriş yönlendirmesi, index yönlendirmesi

## Teknik Detaylar

### 1. Dosya taşıma ve proje yapılandırması
- `src/` klasörünün tamamını zip’ten mevcut projeye kopyala (bileşenler, hook’lar, route’lar, lib, integrations, assets pointer’ları).
- `public/` içeriğini kopyala (favicon, vb.).
- `package.json`’ı zip’tekiyle değiştir veya eksik bağımlılıkları ekle:
  - `@supabase/supabase-js`
  - `leaflet`, `@types/leaflet`, `react-leaflet`
  - Diğer mevcut bağımlılıklar zaten şablonda var.
- `vite.config.ts`, `tsconfig.json`, `components.json`, `.prettierrc`, `.prettierignore` gibi yapılandırma dosyalarını karşılaştır ve gerekirse güncelle.
- `.gitignore` ve `AGENTS.md`’yi koru; `.env` dosyasını kopyalama (eski projenin Supabase bilgileri içeriyor).

### 2. Lovable Cloud entegrasyonu
- Lovable Cloud’u etkinleştir (`supabase--enable`).
- Yeni proje için Supabase URL ve publishable key bilgilerini al.
- Gerekli secrets/ortam değişkenlerini ayarla:
  - `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY`
  - `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`
  - `SUPABASE_SERVICE_ROLE_KEY` (server-only)

### 3. Veritabanı şeması
- Zip içindeki `supabase/migrations/` dosyalarını mevcut projeye kopyala.
- Migration’ları sırayla çalıştırarak tabloları, fonksiyonları, RLS politikalarını ve rolleri oluştur.
- Önemli tablolar: `profiles`, `user_roles`, `motorcycles`, `tenants`, `rentals`, `payment_schedule`, `service_records`, `notifications`, `fleets`, `fleet_users`, `earnings_goals`, `earnings_records`, `monthly_expenses`, `founder_accounts`, `founder_sessions`.
- `fleet_access_active` RPC fonksiyonunun ve ilgili trigger/politikaların oluştuğunu doğrula.

### 4. Varlıklar (assets)
- `src/assets/mty-filo-logo.png.asset.json` pointer’ını koru; görselin CDN’de hâlâ erişilebilir olduğunu doğrula.
- Gerekirse logoyu `lovable-assets` ile yeni projeye yeniden oluştur veya mevcut pointer’ı kullan.

### 5. `plan.md` düzenlemelerini uygula
- `src/routes/_authenticated/dashboard.tsx`:
  - Bileşen render öncesi rol kontrolü ekle.
  - Kullanıcı sadece `tenant` ise `/my-rentals` sayfasına `<Navigate replace />` ile yönlendir.
- `src/routes/auth.tsx`:
  - Giriş başarılı olduktan sonra rolleri kontrol et.
  - `admin` veya `staff` varsa `/dashboard`, sadece `tenant` ise `/my-rentals` yönlendirmesi yap.
- `src/routes/index.tsx`:
  - Mevcut rol bazlı yönlendirme zaten var; kontrol et ve gerekiyorsa güçlendir.
  - Kiracının `/dashboard` yerine hiçbir zaman panele düşmemesini sağla.

### 6. Build ve doğrulama
- `bun install` ile bağımlılıkları güncelle.
- `vite build` veya `bun run build` ile derleme yap.
- Derleme hatalarını çöz:
  - Eksik importlar
  - Route tree uyumsuzlukları
  - Transitive `client.server` import hataları
- Uygulamayı önizlemede aç ve temel akışları test et:
  - `/auth` giriş sayfası
  - Admin girişi → `/dashboard`
  - Tenant girişi → `/my-rentals`
  - Tenant `/dashboard` doğrudan URL erişimi → `/my-rentals` yönlendirmesi

## Beklenen Sonuç
- Mevcut boş proje, zip’teki MTY Filo Takip Sistemi’ne dönüşmüş olacak.
- Lovable Cloud bağlı ve veritabanı şeması hazır olacak.
- Kiracı kullanıcılar panel yerine `/my-rentals` sayfasına yönlendirilecek.
- Admin/staff kullanıcılar `/dashboard` sayfasına erişebilecek.

## Notlar
- `.env` dosyası eski projenin Supabase bilgilerini içerdiği için doğrudan kopyalanmayacak; Lovable Cloud etkinleştirildikten sonra yeni projenin kendi değerleri kullanılacak.
- Kullanıcı profili verisi (profiles tablosu) uygulamanın zorunlu parçası olduğu için ayrıca sorulmayacak; mevcut migration’larla kurulacak.